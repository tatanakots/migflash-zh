import tkinter as tk
from tkinter import ttk
from tkinter import filedialog as fd
from tkinter.messagebox import showerror
from tkinter.messagebox import showinfo
import traceback
import struct
import os, sys, platform
import logging
import re
from enum import Enum
from threading import Thread

OFFSET = 0x209A4000
SIZE = 0x44000
BLOCKS = SIZE // 512

logging.basicConfig(format="%(asctime)s %(message)s")
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

appdir = os.path.dirname(__file__)

def isWindowsPlatform():
    return platform.system() == 'Windows'

def isMacPlatform():
    return platform.system() == 'Darwin'

def isLinuxPlatform():
    return platform.system() == 'Linux'


logger.info(f"Application is running on system {platform.system()}")
logger.info(f"Application is running from directory {appdir}")

if isMacPlatform():
    m = re.search(r'(.+\.app)/.+\.app/.+', appdir)
    iconPath = m.group(1) if m and os.path.isdir(m.group(1)) else None
elif isWindowsPlatform():
    iconPath = appdir + "/assets/icon.ico"
else:
    iconPath = appdir + "/assets/icon.png"

if isWindowsPlatform():
    import win32file
    import win32con
    import win32api
    import winioctlcon
    import winerror
    import ctypes
    from ctypes import wintypes
    from ctypes import windll

    kernel32 = ctypes.WinDLL('kernel32')
    kernel32.FindFirstVolumeW.restype = wintypes.HANDLE
    kernel32.FindNextVolumeW.argtypes = (wintypes.HANDLE, wintypes.LPWSTR, wintypes.DWORD)
    kernel32.FindVolumeClose.argtypes = (wintypes.HANDLE,)

    DRIVE_TYPES = {
       win32con.DRIVE_REMOVABLE : "usb",
       win32con.DRIVE_FIXED     : "hdd"
    }

    def setHighDpiAware():
        try:
            windll.shcore.SetProcessDpiAwareness(1)
        except:
            return

    setHighDpiAware()

    def isUserAdmin():
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            traceback.print_exc()
            return False

    def FindFirstVolume():
        volume_name = ctypes.create_unicode_buffer(" " * 255)
        h = kernel32.FindFirstVolumeW(volume_name, 255)
        if h == win32file.INVALID_HANDLE_VALUE:
            raise RuntimeError("FindFirstVolume() returned an invalid handle.")
        return h, volume_name.value

    def FindNextVolume(h):
        volume_name = ctypes.create_unicode_buffer(" " * 255)
        if kernel32.FindNextVolumeW(h, volume_name, 255) != 0:
            return volume_name.value
        else:
            errno = ctypes.GetLastError()
            if errno == winerror.ERROR_NO_MORE_FILES:
                FindVolumeClose(h)
                return None
            raise RuntimeError("FindNextVolume failed (%s)" % errno)

    def FindVolumeClose(h):
        if kernel32.FindVolumeClose(h) == 0:
            raise RuntimeError("FindVolumeClose() failed.")

    class Volume:
        def __init__(self, guid):
            self.valid = False

            driveType = win32file.GetDriveType(guid)
            if driveType not in [win32con.DRIVE_REMOVABLE, win32con.DRIVE_FIXED]:
                return

            mountPoints = ",".join(win32file.GetVolumePathNamesForVolumeName(guid))

            try:
                volumeLabel, volumeSerial, maxFilenameLen, sysFlags, filesystemType = win32api.GetVolumeInformation(guid)
            except Exception:
                volumeLabel = ''

            try:
                physicalPath = None
                h = win32file.CreateFile(guid[:-1], win32con.GENERIC_READ, win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE, None, win32con.OPEN_EXISTING, win32con.FILE_ATTRIBUTE_NORMAL,  None)
                r = win32file.DeviceIoControl(h, winioctlcon.IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, None, 512, None)
                if len(r) >= 12:
                    deviceNumber = struct.unpack('L', r[8:12])[0]
                    physicalPath = fr"\\.\PhysicalDrive{deviceNumber}"
                    logger.debug(f'Volume {guid} maps to drive {physicalPath}')
                win32file.CloseHandle(h)
            except Exception:
                physicalPath = None

            if physicalPath is None:
                return

            self.valid = True
            self.physicalPath = physicalPath
            self.volumePath = guid[:-1]
            self.mountPoints = mountPoints
            self.label = volumeLabel
            
        def isValid(self):
            return self.valid

        def getLabel(self):
            return self.label
            
        def getMountPoints(self):
            return self.mountPoints
            
        def getPhysicalPath(self):
            return self.physicalPath

        def getVolumePath(self):
            return self.volumePath
            
        def lock(self):
            access_flag = win32con.GENERIC_READ | win32con.GENERIC_WRITE
            share_flag = win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE
            self.handle = win32file.CreateFile(self.volumePath, access_flag, share_flag, None, win32con.OPEN_EXISTING, win32con.FILE_ATTRIBUTE_NORMAL, None)
            win32file.DeviceIoControl(self.handle, winioctlcon.FSCTL_LOCK_VOLUME, None, 0, None)

        def dismount(self):
            win32file.DeviceIoControl(self.handle, winioctlcon.FSCTL_DISMOUNT_VOLUME, None, 0, None)

        def unlock(self):
            win32file.DeviceIoControl(self.handle, winioctlcon.FSCTL_UNLOCK_VOLUME, None, 0, None)
            win32file.CloseHandle(self.handle)
            self.handle = None

    class Drive:
        def __init__(self, num, volumes):
            self.valid = False
            driveType = None
            try:
                physicalPath = fr'\\.\PhysicalDrive{num}'
                driveType = win32file.GetDriveType(physicalPath + '\\')
                if driveType not in [win32con.DRIVE_REMOVABLE, win32con.DRIVE_FIXED]:
                    return
                
                h = win32file.CreateFile(physicalPath, win32con.GENERIC_READ, win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE, None, win32con.OPEN_EXISTING, win32con.FILE_ATTRIBUTE_NORMAL, None)
                win32api.CloseHandle(h)
                logger.debug(f'Drive {physicalPath} {DRIVE_TYPES.get(driveType, "")} exists')
            except:
                return
            
            self.volumes = [volume for volume in volumes if volume.getPhysicalPath() == physicalPath]
            volumeLabels = " ".join([volume.getLabel() for volume in self.volumes if len(volume.getLabel()) > 0])
            volumeMountPoints = " ".join([volume.getMountPoints() for volume in self.volumes if len(volume.getMountPoints()) > 0])
            
            self.valid = True
            self.removable = driveType == win32con.DRIVE_REMOVABLE
            self.physicalPath = physicalPath
            self.displayText = f'{physicalPath} {DRIVE_TYPES.get(driveType, "")} {volumeMountPoints} {volumeLabels}'
            
        def isValid(self):
            return self.valid
            
        def isRemovable(self):
            return self.removable
            
        def getDisplayText(self):
            return self.displayText

        def open(self):
            logger.debug(f'Locking volumes')
            for volume in self.volumes:
                volume.lock()

            logger.debug(f'Opening drive file')
            access_flag = win32con.GENERIC_READ | win32con.GENERIC_WRITE
            share_flag = win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE
            self.handle = win32file.CreateFile(self.physicalPath, access_flag, share_flag, None, win32con.OPEN_EXISTING, win32con.FILE_ATTRIBUTE_NORMAL, None)
                
        def write(self, buf):
            win32file.WriteFile(self.handle, buf, None)
                
        def read(self, size):
            r, buf = win32file.ReadFile(self.handle, size, None)
            if r != 0:
                raise RuntimeError('ReadFile returned error')
            return buf
                
        def seek(self, offset):
            win32file.SetFilePointer(self.handle, offset, win32con.FILE_BEGIN)

        def eject(self):
            logger.debug(f'Ejecting drive')
            win32file.DeviceIoControl(self.handle, winioctlcon.IOCTL_STORAGE_EJECT_MEDIA, None, 0, None)

        def close(self):
            logger.debug(f'Unlocking volumes')
            for volume in self.volumes:
                volume.unlock()
            logger.debug(f'Closing drive file')
            win32file.CloseHandle(self.handle)
            self.handle = None
            
    def findVolumes():
        found = []
        h, guid = FindFirstVolume()
        while h and guid:
            volume = Volume(guid)

            if volume.isValid():
                found.append(volume)

            guid = FindNextVolume(h)
        return found
        
    def findDrives():
        volumes = findVolumes()
        found = []
        for i in range(32):
            drive = Drive(i, volumes)
            if drive.isValid() and drive.isRemovable():
                logger.debug(f'Found {drive.getDisplayText()}')
                found.append(drive)
        found.reverse()
        return found
else:
    import subprocess
    import plistlib, json

    def isUserAdmin():
        return os.geteuid() == 0

    class Drive:
        def __init__(self, path, volumeName):
            self.path = path
            self.displayText = f'{path} {volumeName}'
            
        def isRemovable(self):
            return True
            
        def getDisplayText(self):
            return self.displayText

        def open(self):
            if isMacPlatform():
                logger.debug(f'Unmounting disk {self.path}')
                subprocess.check_call(["diskutil", "unmountDisk", "force", self.path])
                logger.debug(f'Disk {self.path} unmounted')

            logger.debug(f'Opening drive file')
            self.f = open(self.path, 'r+b')
                
        def write(self, buf):
            self.f.write(buf)
                
        def read(self, size):
            return self.f.read(size)
                
        def seek(self, offset):
            self.f.seek(offset)

        def eject(self):
            self.f.flush()

        def close(self):
            logger.debug(f'Closing drive file')
            self.f.close()
            self.f = None


    if isMacPlatform():
        def findDrives():
            found = []
            logger.debug('Listing drives..')
            plist = subprocess.check_output(["diskutil", "list", "-plist", "external"])
            logger.debug('Drive list received')
            plist = plistlib.loads(plist)
            for d in plist.get('AllDisksAndPartitions', []):
                diskId = d.get('DeviceIdentifier', None)
                partitions = d.get('Partitions', [])

                logger.debug(f'Found disk {diskId} {partitions}')
                if len(partitions):
                    volumeNames = [p.get('VolumeName', None) for p in partitions]
                    volumeNames = " ".join([s for s in volumeNames if s is not None])
                    found.append(Drive(f'/dev/{diskId}', volumeNames))

            found.reverse()
            return found
    else:
        def findDrives():
            found = []
            logger.debug('Listing drives..')
            lsblk = json.loads(subprocess.check_output(["lsblk", "-o", "path,type,fstype,tran,label", "-T", "--json"]))
            logger.debug('Drive list received')
            for b in lsblk.get('blockdevices', []):
                path = b.get('path', '')
                type = b.get('type', '')
                tran = b.get('tran', '')
                if type == 'disk' and tran == 'usb':
                    partitions = b.get('children', [])
                    logger.debug(f'Found disk {path} {partitions}')
                    exfatPartitions = [p for p in partitions if p.get('fstype', '') == 'exfat']
                    if len(exfatPartitions):
                        volumeNames = [p.get('label', None) for p in exfatPartitions]
                        volumeNames = " ".join([s for s in volumeNames if s is not None])
                        found.append(Drive(path, volumeNames))
            
            found.reverse()
            return found

class DriveThread(Thread):
    def __init__(self, drive, updatePath):
        super().__init__()
        self.drive = drive
        self.updatePath = updatePath
        self.statusError = False
        self.statusText = ''

    def run(self):
        try:
            if self.updatePath is not None:
                self.drive.open()
                self.checkFirmwareVersion()
                self.updateFirmware(self.updatePath)
                self.drive.eject()
                self.drive.close()
                self.statusText = f'Update completed'
            else:
                self.drive.open()
                version = self.checkFirmwareVersion()
                self.drive.close()
                self.statusText = f'Current firmware version is {version}'
        except:
            traceback.print_exc()
            self.statusText = traceback.format_exc()
            self.statusError = True

    def checkFirmwareVersion(self):
        logger.debug('Checking for firmware version...')
        self.drive.seek(0x400)
        gpt = self.drive.read(512)
        if gpt[0:16] != b'\xA2\xA0\xD0\xEB\xE5\xB9\x33\x44\x87\xC0\x68\xB6\xB7\x26\x99\xC7':
            raise Exception("GPT MS Data mismatch")

        self.drive.seek(OFFSET)
        blob = self.drive.read(SIZE)
        sector = blob[0:512]
        while len(blob) > 0:
            if sector != blob[0:512]:
                raise Exception("Unexpected data was read")
            blob = blob[512:]
        version = sector[0:16].decode("ascii")
        logger.debug(f'Firmware version is: {version}')
        return version
            
    def updateFirmware(self, updatePath):
        logger.debug(f'Reading update file {updatePath}')
        with open(updatePath,'rb') as file:
            fw = file.read(SIZE)

        logger.debug(f"Updating ({len(fw)} bytes)...")
        self.drive.seek(OFFSET)
        while len(fw) > 0:
            block = fw[0:512]
            fw = fw[512:]
            self.drive.write(block)

        logger.debug("Update completed")

    def isStatusError(self):
        return self.statusError
    def getStatusText(self):
        return self.statusText

class DeviceState(Enum):
    IDLE         = 1
    BUSY         = 2

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        if isLinuxPlatform():
            self.icon = tk.PhotoImage(file=iconPath)
            self.tk.call('wm', 'iconphoto', self._w, self.icon)
        else:
            self.iconbitmap(iconPath)
        self.isAdmin = isUserAdmin()
        self.style = ttk.Style(self)
        self.title('migupdater')
        self.windowFrame = ttk.Frame(self)
        self.windowFrame.pack(fill='both', ipadx=20,ipady=20, padx=30, pady=30)
        self.drives = []
        self.deviceState = DeviceState.IDLE

        frame = ttk.Frame(self.windowFrame)
        frame.pack(fill='x', pady=10, ipady=3)
        label = ttk.Label(frame, text='Select drive')
        label.pack(fill='x')


        self.drive_textvar = tk.StringVar(self)
        self.drive_combobox = ttk.Combobox(frame, state='readonly', textvariable=self.drive_textvar)
        self.drive_combobox.pack(expand=True, fill='x', ipadx=10, padx=10, side='left')
        self.btn_refresh = ttk.Button(frame, text='Refresh', command=self.refreshDevices)
        self.btn_refresh.pack(padx=10, side='left')

        frame = ttk.Frame(self.windowFrame)
        frame.pack(fill='x', pady=10, ipady=3)
        label = ttk.Label(frame, text='Select update file')
        label.pack(fill='x')
        self.updatefilename = tk.StringVar(self)
        self.updatefilename_entry = ttk.Entry(frame, textvariable=self.updatefilename)
        self.updatefilename_entry.pack(expand=True, fill='x', ipadx=10, padx=10, side='left')
        self.btn_browse = ttk.Button(frame, text='Browse', command=self.selectUpdateFile)
        self.btn_browse.pack(padx=10, side='left')
        
        frame = ttk.Frame(self.windowFrame)
        frame.pack(fill='x', pady=10, ipady=3)
        label = ttk.Label(frame, text='Select action')
        label.pack(fill='x')
        self.btn_fw_check = ttk.Button(frame, text='Check version', command=self.checkDevice)
        self.btn_fw_check.pack(padx=30, ipadx=10, ipady=10, side='left')
        self.btn_fw_update = ttk.Button(frame, text='Update', command=self.updateDevice)
        self.btn_fw_update.pack(padx=30, ipadx=10, ipady=10, side='right')

        self.bar = ttk.Progressbar(self.windowFrame, maximum=10, value=0)
        self.bar.pack(fill='both',ipady=10,pady=10)

        frame = ttk.Frame(self.windowFrame)
        frame.pack()
        self.photo = tk.PhotoImage(file=appdir + '/assets/logo.png')
        label = ttk.Label(frame, image=self.photo)
        label.pack()

    def updateState(self):
        for w in [self.btn_fw_update, self.btn_fw_check, self.btn_browse, self.updatefilename_entry]:
            w['state'] = 'normal' if self.deviceState == DeviceState.IDLE and len(self.drives) > 0 else 'disabled'

        for w in [self.btn_refresh]:
            w['state'] = 'disabled' if self.deviceState == DeviceState.BUSY else 'normal'

    def refreshDevices(self):
        if self.isAdmin:
            self.drives = findDrives()
        else:
            showerror("Error", message='This application needs to run as Administrator' if isWindowsPlatform() else 'This application needs to run with root permissions. Try with sudo.')
            self.drives = []
            
        if len(self.drives) == 0:
            self.drive_combobox['values'] = ['No devices found!']
            self.drive_combobox['state'] = 'disabled'
            for btn in [self.btn_fw_update, self.btn_fw_check, self.btn_browse, self.updatefilename_entry]:
                btn['state'] = 'disabled'
        else:
            self.drive_combobox['values'] = [x.getDisplayText() for x in self.drives]
            self.drive_combobox['state'] = 'readonly'
        idx = self.drive_combobox.current()
        if idx < 0 or idx >= len(self.drives):
            candidate = 0
            for i in range(len(self.drives)):
                d = self.drives[i]
                if d.isRemovable():
                    candidate = i
                    
            self.drive_combobox.current(candidate)
        self.updateState()
        
    def selectUpdateFile(self):
        filetypes = (
            ('S2 files', '*.s2'),
            ('All files', '*.*')
        )
        self.updatefilename.set(fd.askopenfilename(parent=self, title='Select update file', filetypes=filetypes))


    def checkDevice(self):
        self.performDevice(None)

    def updateDevice(self):
        update_path = self.updatefilename.get()
        if update_path == None or len(update_path) == 0:
            showerror("Error", message="Please select update file first")
            return
        
        self.performDevice(update_path)
        
    def performDevice(self, update_path):
        index = self.drive_combobox.current()
        if index >= len(self.drives):
            return
            
        drive = self.drives[index]
        if drive.isRemovable() == False:
            showerror("Error", message="Please select only usb devices from the list")
            return
        
        self.deviceState = DeviceState.BUSY
        self.updateState()
        thread = DriveThread(drive, update_path)
        thread.start()
        self.bar.start()
        self.monitor(thread)

    def monitor(self, thread):
            if thread.is_alive():
                self.after(100, lambda: self.monitor(thread))
            else:
                self.bar.stop()
                self.deviceState = DeviceState.IDLE
                self.refreshDevices()
                if thread.isStatusError():
                    showerror("Error", message=thread.getStatusText())
                else:
                    showinfo("Info", message=thread.getStatusText())

    def report_callback_exception(self, exc, val, tb):
        traceback.print_exc()
        s = traceback.format_exc()
        showerror("Error", message=s)

def main():
    app = App()
    app.update()
    app.minsize(app.winfo_width(), app.winfo_height())
    app.refreshDevices()
    app.mainloop()    

if __name__ == "__main__":
    if isUserAdmin():
        main()
    else:
        logger.warning("This application needs to run as root / Administrator")
        main()
