/*
 * keys.c
 *
 * Copyright (c) 2018-2020, SciresM.
 * Copyright (c) 2019, shchmue.
 * Copyright (c) 2020-2023, DarkMatterCore <pabloacurielz@gmail.com>.
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "utils.h"
#include "keys.h"

static bool keysDeriveGcCardInfoKey(void);

static bool g_keysetLoaded = false;
static Mutex g_keysetMutex = 0;

static const u8 g_gcCardInfoKekSource[AES_128_KEY_SIZE] = {
    0xDE, 0xC6, 0x3F, 0x6A, 0xBF, 0x37, 0x72, 0x0B, 0x7E, 0x54, 0x67, 0x6A, 0x2D, 0xEF, 0xDD, 0x97
};

static const u8 g_gcCardInfoKeySourceProd[AES_128_KEY_SIZE] = {
    0xF4, 0x92, 0x06, 0x52, 0xD6, 0x37, 0x70, 0xAF, 0xB1, 0x9C, 0x6F, 0x63, 0x09, 0x01, 0xF6, 0x29
};

static const u8 g_gcCardInfoKeySourceDev[AES_128_KEY_SIZE] = {
    0x54, 0xC3, 0xE1, 0xF2, 0x5B, 0x3A, 0x5E, 0xC0, 0x4C, 0xA7, 0xCF, 0xFB, 0xE1, 0xAE, 0x16, 0xCA
};

static u8 g_gcCardInfoKey[AES_128_KEY_SIZE] = {0};

bool keysLoadKeyset(void)
{
    bool ret = false;

    SCOPED_LOCK(&g_keysetMutex)
    {
        ret = g_keysetLoaded;
        if (ret) break;

        if (!keysDeriveGcCardInfoKey())
        {
            LOG_MSG_ERROR("Failed to derive gamecard CardInfo key!");
            break;
        }

        ret = g_keysetLoaded = true;
    }

    return ret;
}

const u8 *keysGetGameCardInfoKey(void)
{
    const u8 *ret = NULL;

    SCOPED_LOCK(&g_keysetMutex)
    {
        if (g_keysetLoaded) ret = (const u8*)g_gcCardInfoKey;
    }

    return ret;
}

static bool keysDeriveGcCardInfoKey(void) {
    Result res = 0;
    const u8 *key_src = (utilsIsDevelopmentUnit() ? g_gcCardInfoKeySourceDev : g_gcCardInfoKeySourceProd);
    u8 kek[AES_128_KEY_SIZE] = {0};

    res = splCryptoGenerateAesKek(g_gcCardInfoKekSource, 0, 0, kek);
    if (R_FAILED(res)) {
        LOG_MSG_ERROR("GenerateAesKek failed 0x%X", res);
        return false;
    }

    res = splCryptoGenerateAesKey(kek, key_src, g_gcCardInfoKey);
    if (R_FAILED(res)) {
        LOG_MSG_ERROR("GenerateAesKey failed 0x%X", res);
        return false;
    }

    return true;
}
