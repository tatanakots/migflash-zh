/*
 * utils.c
 *
 * Copyright (c) 2020-2023, DarkMatterCore <pabloacurielz@gmail.com>.
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include <sys/statvfs.h>
#include <turbojpeg.h>
#include <png.h>

#include "utils.h"
#include "keys.h"
#include "gamecard.h"
#include "services.h"
#include "usb.h"
#include "title.h"

#define FS_MAX_FILENAME_LENGTH 64

typedef struct {
    SdkAddOnVersion target_firmware;
    u8 key_generation;
    u8 ams_ver_micro;
    u8 ams_ver_minor;
    u8 ams_ver_major;
} UtilsExosphereApiVersion;

MDT_ASSERT(UtilsExosphereApiVersion, 0x8);

typedef struct {
    const u8 *buf;
    size_t buf_size;
    size_t pos;
} UtilsPngReadData;

/* Global variables. */

extern int __system_argc;
extern char **__system_argv;

static bool g_resourcesInit = false;
static Mutex g_resourcesMutex = 0;

static const char *g_appLaunchPath = NULL;

static FsFileSystem *g_sdCardFileSystem = NULL;

static int g_nxLinkSocketFd = -1;

static u8 g_customFirmwareType = UtilsCustomFirmwareType_Unknown;

static u8 g_productModel = SetSysProductModel_Invalid;

static bool g_isDevUnit = false;

static AppletType g_programAppletType = AppletType_None;

static AppletHookCookie g_systemOverclockCookie = {0};

static bool g_longRunningProcess = false;

static const char *g_sizeSuffixes[] = { "B", "KiB", "MiB", "GiB", "TiB" };
static const u32 g_sizeSuffixesCount = MAX_ELEMENTS(g_sizeSuffixes);

static const char g_illegalFileSystemChars[] = "\\/:*?\"<>|";
static const size_t g_illegalFileSystemCharsLength = (MAX_ELEMENTS(g_illegalFileSystemChars) - 1);

static PadState g_padState = {0};

static const SplConfigItem SplConfigItem_ExosphereApiVersion = (SplConfigItem)65000;

static UtilsExosphereApiVersion g_exosphereApiVersion = {0};

/* Function prototypes. */

static void _utilsGetLaunchPath(void);

static bool utilsGetExosphereApiVersion(void);

static void _utilsGetCustomFirmwareType(void);

static bool _utilsGetProductModel(void);

static bool _utilsIsDevelopmentUnit(void);

static void utilsOverclockSystem(bool overclock);
static void utilsOverclockSystemAppletHook(AppletHookType hook, void *param);

static void utilsChangeHomeButtonBlockStatus(bool block);

static size_t utilsGetUtf8StringLimit(const char *str, size_t str_size, size_t byte_limit);

static char utilsConvertHexDigitToBinary(char c);

static void utilsConfigureInput(void);

static void utilsPngErrorCallback(png_structp png_ptr, png_const_charp msg);
static void utilsPngWarningCallback(png_structp png_ptr, png_const_charp msg);
static void utilsPngReadCallback(png_structp png_ptr, png_bytep rd_buf, size_t rd_size);

bool utilsInitializeResources(void)
{
    Result rc = 0;
    bool ret = false;

    SCOPED_LOCK(&g_resourcesMutex)
    {
        ret = g_resourcesInit;
        if (ret) break;

        utilsConfigureInput();

        /* Lock applet exit. */
        appletLockExit();

        /* Retrieve pointer to the application launch path. */
        _utilsGetLaunchPath();

        /* Retrieve pointer to the SD card FsFileSystem element. */
        if (!(g_sdCardFileSystem = fsdevGetDeviceFileSystem(DEVOPTAB_SDMC_DEVICE)))
        {
            LOG_MSG_ERROR("Failed to retrieve FsFileSystem object for the SD card!");
            break;
        }

        /* Initialize needed services. */
        if (!servicesInitialize()) break;

        /* Check if a valid nxlink host IP address was set by libnx. */
        /* If so, initialize nxlink connection without redirecting stdout and/or stderr. */
        if (__nxlink_host.s_addr != 0 && __nxlink_host.s_addr != INADDR_NONE) g_nxLinkSocketFd = nxlinkConnectToHost(false, false);

#if LOG_LEVEL <= LOG_LEVEL_INFO
        /* Log info messages. */
        u32 hos_version = hosversionGet();
        LOG_MSG_INFO(APP_TITLE " v" APP_VERSION " starting. Built on " BUILD_TIMESTAMP ".");
        if (g_nxLinkSocketFd >= 0) LOG_MSG_INFO("nxlink enabled! Host IP address: %s.", inet_ntoa(__nxlink_host));
        LOG_MSG_INFO("Horizon OS version: %u.%u.%u.", HOSVER_MAJOR(hos_version), HOSVER_MINOR(hos_version), HOSVER_MICRO(hos_version));
#endif

        /* Retrieve Exosphère API version. */
        if (!utilsGetExosphereApiVersion())
        {
            LOG_MSG_ERROR("Failed to retrieve Exosphère API version!");
            break;
        }

        /* Retrieve custom firmware type. */
        _utilsGetCustomFirmwareType();
        if (g_customFirmwareType != UtilsCustomFirmwareType_Unknown) LOG_MSG_INFO("Detected %s CFW.", (g_customFirmwareType == UtilsCustomFirmwareType_Atmosphere ? "Atmosphère" : \
                                                                                  (g_customFirmwareType == UtilsCustomFirmwareType_SXOS ? "SX OS" : "ReiNX")));

        LOG_MSG_INFO("Exosphère API version info:\r\n" \
                     "- Release version: %u.%u.%u.\r\n" \
                     "- PKG1 key generation: %u (0x%02X).\r\n" \
                     "- Target firmware: %u.%u.%u.", \
                     g_exosphereApiVersion.ams_ver_major, g_exosphereApiVersion.ams_ver_minor, g_exosphereApiVersion.ams_ver_micro, \
                     g_exosphereApiVersion.key_generation, !g_exosphereApiVersion.key_generation ? g_exosphereApiVersion.key_generation : (g_exosphereApiVersion.key_generation + 1), \
                     g_exosphereApiVersion.target_firmware.major, g_exosphereApiVersion.target_firmware.minor, g_exosphereApiVersion.target_firmware.micro);

        /* Get product model. */
        if (!_utilsGetProductModel()) break;

        /* Get development unit flag. */
        if (!_utilsIsDevelopmentUnit()) break;

        /* Get applet type. */
        g_programAppletType = appletGetAppletType();

        LOG_MSG_INFO("Running under %s %s unit in %s mode.", g_isDevUnit ? "development" : "retail", utilsIsMarikoUnit() ? "Mariko" : "Erista", utilsIsAppletMode() ? "applet" : "title override");

        if (g_appLaunchPath) LOG_MSG_INFO("Launch path: \"%s\".", g_appLaunchPath);

        /* Initialize USB interface. */
        if (!usbInitialize()) break;

        /* Initialize USB Mass Storage interface. */
        if (!umsInitialize()) break;

        /* Load keyset. */
        if (!keysLoadKeyset()) break;

        /* Initialize gamecard interface. */
        if (!gamecardInitialize()) break;

        /* Initialize title interface. */
        if (!titleInitialize()) break;

        /* Mount application RomFS. */
        rc = romfsInit();
        if (R_FAILED(rc))
        {
            LOG_MSG_ERROR("Failed to mount " APP_TITLE "'s RomFS container!");
            break;
        }

        /* Initialize configuration interface. */
        if (!configInitialize()) break;

        /* Setup an applet hook to change the hardware clocks after a system mode change (docked <-> undocked). */
        appletHook(&g_systemOverclockCookie, utilsOverclockSystemAppletHook, NULL);

        /* Enable video recording if we're running under title override mode. */
        if (!utilsIsAppletMode())
        {
            bool flag = false;
            rc = appletIsGamePlayRecordingSupported(&flag);
            if (R_SUCCEEDED(rc) && flag)
            {
                rc = appletInitializeGamePlayRecording();
                if (R_FAILED(rc)) LOG_MSG_ERROR("appletInitializeGamePlayRecording failed! (0x%X).", rc);
            } else {
                LOG_MSG_ERROR("appletIsGamePlayRecordingSupported returned [0x%X, %u].", rc, flag);
            }
        }

        if (!menu_init()) break;

        /* Update flags. */
        ret = g_resourcesInit = true;
    }

    if (!ret)
    {
        char *msg = NULL;
        size_t msg_size = 0;

        /* Generate error message. */
        utilsAppendFormattedStringToBuffer(&msg, &msg_size, "An error occurred while initializing resources.");

#if LOG_LEVEL <= LOG_LEVEL_ERROR
        /* Get last log message. */
        char *log_msg = logGetLastMessage();
        if (log_msg)
        {
            utilsAppendFormattedStringToBuffer(&msg, &msg_size, "\n\n%s", log_msg);
            free(log_msg);
        }
#endif

        /* Print error message. */
        utilsPrintConsoleError(msg);

        /* Free error message. */
        if (msg) free(msg);
    }

    return ret;
}

void utilsCloseResources(void)
{
    SCOPED_LOCK(&g_resourcesMutex)
    {
        LOG_MSG_INFO("Shutting down...");

        /* Unset long running process state. */
        utilsSetLongRunningProcessState(false);

        /* Unset our overclock applet hook. */
        appletUnhook(&g_systemOverclockCookie);

        menu_deinit();

        /* Close configuration interface. */
        configExit();

        /* Unmount application RomFS. */
        romfsExit();

        /* Deinitialize title interface. */
        titleExit();

        /* Deinitialize gamecard interface. */
        gamecardExit();

        /* Close USB Mass Storage interface. */
        umsExit();

        /* Close USB interface. */
        usbExit();

        /* Close nxlink socket. */
        if (g_nxLinkSocketFd >= 0)
        {
            close(g_nxLinkSocketFd);
            g_nxLinkSocketFd = -1;
        }

        /* Close initialized services. */
        servicesClose();

#if LOG_LEVEL <= LOG_LEVEL_ERROR
        /* Close logfile. */
        logCloseLogFile();
#endif

        /* Unlock applet exit. */
        appletUnlockExit();

        g_resourcesInit = false;
    }
}

const char *utilsGetLaunchPath(void)
{
    return g_appLaunchPath;
}

int utilsGetNxLinkFileDescriptor(void)
{
    return g_nxLinkSocketFd;
}

FsFileSystem *utilsGetSdCardFileSystemObject(void)
{
    return g_sdCardFileSystem;
}

bool utilsCommitSdCardFileSystemChanges(void)
{
    return (g_sdCardFileSystem ? R_SUCCEEDED(fsFsCommit(g_sdCardFileSystem)) : false);
}

u32 utilsGetAtmosphereVersion(void)
{
    return MAKEHOSVERSION(g_exosphereApiVersion.ams_ver_major, g_exosphereApiVersion.ams_ver_minor, g_exosphereApiVersion.ams_ver_micro);
}

u8 utilsGetAtmosphereKeyGeneration(void)
{
    return g_exosphereApiVersion.key_generation;
}

void utilsGetAtmosphereTargetFirmware(SdkAddOnVersion *out)
{
    memcpy(out, &(g_exosphereApiVersion.target_firmware), sizeof(SdkAddOnVersion));
}

u8 utilsGetCustomFirmwareType(void)
{
    return g_customFirmwareType;
}

bool utilsIsMarikoUnit(void)
{
    return (g_productModel > SetSysProductModel_Copper);
}

bool utilsIsDevelopmentUnit(void)
{
    return g_isDevUnit;
}

bool utilsIsAppletMode(void)
{
    return (g_programAppletType > AppletType_Application && g_programAppletType < AppletType_SystemApplication);
}

void utilsSetLongRunningProcessState(bool state)
{
    SCOPED_LOCK(&g_resourcesMutex)
    {
        /* Don't proceed if resources haven't been initialized, or if the requested state matches the current one. */
        if (!g_resourcesInit || state == g_longRunningProcess) break;

        /* Change HOME button block status. */
        utilsChangeHomeButtonBlockStatus(state);

        /* Enable/disable screen dimming and auto sleep. */
        appletSetMediaPlaybackState(state);

        /* Enable/disable system overclock. */
        utilsOverclockSystem(configGetBoolean("overclock") & state);

        /* Update flag. */
        g_longRunningProcess = state;
    }
}

bool utilsCreateThread(Thread *out_thread, ThreadFunc func, void *arg, int cpu_id)
{
    /* Core 3 is reserved for HOS, so we can only use cores 0, 1 and 2. */
    /* -2 can be provided to use the default process core. */
    if (!out_thread || !func || (cpu_id < 0 && cpu_id != -2) || cpu_id > 2)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    Result rc = 0;
    u64 core_mask = 0;
    size_t stack_size = 0x20000; /* Same value as libnx's newlib. */
    bool success = false;

    memset(out_thread, 0, sizeof(Thread));

    /* Get process core mask. */
    rc = svcGetInfo(&core_mask, InfoType_CoreMask, CUR_PROCESS_HANDLE, 0);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("svcGetInfo failed! (0x%X).", rc);
        goto end;
    }

    /* Create thread. */
    /* Enable preemptive multithreading by using priority 0x3B. */
    rc = threadCreate(out_thread, func, arg, NULL, stack_size, 0x3B, cpu_id);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("threadCreate failed! (0x%X).", rc);
        goto end;
    }

    /* Set thread core mask. */
    rc = svcSetThreadCoreMask(out_thread->handle, cpu_id == -2 ? -1 : cpu_id, core_mask);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("svcSetThreadCoreMask failed! (0x%X).", rc);
        goto end;
    }

    /* Start thread. */
    rc = threadStart(out_thread);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("threadStart failed! (0x%X).", rc);
        goto end;
    }

    success = true;

end:
    if (!success && out_thread->handle != INVALID_HANDLE) threadClose(out_thread);

    return success;
}

void utilsJoinThread(Thread *thread)
{
    if (!thread || thread->handle == INVALID_HANDLE)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return;
    }

    Result rc = threadWaitForExit(thread);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("threadWaitForExit failed! (0x%X).", rc);
        return;
    }

    threadClose(thread);

    memset(thread, 0, sizeof(Thread));
}

__attribute__((format(printf, 3, 4))) bool utilsAppendFormattedStringToBuffer(char **dst, size_t *dst_size, const char *fmt, ...)
{
    bool use_log = false;
    SCOPED_LOCK(&g_resourcesMutex) use_log = g_resourcesInit;

    if (!dst || !dst_size || !fmt || !*fmt)
    {
        if (use_log) LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    va_list args;

    int formatted_str_len = 0;
    size_t formatted_str_len_cast = 0;

    char *dst_ptr = *dst, *tmp_str = NULL;
    size_t dst_cur_size = *dst_size, dst_str_len = (dst_ptr ? strlen(dst_ptr) : 0);

    bool success = false;

    /* Sanity check. */
    if (dst_cur_size && dst_str_len >= dst_cur_size)
    {
        if (use_log) LOG_MSG_ERROR("String length is equal to or greater than the provided buffer size! (0x%lX >= 0x%lX).", dst_str_len, dst_cur_size);
        return false;
    }

    va_start(args, fmt);

    /* Get formatted string length. */
    formatted_str_len = vsnprintf(NULL, 0, fmt, args);
    if (formatted_str_len <= 0)
    {
        if (use_log) LOG_MSG_ERROR("Failed to retrieve formatted string length!");
        goto end;
    }

    formatted_str_len_cast = (size_t)(formatted_str_len + 1);

    if (!dst_ptr || !dst_cur_size || formatted_str_len_cast > (dst_cur_size - dst_str_len))
    {
        /* Update buffer size. */
        dst_cur_size = (dst_str_len + formatted_str_len_cast);

        /* Reallocate buffer. */
        tmp_str = realloc(dst_ptr, dst_cur_size);
        if (!tmp_str)
        {
            if (use_log) LOG_MSG_ERROR("Failed to resize buffer to 0x%lX byte(s).", dst_cur_size);
            goto end;
        }

        dst_ptr = tmp_str;
        tmp_str = NULL;

        /* Clear allocated area. */
        memset(dst_ptr + dst_str_len, 0, formatted_str_len_cast);

        /* Update pointers. */
        *dst = dst_ptr;
        *dst_size = dst_cur_size;
    }

    /* Generate formatted string. */
    vsprintf(dst_ptr + dst_str_len, fmt, args);

    /* Update output flag. */
    success = true;

end:
    va_end(args);

    return success;
}

void utilsReplaceIllegalCharacters(char *str, bool ascii_only)
{
    size_t str_size = 0, cur_pos = 0;

    if (!str || !(str_size = strlen(str))) return;

    u8 *ptr1 = (u8*)str, *ptr2 = ptr1;
    ssize_t units = 0;
    u32 code = 0;
    bool repl = false;

    while(cur_pos < str_size)
    {
        units = decode_utf8(&code, ptr1);
        if (units < 0) break;

        if (memchr(g_illegalFileSystemChars, (int)code, g_illegalFileSystemCharsLength) || code < 0x20 || (!ascii_only && code == 0x7F) || (ascii_only && code >= 0x7F))
        {
            if (!repl)
            {
                *ptr2++ = '_';
                repl = true;
            }
        } else {
            if (ptr2 != ptr1) memmove(ptr2, ptr1, (size_t)units);
            ptr2 += units;
            repl = false;
        }

        ptr1 += units;
        cur_pos += (size_t)units;
    }

    *ptr2 = '\0';
}

void utilsTrimString(char *str)
{
    size_t strsize = 0;
    char *start = NULL, *end = NULL;

    if (!str || !(strsize = strlen(str))) return;

    start = str;
    end = (start + strsize);

    while(--end >= start)
    {
        if (!isspace((unsigned char)*end)) break;
    }

    *(++end) = '\0';

    while(isspace((unsigned char)*start)) start++;

    if (start != str) memmove(str, start, end - start + 1);
}

void utilsGenerateHexString(char *dst, size_t dst_size, const void *src, size_t src_size, bool uppercase)
{
    if (!src || !src_size || !dst || dst_size < ((src_size * 2) + 1)) return;

    size_t i, j;
    const u8 *src_u8 = (const u8*)src;

    for(i = 0, j = 0; i < src_size; i++)
    {
        char h_nib = ((src_u8[i] >> 4) & 0xF);
        char l_nib = (src_u8[i] & 0xF);

        dst[j++] = (h_nib + (h_nib < 0xA ? 0x30 : (uppercase ? 0x37 : 0x57)));
        dst[j++] = (l_nib + (l_nib < 0xA ? 0x30 : (uppercase ? 0x37 : 0x57)));
    }

    dst[j] = '\0';
}

bool utilsParseHexString(void *dst, size_t dst_size, const char *src, size_t src_size)
{
    u8 *dst_u8 = (u8*)dst;
    bool success = true;

    if (!dst || !dst_size || !src || !*src || (!src_size && !(src_size = strlen(src))) || (src_size % 2) != 0 || dst_size < (src_size / 2))
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    memset(dst, 0, dst_size);

    for(size_t i = 0; i < src_size; i++)
    {
        char val = utilsConvertHexDigitToBinary(src[i]);
        if (val == 'z')
        {
            LOG_MSG_ERROR("Invalid hex character in string \"%s\" at position %lu!", src, i);
            success = false;
            break;
        }

        if ((i & 1) == 0) val <<= 4;
        dst_u8[i >> 1] |= val;
    }

    return success;
}

void utilsGenerateFormattedSizeString(double size, char *dst, size_t dst_size)
{
    if (!dst || dst_size < 2) return;

    size = fabs(size);

    for(u32 i = 0; i < g_sizeSuffixesCount; i++)
    {
        if (size >= pow(1024.0, i + 1) && (i + 1) < g_sizeSuffixesCount) continue;

        size /= pow(1024.0, i);

        /* Don't display decimal places if we're dealing with plain bytes. */
        snprintf(dst, dst_size, "%.*f %s", i == 0 ? 0 : 2, size, g_sizeSuffixes[i]);

        break;
    }
}

bool utilsGetFileSystemStatsByPath(const char *path, u64 *out_total, u64 *out_free)
{
    char *name_end = NULL, stat_path[32] = {0};
    struct statvfs info = {0};
    int ret = -1;

    if (!path || !*path || !(name_end = strchr(path, ':')) || *(name_end + 1) != '/' || (!out_total && !out_free))
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    name_end += 2;
    sprintf(stat_path, "%.*s", (int)(name_end - path), path);

    if ((ret = statvfs(stat_path, &info)) != 0)
    {
        LOG_MSG_ERROR("statvfs failed for \"%s\"! (%d) (errno: %d).", stat_path, ret, errno);
        return false;
    }

    if (out_total) *out_total = ((u64)info.f_blocks * (u64)info.f_frsize);
    if (out_free) *out_free = ((u64)info.f_bfree * (u64)info.f_frsize);

    return true;
}

bool utilsCheckIfFileExists(const char *path)
{
    if (!path || !*path) return false;

    FILE *chkfile = fopen(path, "rb");
    if (chkfile)
    {
        fclose(chkfile);
        return true;
    }

    return false;
}

void utilsRemoveConcatenationFile(const char *path)
{
    if (!path || !*path) return;
    remove(path);
    fsdevDeleteDirectoryRecursively(path);
}

bool utilsCreateConcatenationFile(const char *path)
{
    if (!path || !*path)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    /* Safety measure: remove any existant file/directory at the destination path. */
    utilsRemoveConcatenationFile(path);

    /* Create ConcatenationFile. */
    /* If the call succeeds, the caller function will be able to operate on this file using stdio calls. */
    Result rc = fsdevCreateFile(path, 0, FsCreateOption_BigFile);
    if (R_FAILED(rc)) LOG_MSG_ERROR("fsdevCreateFile failed for \"%s\"! (0x%X).", path, rc);

    return R_SUCCEEDED(rc);
}

void utilsCreateDirectoryTree(const char *path, bool create_last_element)
{
    char *ptr = NULL, *tmp = NULL;
    size_t path_len = 0;

    if (!path || !(path_len = strlen(path))) return;

    tmp = calloc(path_len + 1, sizeof(char));
    if (!tmp) return;

    ptr = strchr(path, '/');
    while(ptr)
    {
        sprintf(tmp, "%.*s", (int)(ptr - path), path);
        mkdir(tmp, 0777);
        ptr = strchr(++ptr, '/');
    }

    if (create_last_element) mkdir(path, 0777);

    free(tmp);
}

bool utilsGetDirectorySize(const char *path, u64 *out_size)
{
    u64 total_size = 0;
    char *name_end = NULL, *entry_path = NULL;
    DIR *dir = NULL;
    struct dirent *entry = NULL;
    struct stat st = {0};
    bool success = false;

    /* Sanity checks. */
    if (!path || !*path || !(name_end = strchr(path, ':')) || *(name_end + 1) != '/' || !*(name_end + 2) || !out_size)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    if (!(dir = opendir(path)))
    {
        LOG_MSG_ERROR("Failed to open directory \"%s\"! (%d).", path, errno);
        goto end;
    }

    if (!(entry_path = calloc(1, FS_MAX_PATH)))
    {
        LOG_MSG_ERROR("Failed to allocate memory for path buffer!");
        goto end;
    }

    /* Read directory entries. */
    while((entry = readdir(dir)))
    {
        /* Skip current directory and parent directory entries. */
        if (!strcmp(".", entry->d_name) || !strcmp("..", entry->d_name)) continue;

        /* Generate path to the current entry. */
        snprintf(entry_path, FS_MAX_PATH, "%s/%s", path, entry->d_name);

        if (entry->d_type == DT_DIR)
        {
            /* Get directory size. */
            u64 dir_size = 0;
            if (!utilsGetDirectorySize(entry_path, &dir_size)) goto end;

            /* Update size. */
            total_size += dir_size;
        } else {
            /* Get file properties. */
            if (stat(entry_path, &st) != 0)
            {
                LOG_MSG_ERROR("Failed to stat file \"%s\"! (%d).", entry_path, errno);
                goto end;
            }

            /* Update size. */
            total_size += st.st_size;
        }
    }

    /* Update output pointer. */
    *out_size = total_size;

    /* Update return value. */
    success = true;

end:
    if (entry_path) free(entry_path);

    if (dir) closedir(dir);

    return success;
}

bool utilsDeleteDirectoryRecursively(const char *path)
{
    char *name_end = NULL, *entry_path = NULL;
    DIR *dir = NULL;
    struct dirent *entry = NULL;
    bool success = false;

    /* Sanity checks. */
    if (!path || !*path || !(name_end = strchr(path, ':')) || *(name_end + 1) != '/' || !*(name_end + 2))
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    if (!(dir = opendir(path)))
    {
        LOG_MSG_ERROR("Failed to open directory \"%s\"! (%d).", path, errno);
        goto end;
    }

    if (!(entry_path = calloc(1, FS_MAX_PATH)))
    {
        LOG_MSG_ERROR("Failed to allocate memory for path buffer!");
        goto end;
    }

    /* Read directory entries. */
    while((entry = readdir(dir)))
    {
        int status = 0;

        /* Skip current directory and parent directory entries. */
        if (!strcmp(".", entry->d_name) || !strcmp("..", entry->d_name)) continue;

        /* Generate path to the current entry. */
        snprintf(entry_path, FS_MAX_PATH, "%s/%s", path, entry->d_name);

        if (entry->d_type == DT_DIR)
        {
            /* Delete directory contents. */
            if (!utilsDeleteDirectoryRecursively(entry_path)) goto end;

            /* Delete directory. */
            status = rmdir(entry_path);
        } else {
            /* Delete file. */
            status = unlink(entry_path);
        }

        if (status != 0)
        {
            LOG_MSG_ERROR("Failed to delete %s \"%s\"! (%d).", entry->d_type == DT_DIR ? "directory" : "file", entry_path, errno);
            goto end;
        }
    }

    /* Close topmost directory so we can delete it. */
    closedir(dir);
    dir = NULL;

    success = (rmdir(path) == 0);
    if (!success) LOG_MSG_ERROR("Failed to delete topmost directory \"%s\"! (%d).", path, errno);

end:
    if (entry_path) free(entry_path);

    if (dir) closedir(dir);

    return success;
}

char *utilsGeneratePath(const char *prefix, const char *filename, const char *extension)
{
    if (!filename || !*filename)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    bool use_prefix = (prefix && *prefix);
    size_t prefix_len = (use_prefix ? strlen(prefix) : 0);
    bool append_path_sep = (use_prefix && prefix[prefix_len - 1] != '/' && *filename != '/');

    bool use_extension = (extension && *extension);
    size_t extension_len = (use_extension ? strlen(extension) : 0);

    size_t path_len = (prefix_len + strlen(filename) + extension_len);
    if (append_path_sep) path_len++;

    char *path = NULL, *ptr1 = NULL, *ptr2 = NULL;
    bool filename_only = false, success = false;

    /* Allocate memory for the output path. */
    if (!(path = calloc(path_len + 1, sizeof(char))))
    {
        LOG_MSG_ERROR("Failed to allocate 0x%lX bytes for output path!", path_len);
        goto end;
    }

    /* Generate output path. */
    if (use_prefix) strcat(path, prefix);
    if (append_path_sep) strcat(path, "/");
    strcat(path, filename);
    if (use_extension) strcat(path, extension);

    /* Retrieve pointer to the first path separator. */
    ptr1 = strchr(path, '/');
    if (!ptr1)
    {
        filename_only = true;
        ptr1 = path;
    }

    /* Make sure each path element doesn't exceed our max filename length. */
    while(ptr1)
    {
        if (!filename_only)
        {
            /* End loop if we find a NULL terminator. */
            if (!*ptr1++) break;

            /* Get pointer to next path separator. */
            ptr2 = strchr(ptr1, '/');
        }

        /* Get current path element size. */
        size_t element_size = (ptr2 ? (size_t)(ptr2 - ptr1) : (path_len - (size_t)(ptr1 - path)));

        /* Get UTF-8 string limit. */
        /* Use our max filename length as the byte count limit. */
        size_t last_cp_pos = utilsGetUtf8StringLimit(ptr1, element_size, FS_MAX_FILENAME_LENGTH);
        if (last_cp_pos < element_size)
        {
            if (ptr2)
            {
                /* Truncate current element by moving the rest of the path to the current position. */
                memmove(ptr1 + last_cp_pos, ptr2, path_len - (size_t)(ptr2 - path));

                /* Update pointer. */
                ptr2 -= (element_size - last_cp_pos);
            } else
            if (use_extension)
            {
                /* Truncate last element. Make sure to preserve the provided file extension. */
                if (extension_len >= last_cp_pos)
                {
                    LOG_MSG_ERROR("File extension length is >= truncated filename length! (0x%lX >= 0x%lX).", extension_len, last_cp_pos);
                    goto end;
                }

                memmove(ptr1 + last_cp_pos - extension_len, ptr1 + element_size - extension_len, extension_len);
            }

            path_len -= (element_size - last_cp_pos);
            path[path_len] = '\0';
        }

        ptr1 = ptr2;
    }

    /* Check if the full length for the generated path is >= FS_MAX_PATH. */
    if (path_len >= FS_MAX_PATH)
    {
        LOG_MSG_ERROR("Generated path length is >= FS_MAX_PATH! (0x%lX).", path_len);
        goto end;
    }

    /* Update flag. */
    success = true;

end:
    if (!success && path)
    {
        free(path);
        path = NULL;
    }

    return path;
}

void utilsPrintConsoleError(const char *msg)
{
    /* Initialize console output. */
    consoleInit(NULL);

    /* Print message. */
    if (msg && *msg)
    {
        printf("%s", msg);
    } else {
        printf("An error occurred.");
    }

#if LOG_LEVEL < LOG_LEVEL_NONE
    printf("\n\nFor more information, please check the logfile. Press any button to exit.");
#else
    printf("\n\nPress any button to exit.");
#endif

    consoleUpdate(NULL);

    /* Wait until the user presses a button. */
    utilsWaitForButtonPress(0);

    /* Deinitialize console output. */
    consoleExit(NULL);
}

void utilsScanPads(void)
{
    SCOPED_LOCK(&g_resourcesMutex) padUpdate(&g_padState);
}

u64 utilsGetButtonsDown(void)
{
    u64 ret = 0;
    SCOPED_LOCK(&g_resourcesMutex) ret = padGetButtonsDown(&g_padState);
    return ret;
}

u64 utilsGetButtonsHeld(void)
{
    u64 ret = 0;
    SCOPED_LOCK(&g_resourcesMutex) ret = padGetButtons(&g_padState);
    return ret;
}

u64 utilsWaitForButtonPress(u64 flag)
{
    u64 ret = 0;

    /* Don't consider stick movement as button inputs. */
    if (!flag) flag = ~(HidNpadButton_StickLLeft | HidNpadButton_StickLRight | HidNpadButton_StickLUp | HidNpadButton_StickLDown | HidNpadButton_StickRLeft | HidNpadButton_StickRRight | \
                        HidNpadButton_StickRUp | HidNpadButton_StickRDown);

    while(appletMainLoop())
    {
        utilsScanPads();
        if ((ret = utilsGetButtonsDown()) & flag) break;
        utilsAppletLoopDelay();
    }

    return ret;
}

u8 *utilsLoadFileToMemory(const char *path, size_t *out_size) {
    if (!path || !*path || !out_size) {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    FILE *fp = NULL;
    size_t fsize = 0;
    u8 *buf = NULL;

    fp = fopen(path, "rb");
    if (!fp) {
        LOG_MSG_ERROR("Failed to open %s", path);
        goto out;
    }

    fseek(fp, 0, SEEK_END);
    fsize = ftell(fp);
    rewind(fp);

    if (!fsize) {
        LOG_MSG_ERROR("File %s is empty", path);
        goto out;
    }

    buf = malloc(fsize);
    if (!buf) {
        LOG_MSG_ERROR("Failed to allocate memory for file data");
        goto out;
    }

    if (fread(buf, 1, fsize, fp) == fsize) {
        *out_size = fsize;
    } else {
        LOG_MSG_ERROR("Error reading file data");
        free(buf);
        buf = NULL;
    }

out:
    if (fp) fclose(fp);

    return buf;
}

u8 *utilsLoadRgba8888ImageFromJpegBuffer(const void *jpeg_buf, size_t jpeg_buf_size, int *out_w, int *out_h) {
    if (!jpeg_buf || !jpeg_buf_size || !out_w || !out_h) {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    tjhandle jpeg_dec = NULL;
    int tj_res = 0, w = 0, h = 0, pitch = 0;
    u8 *rgb888_img = NULL;

    jpeg_dec = tjInitDecompress();
    if (!jpeg_dec) {
        LOG_MSG_ERROR("tjInitDecompress failed: %s", tjGetErrorStr2(NULL));
        goto out;
    }

    tj_res = tjDecompressHeader(jpeg_dec, (u8*)jpeg_buf, jpeg_buf_size, &w, &h);
    if (tj_res != 0) {
        LOG_MSG_ERROR("tjInitDecompress failed: %s", tjGetErrorStr2(jpeg_dec));
        goto out;
    }

    pitch = TJPAD(w * tjPixelSize[TJPF_RGBA]);

    rgb888_img = malloc(pitch * h);
    if (!rgb888_img) {
        LOG_MSG_ERROR("Failed to allocate RGBA buffer");
        goto out;
    }

    tj_res = tjDecompress2(jpeg_dec, jpeg_buf, jpeg_buf_size, (u8*)rgb888_img, w, pitch, h, TJPF_RGBA, TJFLAG_ACCURATEDCT);
    if (tj_res == 0) {
        *out_w = w;
        *out_h = h;
    } else {
        LOG_MSG_ERROR("tjDecompress2 failed: %s", tjGetErrorStr2(jpeg_dec));
        free(rgb888_img);
        rgb888_img = NULL;
    }

out:
    if (jpeg_dec) tjDestroy(jpeg_dec);

    return rgb888_img;
}

u8 *utilsLoadRgba8888ImageFromJpegFile(const char *path, int *out_w, int *out_h) {
    if (!path || !*path || !out_w || !out_h) {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    u8 *jpeg_buf = NULL;
    size_t jpeg_size = 0;

    u8 *rgba8888_img = NULL;

    jpeg_buf = utilsLoadFileToMemory(path, &jpeg_size);
    if (jpeg_buf) {
        rgba8888_img = utilsLoadRgba8888ImageFromJpegBuffer(jpeg_buf, jpeg_size, out_w, out_h);
        free(jpeg_buf);
    }

    return rgba8888_img;
}

u8 *utilsLoadRgba8888ImageFromPngBuffer(const void *png_buf, size_t png_buf_size, int *out_w, int *out_h) {
    if (!png_buf || !png_buf_size || !out_w || !out_h) {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    png_structp png_ptr = NULL;
    png_infop info_ptr = NULL;

    UtilsPngReadData png_rd_data = {0};

    u32 w = 0, h = 0;
    int bit_depth = 0, color_type = 0;

    size_t row_size = 0;

    u8 *rgba8888_img = NULL;

    if (!png_check_sig((const u8*)png_buf, 8)) {
        LOG_MSG_ERROR("png_check_sig failed");
        goto out;
    }

    png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, &utilsPngErrorCallback, &utilsPngWarningCallback);
    if (!png_ptr) {
        LOG_MSG_ERROR("png_create_read_struct failed");
        goto out;
    }

    info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr) {
        LOG_MSG_ERROR("png_create_info_struct failed");
        goto out;
    }

    png_rd_data.buf = (const u8*)png_buf;
    png_rd_data.buf_size = png_buf_size;
    png_rd_data.pos = 8;

    png_set_read_fn(png_ptr, &png_rd_data, &utilsPngReadCallback);

    png_set_sig_bytes(png_ptr, 8);

    png_read_info(png_ptr, info_ptr);

    png_get_IHDR(png_ptr, info_ptr, &w, &h, &bit_depth, &color_type, NULL, NULL, NULL);

    if (color_type == PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(png_ptr);

    if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) png_set_expand_gray_1_2_4_to_8(png_ptr);

    if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(png_ptr);

    if (bit_depth == 16) png_set_scale_16(png_ptr);

    if (!(color_type & PNG_COLOR_MASK_ALPHA)) png_set_add_alpha(png_ptr, 0xFF, PNG_FILLER_AFTER);

    png_set_interlace_handling(png_ptr);

    png_read_update_info(png_ptr, info_ptr);

    row_size = png_get_rowbytes(png_ptr, info_ptr);

    rgba8888_img = calloc(row_size * h, sizeof(u8));
    if (!rgba8888_img) {
        LOG_MSG_ERROR("rgba8888_img calloc failed");
        goto out;
    }

    for(u32 row = 0; row < h; row++) png_read_row(png_ptr, rgba8888_img + (row_size * row), NULL);

    *out_w = (int)w;
    *out_h = (int)h;

out:
    if (png_ptr || info_ptr) png_destroy_read_struct(png_ptr ? &png_ptr : NULL, info_ptr ? &info_ptr : NULL, NULL);

    return rgba8888_img;
}

u8 *utilsLoadRgba8888ImageFromPngFile(const char *path, int *out_w, int *out_h) {
    if (!path || !*path || !out_w || !out_h) {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    u8 *png_buf = NULL;
    size_t png_size = 0;

    u8 *rgba8888_img = NULL;

    png_buf = utilsLoadFileToMemory(path, &png_size);
    if (png_buf) {
        rgba8888_img = utilsLoadRgba8888ImageFromPngBuffer(png_buf, png_size, out_w, out_h);
        free(png_buf);
    }

    return rgba8888_img;
}

static void _utilsGetLaunchPath(void)
{
    if (__system_argc <= 0 || !__system_argv) return;

    for(int i = 0; i < __system_argc; i++)
    {
        if (__system_argv[i] && !strncmp(__system_argv[i], DEVOPTAB_SDMC_DEVICE "/", strlen(DEVOPTAB_SDMC_DEVICE)))
        {
            g_appLaunchPath = __system_argv[i];
            break;
        }
    }
}

/* SMC config item available in Atmosphère and Atmosphère-based CFWs. */
static bool utilsGetExosphereApiVersion(void)
{
    Result rc = splGetConfig(SplConfigItem_ExosphereApiVersion, (u64*)&g_exosphereApiVersion);
    bool ret = R_SUCCEEDED(rc);
    if (!ret) LOG_MSG_ERROR("splGetConfig failed! (0x%X).", rc);
    return ret;
}

static void _utilsGetCustomFirmwareType(void)
{
    bool tx_srv = servicesCheckRunningServiceByName("tx");
    bool rnx_srv = servicesCheckRunningServiceByName("rnx");

    g_customFirmwareType = (rnx_srv ? UtilsCustomFirmwareType_ReiNX : (tx_srv ? UtilsCustomFirmwareType_SXOS : UtilsCustomFirmwareType_Atmosphere));
}

static bool _utilsGetProductModel(void)
{
    Result rc = 0;
    bool ret = false;
    SetSysProductModel model = SetSysProductModel_Invalid;

    rc = setsysGetProductModel(&model);
    if (R_SUCCEEDED(rc) && model != SetSysProductModel_Invalid)
    {
        g_productModel = model;
        ret = true;
    } else {
        LOG_MSG_ERROR("setsysGetProductModel failed! (0x%X) (%d).", rc, model);
    }

    return ret;
}

static bool _utilsIsDevelopmentUnit(void)
{
    Result rc = 0;
    bool tmp = false;

    rc = splIsDevelopment(&tmp);
    if (R_SUCCEEDED(rc))
    {
        g_isDevUnit = tmp;
    } else {
        LOG_MSG_ERROR("splIsDevelopment failed! (0x%X).", rc);
    }

    return R_SUCCEEDED(rc);
}

static void utilsOverclockSystem(bool overclock)
{
    u32 cpu_rate = ((overclock ? CPU_CLKRT_OVERCLOCKED : CPU_CLKRT_NORMAL) * 1000000);
    u32 mem_rate = ((overclock ? MEM_CLKRT_OVERCLOCKED : MEM_CLKRT_NORMAL) * 1000000);
    servicesChangeHardwareClockRates(cpu_rate, mem_rate);
}

static void utilsOverclockSystemAppletHook(AppletHookType hook, void *param)
{
    NX_IGNORE_ARG(param);

    /* Don't proceed if we're not dealing with a desired hook type. */
    if (hook != AppletHookType_OnOperationMode && hook != AppletHookType_OnPerformanceMode) return;

    /* Overclock the system based on the overclock setting and the current long running state value. */
    SCOPED_LOCK(&g_resourcesMutex) utilsOverclockSystem(configGetBoolean("overclock") & g_longRunningProcess);
}

static void utilsChangeHomeButtonBlockStatus(bool block)
{
    /* Only change HOME button blocking status if we're running as a regular application or a system application. */
    if (utilsIsAppletMode()) return;

    if (block)
    {
        appletBeginBlockingHomeButtonShortAndLongPressed(0);
    } else {
        appletEndBlockingHomeButtonShortAndLongPressed();
    }
}

static size_t utilsGetUtf8StringLimit(const char *str, size_t str_size, size_t byte_limit)
{
    if (!str || !*str || !str_size || !byte_limit) return 0;

    if (byte_limit > str_size) return str_size;

    u32 code = 0;
    ssize_t units = 0;
    size_t cur_pos = 0, last_cp_pos = 0;
    const u8 *str_u8 = (const u8*)str;

    while(cur_pos < str_size && cur_pos < byte_limit)
    {
        units = decode_utf8(&code, str_u8 + cur_pos);
        size_t new_pos = (cur_pos + (size_t)units);
        if (units < 0 || !code || new_pos > str_size) break;

        cur_pos = new_pos;
        if (cur_pos < byte_limit) last_cp_pos = cur_pos;
    }

    return last_cp_pos;
}

static char utilsConvertHexDigitToBinary(char c)
{
    if ('a' <= c && c <= 'f') return (c - 'a' + 0xA);
    if ('A' <= c && c <= 'F') return (c - 'A' + 0xA);
    if ('0' <= c && c <= '9') return (c - '0');
    return 'z';
}

static void utilsConfigureInput(void)
{
    /* Configure input. */
    /* Up to 8 different, full controller inputs. */
    /* Individual Joy-Cons not supported. */
    padConfigureInput(8, HidNpadStyleSet_NpadFullCtrl);
    padInitializeWithMask(&g_padState, 0x1000000FFUL);
}

static void utilsPngErrorCallback(png_structp png_ptr, png_const_charp msg) {
    NX_IGNORE_ARG(png_ptr);
#if LOG_LEVEL <= LOG_LEVEL_ERROR
    LOG_MSG_ERROR("libpng error: %s", msg);
#else
    NX_IGNORE_ARG(msg);
#endif
}

static void utilsPngWarningCallback(png_structp png_ptr, png_const_charp msg) {
    NX_IGNORE_ARG(png_ptr);
#if LOG_LEVEL <= LOG_LEVEL_WARNING
    LOG_MSG_ERROR("libpng warning: %s", msg);
#else
    NX_IGNORE_ARG(msg);
#endif
}

static void utilsPngReadCallback(png_structp png_ptr, png_bytep rd_buf, size_t rd_size) {
    UtilsPngReadData *png_rd_data = (UtilsPngReadData*)png_get_io_ptr(png_ptr);
    if (!png_rd_data) return;

    if (png_rd_data->pos >= png_rd_data->buf_size) {
        memset(rd_buf, 0, rd_size);
        return;
    }

    if ((png_rd_data->pos + rd_size) > png_rd_data->buf_size) rd_size = (png_rd_data->buf_size - png_rd_data->pos);

    memcpy(rd_buf, png_rd_data->buf + png_rd_data->pos, rd_size);

    png_rd_data->pos += rd_size;
}
