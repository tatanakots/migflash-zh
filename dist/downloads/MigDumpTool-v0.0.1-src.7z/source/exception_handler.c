/*
 * exception_handler.c
 *
 * Copyright (c) 2019-2020, WerWolv.
 * Copyright (c) 2020-2023, DarkMatterCore <pabloacurielz@gmail.com>.
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 * Loosely based on debug_helpers.cpp from EdiZon-Rewrite.
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "utils.h"

#define FP_MASK                     0xFFFFFFFFFF000000UL
#define STACK_TRACE_SIZE            0x20
#define IS_HB_ADDR(x)               (info.addr && info.size && (x) >= info.addr && (x) < (info.addr + info.size))
#define EH_ADD_FMT_STR(fmt, ...)    utilsAppendFormattedStringToBuffer(&exception_str, &exception_str_size, fmt, ##__VA_ARGS__)

typedef struct {
    u64 fp;
    u64 lr;
} StackFrame;

u32 __nx_applet_exit_mode = 0;
alignas(16) u8 __nx_exception_stack[0x8000];
u64 __nx_exception_stack_size = sizeof(__nx_exception_stack);

static void GetHomebrewMemoryInfo(MemoryInfo *out);

#if LOG_LEVEL < LOG_LEVEL_NONE
static bool UnwindStack(u64 *out_stack_trace, u32 *out_stack_trace_size, size_t max_stack_trace_size, u64 cur_fp);
#endif

static void NX_NORETURN AbortProgramExecution(const char *crash_str);

void __libnx_exception_handler(ThreadExceptionDump *ctx) {
    MemoryInfo info = {0};
    char *error_desc_str = NULL, crash_str[256] = {0};

    GetHomebrewMemoryInfo(&info);

    switch(ctx->error_desc) {
        case ThreadExceptionDesc_InstructionAbort:
            error_desc_str = "Instruction Abort";
            break;
        case ThreadExceptionDesc_MisalignedPC:
            error_desc_str = "Misaligned Program Counter";
            break;
        case ThreadExceptionDesc_MisalignedSP:
            error_desc_str = "Misaligned Stack Pointer";
            break;
        case ThreadExceptionDesc_SError:
            error_desc_str = "SError";
            break;
        case ThreadExceptionDesc_BadSVC:
            error_desc_str = "Bad SVC";
            break;
        case ThreadExceptionDesc_Trap:
            error_desc_str = "SIGTRAP";
            break;
        case ThreadExceptionDesc_Other:
            error_desc_str = "Segmentation Fault";
            break;
        default:
            error_desc_str = "Unknown";
            break;
    }

#if LOG_LEVEL < LOG_LEVEL_NONE
    char *exception_str = NULL;
    size_t exception_str_size = 0;

    u32 stack_trace_size = 0;
    u64 stack_trace[STACK_TRACE_SIZE] = {0};

    LOG_MSG_ERROR("*** Exception Triggered ***");

    EH_ADD_FMT_STR("Type: %s (0x%X)\r\n", error_desc_str, ctx->error_desc);

    EH_ADD_FMT_STR("Registers:");

    for(size_t i = 0; i < MAX_ELEMENTS(ctx->cpu_gprs); i++) {
        u64 reg = ctx->cpu_gprs[i].x;
        EH_ADD_FMT_STR("\r\n    X%02lu:  0x%lX", i, reg);
        if (IS_HB_ADDR(reg)) EH_ADD_FMT_STR(" (BASE + 0x%lX)", reg - info.addr);
    }

    EH_ADD_FMT_STR("\r\n    FP:   0x%lX", ctx->fp.x);
    if (IS_HB_ADDR(ctx->fp.x)) EH_ADD_FMT_STR(" (BASE + 0x%lX)", ctx->fp.x - info.addr);

    EH_ADD_FMT_STR("\r\n    LR:   0x%lX", ctx->lr.x);
    if (IS_HB_ADDR(ctx->lr.x)) EH_ADD_FMT_STR(" (BASE + 0x%lX)", ctx->lr.x - info.addr);

    EH_ADD_FMT_STR("\r\n    SP:   0x%lX", ctx->sp.x);
    if (IS_HB_ADDR(ctx->sp.x)) EH_ADD_FMT_STR(" (BASE + 0x%lX)", ctx->sp.x - info.addr);

    EH_ADD_FMT_STR("\r\n    PC:   0x%lX", ctx->pc.x);
    if (IS_HB_ADDR(ctx->pc.x)) EH_ADD_FMT_STR(" (BASE + 0x%lX)", ctx->pc.x - info.addr);
    EH_ADD_FMT_STR("\r\n");

    if (UnwindStack(stack_trace, &stack_trace_size, STACK_TRACE_SIZE, ctx->fp.x)) {
        EH_ADD_FMT_STR("Stack Trace:");

        for(u32 i = 0; i < stack_trace_size; i++) {
            u64 addr = stack_trace[i];
            EH_ADD_FMT_STR("\r\n    [%02u]: 0x%lX", stack_trace_size - i - 1, addr);
            if (IS_HB_ADDR(addr)) EH_ADD_FMT_STR(" (BASE + 0x%lX)", addr - info.addr);
        }

        EH_ADD_FMT_STR("\r\n");
    }

    logWriteStringToLogFile(exception_str);

    if (exception_str) free(exception_str);
#endif

    snprintf(crash_str, sizeof(crash_str), "Fatal exception triggered!\nReason: %s (0x%X).\nPC: 0x%lX", error_desc_str, ctx->error_desc, ctx->pc.x);

    if IS_HB_ADDR(ctx->pc.x) {
        size_t crash_str_len = strlen(crash_str);
        snprintf(crash_str + crash_str_len, sizeof(crash_str) - crash_str_len, " (BASE + 0x%lX)", ctx->pc.x - info.addr);
    }

    strcat(crash_str, ".");

    AbortProgramExecution(crash_str);
}

void diagAbortWithResult(Result res) {
    LOG_MSG_ERROR("*** libnx aborted with error code: 0x%X ***", res);

    char crash_str[256] = {0};
    snprintf(crash_str, sizeof(crash_str), "Fatal error triggered in libnx!\nError code: 0x%X.", res);

    AbortProgramExecution(crash_str);
}

static void GetHomebrewMemoryInfo(MemoryInfo *out) {
    u32 p = 0;
    Result rc = svcQueryMemory(out, &p, (uintptr_t)&GetHomebrewMemoryInfo);
    if (R_FAILED(rc)) LOG_MSG_ERROR("svcQueryMemory failed! (0x%X).", rc);
}

#if LOG_LEVEL < LOG_LEVEL_NONE
static bool UnwindStack(u64 *out_stack_trace, u32 *out_stack_trace_size, size_t max_stack_trace_size, u64 cur_fp) {
    *out_stack_trace_size = 0;
    u64 fp_base = (cur_fp & FP_MASK);

    for(size_t i = 0; i < max_stack_trace_size; i++) {
        if (!cur_fp || (cur_fp % sizeof(u64)) || (cur_fp & FP_MASK) != fp_base) break;

        StackFrame *cur_trace = (StackFrame*)cur_fp;
        out_stack_trace[(*out_stack_trace_size)++] = cur_trace->lr;
        cur_fp = cur_trace->fp;
    }

    return (*out_stack_trace_size > 0);
}
#endif

static void NX_NORETURN AbortProgramExecution(const char *crash_str) {
    menu_deinit();

    utilsPrintConsoleError(crash_str);

    utilsCloseResources();

    __nx_applet_exit_mode = 1;
    exit(EXIT_FAILURE);

    __builtin_unreachable();
}
