/*
 * dumper.c
 *
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "utils.h"
#include "dumper.h"
#include "gamecard.h"
#include "title.h"
#include "usb.h"

static char *dumper_gen_base_out_path(u32 output_storage, const UsbHsFsDevice *ums_device);

static bool dumper_save_xci(dumper_thrd_data_t *thrd_data, const char *base_out_path, u64 gc_size);
static bool dumper_save_initial_data_and_uid(dumper_thrd_data_t *thrd_data, const char *base_out_path);
static bool dumper_save_cert(dumper_thrd_data_t *thrd_data, const char *base_out_path);
static bool dumper_save_card_id_set(dumper_thrd_data_t *thrd_data, const char *base_out_path);

static bool dumper_save_file(dumper_thrd_data_t *thrd_data, const char *path, void *data, size_t data_size);

void dumper_save_mig_switch_data(void *arg) {
    dumper_thrd_data_t *thrd_data = (dumper_thrd_data_t*)arg;

    bool dump_xci = false, dump_initial_data = false, dump_certificate = false, dump_card_id_set = false, dump_card_uid = false;
    u32 output_storage = 0;
    UsbHsFsDevice *ums_device = NULL;

    u64 gc_size = 0, free_space = 0, total_size = 0;
    char *base_out_path = NULL;

    bool gc_size_error = false, ret = false;

    SCOPED_LOCK(&(thrd_data->mutex)) {
        if ((dump_xci = thrd_data->dump_xci)) {
            gc_size_error = (!gamecardGetTotalSize(&gc_size) || !gc_size);
            if (gc_size_error) {
                LOG_MSG_ERROR("FAILED TO RETRIEVE GAMECARD SIZE");
                break;
            }

            total_size += gc_size;
        }

        if ((dump_initial_data = thrd_data->dump_initial_data)) total_size += sizeof(GameCardInitialData);
        if ((dump_certificate = thrd_data->dump_certificate)) total_size += sizeof(FsGameCardCertificate);
        if ((dump_card_id_set = thrd_data->dump_card_id_set)) total_size += sizeof(FsGameCardIdSet);
        if ((dump_card_uid = thrd_data->dump_card_uid)) total_size += MEMBER_SIZE(GameCardSpecificData, card_uid);

        output_storage = thrd_data->output_storage;
        ums_device = thrd_data->ums_device;
    }

    if (gc_size_error) goto out;

    if (!total_size) {
        LOG_MSG_ERROR("CALCULATED DATA SIZE IS ZERO");
        goto out;
    }

    if (!(base_out_path = dumper_gen_base_out_path(output_storage, ums_device))) goto out;

    if (output_storage != ConfigOutputStorage_UsbHost) {
        if (!utilsGetFileSystemStatsByPath(base_out_path, NULL, &free_space)) {
            LOG_MSG_ERROR("FAILED TO RETRIEVE FREE SPACE FROM SELECTED OUTPUT STORAGE");
            goto out;
        }

        if (total_size >= free_space) {
            LOG_MSG_ERROR("TOTAL DUMP SIZE EXCEEDS FREE SPACE ON SELECTED OUTPUT STORAGE");
            goto out;
        }

        utilsCreateDirectoryTree(base_out_path, false);
    }

    SCOPED_LOCK(&(thrd_data->mutex)) thrd_data->total_size = total_size;

    if (dump_xci && !dumper_save_xci(thrd_data, base_out_path, gc_size)) goto out;

    if ((dump_initial_data || dump_card_uid) && !dumper_save_initial_data_and_uid(thrd_data, base_out_path)) goto out;

    if (dump_certificate && !dumper_save_cert(thrd_data, base_out_path)) goto out;

    if (dump_card_id_set && !dumper_save_card_id_set(thrd_data, base_out_path)) goto out;

    ret = true;

out:
    SCOPED_LOCK(&(thrd_data->mutex)) {
        if (!ret && !thrd_data->transfer_cancelled) thrd_data->error = true;
    }

    if (base_out_path) free(base_out_path);

    threadExit();
}

static char *dumper_gen_base_out_path(u32 output_storage, const UsbHsFsDevice *ums_device) {
    char *filename = titleGenerateGameCardFileName(TitleNamingConvention_Full, output_storage != ConfigOutputStorage_SdCard ?
                                                   TitleFileNameIllegalCharReplaceType_IllegalFsChars : TitleFileNameIllegalCharReplaceType_KeepAsciiCharsOnly);

    size_t prefix_size = (64 + (filename ? strlen(filename) : 0));
    char *prefix = calloc(sizeof(char), prefix_size);

    char *output = NULL;

    if (filename && prefix) {
        if (output_storage != ConfigOutputStorage_UsbHost) {
            sprintf(prefix, "%s", output_storage == ConfigOutputStorage_SdCard ? DEVOPTAB_SDMC_DEVICE : ums_device->name);
            if (output_storage == ConfigOutputStorage_SdCard) sprintf(prefix + strlen(prefix), "/" APP_TITLE);
        }

        sprintf(prefix + strlen(prefix), "/%s.xci/", filename);

        output = utilsGeneratePath(prefix, filename, NULL);
        if (!output) LOG_MSG_ERROR("FAILED TO GENERATE OUTPUT FILENAME");
    } else {
        LOG_MSG_ERROR("FAILED TO GENERATE GAMECARD FILENAME");
    }

    if (prefix) free(prefix);

    if (filename) free(filename);

    return output;
}

static bool dumper_save_xci(dumper_thrd_data_t *thrd_data, const char *base_out_path, u64 gc_size) {
    u32 output_storage = 0;
    UsbHsFsDevice *ums_device = NULL;

    char file_path[FS_MAX_PATH] = {0};
    FILE *fp = NULL;

    u8 *buf = NULL;
    u64 data_written = 0;

    bool cancel = false, ret = false;

    SCOPED_LOCK(&(thrd_data->mutex)) {
        output_storage = thrd_data->output_storage;
        ums_device = thrd_data->ums_device;
    }

    snprintf(file_path, MAX_ELEMENTS(file_path), "%s.xci", base_out_path);

    if (output_storage == ConfigOutputStorage_UsbHost) {
        if (!usbSendFileProperties(gc_size, file_path)) {
            LOG_MSG_ERROR("FAILED TO SEND XCI FILE PROPERTIES TO PC");
            goto out;
        }
    } else {
        if (output_storage == ConfigOutputStorage_SdCard) {
            if (gc_size > FAT32_FILESIZE_LIMIT && !utilsCreateConcatenationFile(file_path))
            {
                LOG_MSG_ERROR("FAILED TO CREATE XCI CONCATENATION FILE");
                goto out;
            }
        } else {
            if (ums_device->fs_type < UsbHsFsDeviceFileSystemType_exFAT && gc_size > FAT32_FILESIZE_LIMIT)
            {
                LOG_MSG_ERROR("SPLIT DUMPS NOT SUPPORTED FOR USB FAT PARTITIONS");
                goto out;
            }
        }

        fp = fopen(file_path, "wb");
        if (!fp) {
            LOG_MSG_ERROR("FAILED TO CREATE XCI FILE");
            goto out;
        }

        setvbuf(fp, NULL, _IONBF, 0);
        ftruncate(fileno(fp), (off_t)gc_size);
    }

    buf = usbAllocatePageAlignedBuffer(USB_TRANSFER_BUFFER_SIZE);
    if (!buf) {
        LOG_MSG_ERROR("FAILED TO ALLOCATE MEMORY FOR XCI DUMP");
        goto out;
    }

    for(u64 offset = 0, blksize = USB_TRANSFER_BUFFER_SIZE; offset < gc_size; offset += blksize) {
        if (blksize > (gc_size - offset)) blksize = (gc_size - offset);

        SCOPED_LOCK(&(thrd_data->mutex)) {
            if (thrd_data->transfer_cancelled) {
                if (output_storage == ConfigOutputStorage_UsbHost) usbCancelFileTransfer();
                cancel = true;
            }
        }

        if (cancel || !gamecardReadStorage(buf, blksize, offset)) break;

        if (offset == 0) memset(buf + GAMECARD_CERTIFICATE_OFFSET, 0xFF, sizeof(FsGameCardCertificate));

        if (output_storage == ConfigOutputStorage_UsbHost) {
            if (!usbSendFileData(buf, blksize)) {
                LOG_MSG_ERROR("FAILED TO TRANSFER XCI DATA TO PC");
                break;
            }
        } else {
            if (fwrite(buf, 1, blksize, fp) != blksize) {
                LOG_MSG_ERROR("FAILED TO WRITE XCI DATA TO OUTPUT STORAGE");
                break;
            }
        }

        data_written += blksize;
        SCOPED_LOCK(&(thrd_data->mutex)) thrd_data->data_written = data_written;
    }

    ret = (!cancel && data_written >= gc_size);

out:
    if (buf) free(buf);

    if (fp) {
        fclose(fp);

        if (!ret && output_storage != ConfigOutputStorage_UsbHost) {
            if (output_storage == ConfigOutputStorage_SdCard) {
                utilsRemoveConcatenationFile(file_path);
                utilsCommitSdCardFileSystemChanges();
            } else {
                remove(file_path);
            }
        }
    }

    return ret;
}

static bool dumper_save_initial_data_and_uid(dumper_thrd_data_t *thrd_data, const char *base_out_path) {
    GameCardSecurityInformation gc_security_information = {0};
    char file_path[FS_MAX_PATH] = {0};
    bool dump_initial_data = false, dump_card_uid = false, ret = false;

    SCOPED_LOCK(&(thrd_data->mutex)) {
        dump_initial_data = thrd_data->dump_initial_data;
        dump_card_uid = thrd_data->dump_card_uid;
    }

    if (gamecardGetSecurityInformation(&gc_security_information)) {
        if (dump_initial_data) {
            snprintf(file_path, MAX_ELEMENTS(file_path), "%s (Initial Data).bin", base_out_path);

            if (!dumper_save_file(thrd_data, file_path, &(gc_security_information.initial_data), sizeof(gc_security_information.initial_data))) {
                LOG_MSG_ERROR("FAILED TO SAVE GAMECARD INITIAL DATA");
                goto out;
            }
        }

        if (dump_card_uid) {
            snprintf(file_path, MAX_ELEMENTS(file_path), "%s (Card UID).bin", base_out_path);

            if (!dumper_save_file(thrd_data, file_path, gc_security_information.specific_data.card_uid, sizeof(gc_security_information.specific_data.card_uid))) {
                LOG_MSG_ERROR("FAILED TO SAVE GAMECARD CARD UID");
                goto out;
            }
        }

        ret = true;
    } else {
        LOG_MSG_ERROR("FAILED TO GET GAMECARD SECURITY INFORMATION");
    }

out:
    return ret;
}

static bool dumper_save_cert(dumper_thrd_data_t *thrd_data, const char *base_out_path) {
    FsGameCardCertificate gc_cert = {0};
    char file_path[FS_MAX_PATH] = {0};
    bool ret = false;

    if (gamecardGetCertificate(&gc_cert)) {
        snprintf(file_path, MAX_ELEMENTS(file_path), "%s (Certificate).bin", base_out_path);

        ret = dumper_save_file(thrd_data, file_path, &gc_cert, sizeof(gc_cert));
        if (!ret) LOG_MSG_ERROR("FAILED TO SAVE GAMECARD CERTIFICATE");
    } else {
        LOG_MSG_ERROR("FAILED TO GET GAMECARD CERTIFICATE");
    }

    return ret;
}

static bool dumper_save_card_id_set(dumper_thrd_data_t *thrd_data, const char *base_out_path) {
    FsGameCardIdSet id_set = {0};
    char file_path[FS_MAX_PATH] = {0};
    bool ret = false;

    if (gamecardGetCardIdSet(&id_set)) {
        snprintf(file_path, MAX_ELEMENTS(file_path), "%s (Card ID Set).bin", base_out_path);

        ret = dumper_save_file(thrd_data, file_path, &id_set, sizeof(id_set));
        if (!ret) LOG_MSG_ERROR("FAILED TO SAVE GAMECARD ID SET");
    } else {
        LOG_MSG_ERROR("FAILED TO GET GAMECARD ID SET");
    }

    return ret;
}

static bool dumper_save_file(dumper_thrd_data_t *thrd_data, const char *path, void *data, size_t data_size) {
    u32 output_storage = 0;
    bool ret = false;

    SCOPED_LOCK(&(thrd_data->mutex)) output_storage = thrd_data->output_storage;

    if (output_storage == ConfigOutputStorage_UsbHost) {
        if (!usbSendFileProperties(data_size, path)) {
            LOG_MSG_ERROR("FAILED TO SEND FILE PROPERTIES TO PC");
            goto out;
        }

        if (!usbSendFileData(data, data_size)) {
            LOG_MSG_ERROR("FAILED TO TRANSFER FILE DATA TO PC");
            goto out;
        }
    } else {
        FILE *fp = fopen(path, "wb");
        if (!fp) {
            LOG_MSG_ERROR("FAILED TO CREATE FILE");
            goto out;
        }

        ftruncate(fileno(fp), (off_t)data_size);
        size_t ret = fwrite(data, 1, data_size, fp);
        fclose(fp);

        if (output_storage == ConfigOutputStorage_SdCard) utilsCommitSdCardFileSystemChanges();

        if (ret != data_size) {
            LOG_MSG_ERROR("FAILED TO WRITE DATA TO FILE");
            remove(path);
            goto out;
        }
    }

    SCOPED_LOCK(&(thrd_data->mutex)) thrd_data->data_written += data_size;

    ret = true;

out:
    return ret;
}
