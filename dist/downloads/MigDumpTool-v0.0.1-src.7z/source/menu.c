/*
 * menu.c
 *
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include <ft2build.h>
#include FT_FREETYPE_H

#include "utils.h"
#include "title.h"
#include "gamecard.h"
#include "usb.h"
#include "dumper.h"

#define SCREEN_WIDTH                                1280
#define SCREEN_HEIGHT                               720
#define SCREEN_DPI_RES                              96

#define COLOR_BLACK                                 RGBA8_MAXALPHA(0x15, 0x14, 0x1B)
#define COLOR_BRICK                                 RGBA8_MAXALPHA(0x8F, 0x1A, 0x22)
#define COLOR_VERMILION                             RGBA8_MAXALPHA(0xD2, 0x33, 0x29)
#define COLOR_WHITE                                 RGBA8_MAXALPHA(0xE5, 0xE7, 0xEB)
#define COLOR_ORANGE                                RGBA8_MAXALPHA(0xF2, 0x80, 0x31)
#define COLOR_BUFF                                  RGBA8_MAXALPHA(0xF7, 0xDF, 0x87)

#define STARTUP_ANIM_STATIC_DURATION                1.5
#define STARTUP_ANIM_FADEOUT_DURATION               1.5

#define MENU_DEFAULT_PAGE_SIZE                      6

#define MENU_IMAGE_CENTER                           -1

#define MENU_INTERNAL_ICON_WIDTH                    48

#define MENU_SUBMENU_NAME_Y_OFFSET                  259

#define MENU_SCROLLBAR_WIDTH                        14
#define MENU_SCROLLBAR_OUTER_RADIUS                 (MENU_SCROLLBAR_WIDTH / 2)
#define MENU_SCROLLBAR_INNER_RADIUS                 (MENU_SCROLLBAR_OUTER_RADIUS - 3)
#define MENU_SCROLLBAR_X_OFFSET                     40

#define MENU_DUMPER_CANCEL_TIMEOUT                  2.0

#define MENU_KAZATCHOK_FRAME_DELAY                  0.25
#define MENU_KAZATCHOK_MAX_IDX                      4

#define MENU_PROGRESSBAR_OUTER_X                    319
#define MENU_PROGRESSBAR_OUTER_Y                    328
#define MENU_PROGRESSBAR_OUTER_WIDTH                633
#define MENU_PROGRESSBAR_OUTER_HEIGHT               64

#define MENU_PROGRESSBAR_INNER_OFFSET               3
#define MENU_PROGRESSBAR_INNER_X                    (MENU_PROGRESSBAR_OUTER_X + MENU_PROGRESSBAR_INNER_OFFSET)
#define MENU_PROGRESSBAR_INNER_Y                    (MENU_PROGRESSBAR_OUTER_Y + MENU_PROGRESSBAR_INNER_OFFSET)
#define MENU_PROGRESSBAR_INNER_WIDTH                (MENU_PROGRESSBAR_OUTER_WIDTH - (MENU_PROGRESSBAR_INNER_OFFSET * 2))
#define MENU_PROGRESSBAR_INNER_HEIGHT               (MENU_PROGRESSBAR_OUTER_HEIGHT - (MENU_PROGRESSBAR_INNER_OFFSET * 2))

#define MENU_PROGRESSBAR_CHUNK_WIDTH                60
#define MENU_PROGRESSBAR_CHUNK_SEPARATION           MENU_PROGRESSBAR_INNER_OFFSET

#define RGBA8_RED_CHANNEL(color)                    ((color) & 0xFF)
#define RGBA8_GREEN_CHANNEL(color)                  (((color) >> 8) & 0xFF)
#define RGBA8_BLUE_CHANNEL(color)                   (((color) >> 16) & 0xFF)
#define RGBA8_ALPHA_CHANNEL(color)                  (((color) >> 24) & 0xFF)

#define RGBA8_MAX_ALPHA_VALUE                       255.0

#define ALPHA_BLEND_COLORS(col1, col2, p)           (u8)(((1.0 - (p)) * (float)(col1)) + ((p) * (float)(col2)))
#define ALPHA_BLEND_TRANSPARENCIES(p1, p2)          ((p1) + ((1.0 - (p1)) * (p2)))

#define RGBA8_BUFFER_PIXEL(buf, x, y, row_width)    buf[(y * row_width) + x]
#define FB_PIXEL(x, y)                              RGBA8_BUFFER_PIXEL(raw_fb, x, y, raw_fb_row_w)

typedef struct {
    const char *path;
    u8 *ttf;
    size_t ttf_size;
    FT_Face font_face;
} menu_font_t;

typedef enum {
    FONT_TYPE_REGULAR = 0,
    FONT_TYPE_SEMIBOLD,
    FONT_TYPE_BOLD,
    FONT_TYPE_EXTRABOLD,
    FONT_TYPE_THIN,
    FONT_TYPE_TOTAL
} menu_font_type_t;

typedef struct {
    const char *path;
    u8 *rgba8888_img;
    int w, h;
} menu_image_t;

typedef struct _menu_t menu_t;

typedef bool (*menu_elem_func_t)(void);
typedef bool (*menu_elem_toggle_get_func_t)(void);
typedef void (*menu_elem_toggle_set_func_t)(bool value);

typedef struct {
    bool value, retrieved;
    menu_elem_toggle_get_func_t getter_func;
    menu_elem_toggle_set_func_t setter_func;
} menu_elem_toggle_t;

typedef struct {
    char *str;
    int str_w;
    menu_t *child_menu;
    menu_elem_func_t task_func;
    menu_elem_toggle_t *toggle;
    menu_image_t *icon, *icon_hl;
} menu_elem_t;

typedef struct {
    menu_image_t *img;
    int x, y;
} menu_img_layer_t;

struct _menu_t {
    struct _menu_t *parent;
    u32 selected, scroll, elem_count, page_size;
    menu_elem_t **elements;
    menu_img_layer_t **img_layers;
    menu_font_type_t font_type;
    u32 font_size, font_color, font_color_hl;
    int font_height;
    int element_x, element_y, element_w, element_h, element_sep;
    u32 bg_color, bg_color_hl;
    int hl_offset;
    bool draw_sep, transparent_bg, draw_icon_inside;
};

static void menu_start_frame(void);
static void menu_end_frame(void);

static void menu_draw_rect(u32 color, int x, int y, int w, int h);
static void menu_draw_circle(u32 color, int x, int y, int r);

NX_INLINE void menu_draw_rgba888_img(const u8 *rgba8888_img, int x, int y, int w, int h);
NX_INLINE void menu_draw_rgba888_img_with_alpha(const u8 *rgba8888_img, u8 alpha, int x, int y, int w, int h);

__attribute__((format(printf, 7, 8))) static void menu_draw_str(menu_font_type_t font_type, u32 color, u32 size, int x, int y, int *out_x, const char *fmt, ...);
__attribute__((format(printf, 3, 4))) static int menu_get_str_w(menu_font_type_t font_type, u32 size, const char *fmt, ...);

static void menu_play_startup_anim(void);

static u32 menu_get_elem_count(menu_t *menu);
static u32 menu_get_page_size(menu_t *menu);

static void menu_draw_img_layers(menu_img_layer_t **img_layers);
static void menu_draw_app_info(void);
static void menu_draw_submenu_banner(menu_t *parent_menu);
static void menu_draw_scrollbar(void);

static bool menu_init_ft_data(void);
static void menu_deinit_ft_data(void);

static bool menu_load_img_data(void);
static void menu_free_img_data(void);

static bool menu_init_fb(void);
NX_INLINE void menu_deinit_fb(void);

static void _menu_draw_rgba888_img(const u8 *rgba8888_img, u8 alpha, int x, int y, int w, int h);

static void menu_draw_chr_bitmap(const FT_Bitmap *bitmap, u32 color, int x, int y);

static void menu_load_stor_list(bool reset_storage);
static void menu_free_stor_list(void);

static u32 menu_get_output_stor_opt(void);
static bool menu_set_output_stor_opt(void);

static bool menu_get_dump_xci_opt(void);
static void menu_set_dump_xci_opt(bool value);

static bool menu_get_dump_initial_data_opt(void);
static void menu_set_dump_initial_data_opt(bool value);

static bool menu_get_dump_cert_opt(void);
static void menu_set_dump_cert_opt(bool value);

static bool menu_get_dump_card_id_set_opt(void);
static void menu_set_dump_card_id_set_opt(bool value);

static bool menu_get_dump_card_uid_opt(void);
static void menu_set_dump_card_uid_opt(bool value);

static bool menu_easy_one_click_proc(void);
static bool menu_wait_gc(bool *display_error);
static bool menu_wait_usb(void);
static void menu_show_success(void);
static void menu_show_error(void);

static bool is_menu_init = false;

static FT_Library ft_lib = NULL;

static menu_font_t menu_fonts[FONT_TYPE_TOTAL] = {
    [FONT_TYPE_REGULAR] = { "romfs:/fonts/BarlowCondensed-Regular.ttf", NULL, 0, NULL },
    [FONT_TYPE_SEMIBOLD] = { "romfs:/fonts/BarlowCondensed-SemiBold.ttf", NULL, 0, NULL },
    [FONT_TYPE_BOLD] = { "romfs:/fonts/BarlowCondensed-Bold.ttf", NULL, 0, NULL },
    [FONT_TYPE_EXTRABOLD] = { "romfs:/fonts/BarlowCondensed-ExtraBold.ttf", NULL, 0, NULL },
    [FONT_TYPE_THIN] = { "romfs:/fonts/BarlowCondensed-Thin.ttf", NULL, 0, NULL }
};

static menu_image_t menu_images[] = {
    { "romfs:/ui/banners/Cartridge-join-the-revolution.png", NULL, 0, 0 },
    { "romfs:/ui/banners/Congratz.png", NULL, 0, 0 },
    { "romfs:/ui/banners/Ho-no.png", NULL, 0, 0 },
    { "romfs:/ui/bg/01.jpg", NULL, 0, 0 },
    { "romfs:/ui/bg/02.jpg", NULL, 0, 0 },
    { "romfs:/ui/icons/advanced.png", NULL, 0, 0 },
    { "romfs:/ui/icons/easy-dump.png", NULL, 0, 0 },
    { "romfs:/ui/icons/PC-OFF.png", NULL, 0, 0 },
    { "romfs:/ui/icons/PC-ON.png", NULL, 0, 0 },
    { "romfs:/ui/icons/SD-OFF.png", NULL, 0, 0 },
    { "romfs:/ui/icons/SD-ON.png", NULL, 0, 0 },
    { "romfs:/ui/icons/storage.png", NULL, 0, 0 },
    { "romfs:/ui/icons/toggle-HIGHLIGHT-OFF.png", NULL, 0, 0 },
    { "romfs:/ui/icons/toggle-HIGHLIGHT-ON.png", NULL, 0, 0 },
    { "romfs:/ui/icons/toggle-OFF.png", NULL, 0, 0 },
    { "romfs:/ui/icons/toggle-ON.png", NULL, 0, 0 },
    { "romfs:/ui/icons/USB-OFF.png", NULL, 0, 0 },
    { "romfs:/ui/icons/USB-ON.png", NULL, 0, 0 },
    { "romfs:/ui/kazatchok/01.png", NULL, 0, 0 },
    { "romfs:/ui/kazatchok/02.png", NULL, 0, 0 },
    { "romfs:/ui/kazatchok/03.png", NULL, 0, 0 },
    { "romfs:/ui/kazatchok/04.png", NULL, 0, 0 },
    { "romfs:/ui/misc/LOGO-MIGSW.png", NULL, 0, 0 },
    { "romfs:/ui/misc/navigation-01.png", NULL, 0, 0 },
    { "romfs:/ui/misc/navigation-02.png", NULL, 0, 0 },
    { "romfs:/ui/misc/navigation-03.png", NULL, 0, 0 },
    { "romfs:/ui/misc/Top-shape.png", NULL, 0, 0 },
    { "romfs:/ui/icons/no-pc.png", NULL, 0, 0 },
    { "romfs:/ui/icons/no-gamecard.png", NULL, 0, 0 },
    { "romfs:/ui/icons/process-gamecard.png", NULL, 0, 0 }
};

static const u32 menu_images_cnt = MAX_ELEMENTS(menu_images);

static Framebuffer fb = {0};
static u32 *raw_fb = NULL;
static u32 raw_fb_row_w = 0;

static UsbHsFsDevice *usb_storages = NULL;
static u32 usb_storages_cnt = 0;

static menu_img_layer_t *common_img_layers[] = {
    &(menu_img_layer_t){
        .img = &(menu_images[3]),
        .x = 0,
        .y = 0
    },
    &(menu_img_layer_t){
        .img = &(menu_images[26]),
        .x = MENU_IMAGE_CENTER,
        .y = 24
    },
    &(menu_img_layer_t){
        .img = &(menu_images[22]),
        .x = MENU_IMAGE_CENTER,
        .y = 29
    },
    &(menu_img_layer_t){
        .img = &(menu_images[23]),
        .x = MENU_IMAGE_CENTER,
        .y = 633
    },
    NULL
};

static menu_img_layer_t *no_connect_img_layers[] = {
    &(menu_img_layer_t){
        .img = &(menu_images[3]),
        .x = 0,
        .y = 0
    },
    &(menu_img_layer_t){
        .img = &(menu_images[26]),
        .x = MENU_IMAGE_CENTER,
        .y = 24
    },
    &(menu_img_layer_t){
        .img = &(menu_images[22]),
        .x = MENU_IMAGE_CENTER,
        .y = 29
    },
    &(menu_img_layer_t){
        .img = &(menu_images[25]),
        .x = MENU_IMAGE_CENTER,
        .y = 633
    },
    NULL
};

static menu_img_layer_t *gc_processing_img_layers[] = {
    &(menu_img_layer_t){
        .img = &(menu_images[3]),
        .x = 0,
        .y = 0
    },
    &(menu_img_layer_t){
        .img = &(menu_images[26]),
        .x = MENU_IMAGE_CENTER,
        .y = 24
    },
    &(menu_img_layer_t){
        .img = &(menu_images[22]),
        .x = MENU_IMAGE_CENTER,
        .y = 29
    },
    NULL
};

static menu_img_layer_t *progress_img_layers[] = {
    &(menu_img_layer_t){
        .img = &(menu_images[4]),
        .x = 0,
        .y = 0
    },
    &(menu_img_layer_t){
        .img = &(menu_images[26]),
        .x = MENU_IMAGE_CENTER,
        .y = 24
    },
    &(menu_img_layer_t){
        .img = &(menu_images[22]),
        .x = MENU_IMAGE_CENTER,
        .y = 29
    },
    &(menu_img_layer_t){
        .img = &(menu_images[0]),
        .x = MENU_IMAGE_CENTER,
        .y = 254
    },
    &(menu_img_layer_t){
        .img = &(menu_images[18]),
        .x = MENU_IMAGE_CENTER,
        .y = 213
    },
    &(menu_img_layer_t){
        .img = &(menu_images[24]),
        .x = MENU_IMAGE_CENTER,
        .y = 633
    },
    NULL
};

static menu_img_layer_t *error_img_layers[] = {
    &(menu_img_layer_t){
        .img = &(menu_images[4]),
        .x = 0,
        .y = 0
    },
    &(menu_img_layer_t){
        .img = &(menu_images[26]),
        .x = MENU_IMAGE_CENTER,
        .y = 24
    },
    &(menu_img_layer_t){
        .img = &(menu_images[22]),
        .x = MENU_IMAGE_CENTER,
        .y = 29
    },
    &(menu_img_layer_t){
        .img = &(menu_images[2]),
        .x = MENU_IMAGE_CENTER,
        .y = 230
    },
    NULL
};

static menu_img_layer_t *success_img_layers[] = {
    &(menu_img_layer_t){
        .img = &(menu_images[4]),
        .x = 0,
        .y = 0
    },
    &(menu_img_layer_t){
        .img = &(menu_images[26]),
        .x = MENU_IMAGE_CENTER,
        .y = 24
    },
    &(menu_img_layer_t){
        .img = &(menu_images[22]),
        .x = MENU_IMAGE_CENTER,
        .y = 29
    },
    &(menu_img_layer_t){
        .img = &(menu_images[0]),
        .x = MENU_IMAGE_CENTER,
        .y = 254
    },
    &(menu_img_layer_t){
        .img = &(menu_images[1]),
        .x = MENU_IMAGE_CENTER,
        .y = 237
    },
    NULL
};

static u32 output_stor = ConfigOutputStorage_SdCard;
static menu_elem_t **output_stor_menu_elem = NULL;

static menu_t output_stor_menu = {
    .parent = NULL,
    .selected = 0,
    .scroll = 0,
    .elements = NULL,
    .img_layers = common_img_layers,
    .font_type = FONT_TYPE_SEMIBOLD,
    .font_size = 13,
    .font_color = COLOR_BRICK,
    .font_color_hl = COLOR_VERMILION,
    .font_height = 0,
    .element_x = 397,
    .element_y = 338,
    .element_w = 486,
    .element_h = 33,
    .element_sep = 9,
    .bg_color = 0,
    .bg_color_hl = COLOR_BUFF,
    .hl_offset = 0,
    .draw_sep = false,
    .transparent_bg = true,
    .draw_icon_inside = true
};

static menu_elem_t *advanced_opt_menu_elem[] = {
    &(menu_elem_t){
        .str = "DUMP XCI",
        .str_w = 0,
        .child_menu = NULL,
        .task_func = NULL,
        .toggle = &(menu_elem_toggle_t){
            .value = false,
            .retrieved = false,
            .getter_func = &menu_get_dump_xci_opt,
            .setter_func = &menu_set_dump_xci_opt
        },
        .icon = NULL,
        .icon_hl = NULL
    },
    &(menu_elem_t){
        .str = "DUMP INITIAL DATA",
        .str_w = 0,
        .child_menu = NULL,
        .task_func = NULL,
        .toggle = &(menu_elem_toggle_t){
            .value = false,
            .retrieved = false,
            .getter_func = &menu_get_dump_initial_data_opt,
            .setter_func = &menu_set_dump_initial_data_opt
        },
        .icon = NULL,
        .icon_hl = NULL
    },
    &(menu_elem_t){
        .str = "DUMP CERTIFICATE",
        .str_w = 0,
        .child_menu = NULL,
        .task_func = NULL,
        .toggle = &(menu_elem_toggle_t){
            .value = false,
            .retrieved = false,
            .getter_func = &menu_get_dump_cert_opt,
            .setter_func = &menu_set_dump_cert_opt
        },
        .icon = NULL,
        .icon_hl = NULL
    },
    &(menu_elem_t){
        .str = "DUMP CARD ID SET",
        .str_w = 0,
        .child_menu = NULL,
        .task_func = NULL,
        .toggle = &(menu_elem_toggle_t){
            .value = false,
            .retrieved = false,
            .getter_func = &menu_get_dump_card_id_set_opt,
            .setter_func = &menu_set_dump_card_id_set_opt
        },
        .icon = NULL,
        .icon_hl = NULL
    },
    &(menu_elem_t){
        .str = "DUMP CARD UID",
        .str_w = 0,
        .child_menu = NULL,
        .task_func = NULL,
        .toggle = &(menu_elem_toggle_t){
            .value = false,
            .retrieved = false,
            .getter_func = &menu_get_dump_card_uid_opt,
            .setter_func = &menu_set_dump_card_uid_opt
        },
        .icon = NULL,
        .icon_hl = NULL
    },
    NULL
};

static menu_t advanced_opt_menu = {
    .parent = NULL,
    .selected = 0,
    .scroll = 0,
    .elements = advanced_opt_menu_elem,
    .img_layers = common_img_layers,
    .font_type = FONT_TYPE_SEMIBOLD,
    .font_size = 13,
    .font_color = COLOR_BRICK,
    .font_color_hl = COLOR_VERMILION,
    .font_height = 0,
    .element_x = 478,
    .element_y = 338,
    .element_w = 324,
    .element_h = 33,
    .element_sep = 9,
    .bg_color = 0,
    .bg_color_hl = COLOR_BUFF,
    .hl_offset = 0,
    .draw_sep = false,
    .transparent_bg = true,
    .draw_icon_inside = false
};

static menu_elem_t *root_menu_elem[] = {
    &(menu_elem_t){
        .str = "EASY ONE CLICK DUMP",
        .str_w = 0,
        .child_menu = NULL,
        .task_func = &menu_easy_one_click_proc,
        .toggle = NULL,
        .icon = &(menu_images[6]),
        .icon_hl = NULL
    },
    &(menu_elem_t){
        .str = "OUTPUT STORAGE",
        .str_w = 0,
        .child_menu = &output_stor_menu,
        .task_func = NULL,
        .toggle = NULL,
        .icon = &(menu_images[11]),
        .icon_hl = NULL
    },
    &(menu_elem_t){
        .str = "ADVANCED OPTIONS",
        .str_w = 0,
        .child_menu = &advanced_opt_menu,
        .task_func = NULL,
        .toggle = NULL,
        .icon = &(menu_images[5]),
        .icon_hl = NULL
    },
    NULL
};

static menu_t root_menu = {
    .parent = NULL,
    .selected = 0,
    .scroll = 0,
    .elements = root_menu_elem,
    .img_layers = common_img_layers,
    .font_type = FONT_TYPE_SEMIBOLD,
    .font_size = 14,
    .font_color = COLOR_BUFF,
    .font_color_hl = COLOR_BUFF,
    .font_height = 0,
    .element_x = 517,
    .element_y = 293,
    .element_w = 246,
    .element_h = 36,
    .element_sep = 36,
    .bg_color = COLOR_VERMILION,
    .bg_color_hl = COLOR_BRICK,
    .hl_offset = 3,
    .draw_sep = true,
    .transparent_bg = false,
    .draw_icon_inside = false
};

static menu_t *cur_menu = &root_menu;

bool menu_init(void) {
    if (is_menu_init) return true;

    bool ret = (menu_init_ft_data() && menu_load_img_data() && menu_init_fb());
    if (ret) {
        cur_menu = &root_menu;
        is_menu_init = true;
        output_stor = menu_get_output_stor_opt();

        menu_load_stor_list(true);

        menu_play_startup_anim();
    } else {
        menu_deinit();
    }

    return ret;
}

void menu_deinit(void) {
    menu_free_stor_list();

    menu_deinit_fb();

    menu_free_img_data();

    menu_deinit_ft_data();

    cur_menu = &root_menu;
    is_menu_init = false;
}

bool menu_loop(void) {
    if (!is_menu_init) return false;

    u32 elem_count = menu_get_elem_count(cur_menu);
    u32 page_size = menu_get_page_size(cur_menu);

    menu_t *parent_menu = cur_menu->parent;

    menu_font_type_t font_type = cur_menu->font_type;
    u32 font_size = cur_menu->font_size, font_color = cur_menu->font_color, font_color_hl = cur_menu->font_color_hl;
    int font_height = cur_menu->font_height;

    int x = cur_menu->element_x, y = cur_menu->element_y;
    int w = cur_menu->element_w, h = cur_menu->element_h;
    int sep = cur_menu->element_sep, hl_offset = cur_menu->hl_offset;

    u32 bg_color = cur_menu->bg_color, bg_color_hl = cur_menu->bg_color_hl;

    bool draw_sep = cur_menu->draw_sep, transparent_bg = cur_menu->transparent_bg, draw_icon_inside = cur_menu->draw_icon_inside;

    bool data_update = false;
    u64 btn_down = 0, btn_held = 0;

    bool ret = true;

    menu_start_frame();

    menu_draw_img_layers(cur_menu->img_layers);

    menu_draw_app_info();

    menu_draw_submenu_banner(parent_menu);

    for(u32 i = cur_menu->scroll; i < elem_count; i++) {
        if (i >= (cur_menu->scroll + page_size)) break;

        bool is_selected = (i == cur_menu->selected);

        menu_elem_t *cur_element = cur_menu->elements[i];
        menu_elem_toggle_t *toggle = cur_element->toggle;

        u32 str_color = (is_selected ? font_color_hl : font_color);
        menu_image_t *icon = ((is_selected && cur_element->icon_hl) ? cur_element->icon_hl : cur_element->icon);

        if (!transparent_bg) menu_draw_rect(bg_color, x, y, w, h);

        if (draw_sep) menu_draw_rect(font_color, x, y, w, 1);

        if (is_selected) {
            menu_draw_rect(bg_color_hl, x, y + hl_offset, w, h - (hl_offset * 2));
        } else if (cur_menu == &output_stor_menu && output_stor == i) {
            menu_draw_rect(COLOR_ORANGE, x, y + hl_offset, w, h - (hl_offset * 2));
        }

        if (toggle && !icon) {
            if (toggle->getter_func && !toggle->retrieved) {
                toggle->value = toggle->getter_func();
                toggle->retrieved = true;
            }

            menu_image_t *toggle_img = (toggle->value ? (is_selected ? &(menu_images[13]) : &(menu_images[15])) : &(menu_images[12]));

            if (!toggle->value && !is_selected) {
                menu_draw_rect(COLOR_BRICK, x, y + hl_offset, w, h - (hl_offset * 2));
                str_color = COLOR_VERMILION;
            }

            menu_draw_rgba888_img(toggle_img->rgba8888_img, x + 6, y + (h / 2) - (toggle_img->h / 2), toggle_img->w, toggle_img->h);
        }

        if (icon && !toggle) {
            int icon_x = (draw_icon_inside ? (x + (MENU_INTERNAL_ICON_WIDTH / 2) - (icon->w / 2)) : (x - icon->w - 2));
            menu_draw_rgba888_img(icon->rgba8888_img, icon_x, y + (h / 2) - (icon->h / 2), icon->w, icon->h);
        }

        if (cur_menu == &output_stor_menu) {
            menu_image_t *toggle_img = (output_stor == i ? (is_selected ? &(menu_images[13]) : &(menu_images[15])) : (is_selected ? &(menu_images[12]) : &(menu_images[14])));
            menu_draw_rgba888_img(toggle_img->rgba8888_img, (x + w) - (toggle_img->w + 6), y + (h / 2) - (toggle_img->h / 2), toggle_img->w, toggle_img->h);
        }

        if (cur_element->str_w <= 0 || font_height <= 0) {
            cur_element->str_w = menu_get_str_w(font_type, font_size, "%s", cur_element->str);
            cur_menu->font_height = font_height = (menu_fonts[font_type].font_face->size->metrics.height >> 6);
        }

        menu_draw_str(font_type, font_size, str_color, (SCREEN_WIDTH / 2) - (cur_element->str_w / 2), y + (h / 2) + (font_height / 4), NULL, "%s", cur_element->str);

        if (draw_sep) menu_draw_rect(font_color, x, y + (h - 1), w, 1);

        y += (h + sep);
    }

    menu_draw_scrollbar();

    menu_end_frame();

    while((ret = appletMainLoop())) {
        utilsScanPads();
        btn_down = utilsGetButtonsDown();
        btn_held = utilsGetButtonsHeld();
        if (btn_down || btn_held) break;

        if (umsIsDeviceInfoUpdated()) {
            menu_load_stor_list(true);
            data_update = true;
            break;
        }

        if (titleIsGameCardInfoUpdated()) {
            data_update = true;
            break;
        }

        utilsAppletLoopDelay();
    }

    if (!ret || data_update) goto out;

    menu_elem_t *selected_element = (elem_count ? cur_menu->elements[cur_menu->selected] : NULL);
    menu_elem_toggle_t *selected_element_toggle = (selected_element ? selected_element->toggle : NULL);

    if (selected_element && (btn_down & HidNpadButton_A)) {
        menu_t *child_menu = selected_element->child_menu;

        if (child_menu) {
            child_menu->parent = cur_menu;
            cur_menu = child_menu;
        } else if (selected_element->task_func) {
            if (selected_element->task_func() && output_stor != ConfigOutputStorage_UsbHost) menu_load_stor_list(false);
        } else if (selected_element_toggle) {
            selected_element_toggle->value ^= 1;
            selected_element_toggle->setter_func(selected_element_toggle->value);
        }
    } else if (parent_menu && (btn_down & HidNpadButton_B)) {
        cur_menu->selected = cur_menu->scroll = 0;
        cur_menu = parent_menu;
    } else if (btn_down & HidNpadButton_Plus) {
        ret = false;
    } else if (elem_count && ((btn_down & (HidNpadButton_Down | HidNpadButton_StickLDown)) || (btn_held & HidNpadButton_StickRDown))) {
        cur_menu->selected++;

        if (!cur_menu->elements[cur_menu->selected]) {
            if (btn_down & (HidNpadButton_Down | HidNpadButton_StickLDown)) {
                cur_menu->selected = 0;
                cur_menu->scroll = 0;
            } else {
                cur_menu->selected--;
            }
        } else if (cur_menu->selected > (cur_menu->scroll + (page_size / 2)) && elem_count > (cur_menu->scroll + page_size)) {
            cur_menu->scroll++;
        }
    } else if (elem_count && ((btn_down & (HidNpadButton_Up | HidNpadButton_StickLUp)) || (btn_held & HidNpadButton_StickRUp))) {
        cur_menu->selected--;

        if (cur_menu->selected == UINT32_MAX) {
            if (btn_down & (HidNpadButton_Up | HidNpadButton_StickLUp)) {
                cur_menu->selected = (elem_count - 1);
                cur_menu->scroll = (elem_count > page_size ? (elem_count - page_size) : 0);
            } else {
                cur_menu->selected = 0;
            }
        } else if (cur_menu->selected < (cur_menu->scroll + (page_size / 2)) && cur_menu->scroll > 0) {
            cur_menu->scroll--;
        }
    }

out:
    return ret;
}

static void menu_start_frame(void) {
    if (is_menu_init) {
        menu_end_frame();
        raw_fb = framebufferBegin(&fb, &raw_fb_row_w);
        raw_fb_row_w /= sizeof(u32);
    }
}

static void menu_end_frame(void) {
    if (is_menu_init && raw_fb) {
        framebufferEnd(&fb);
        raw_fb = NULL;
        raw_fb_row_w = 0;
    }
}

static void menu_draw_rect(u32 color, int x, int y, int w, int h) {
    if (!is_menu_init || !raw_fb || x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT || w <= 0 || h <= 0) return;

    if ((x + w) > SCREEN_WIDTH) w = (SCREEN_WIDTH - x);

    if ((y + h) > SCREEN_HEIGHT) h = (SCREEN_HEIGHT - y);

    for(int fy = y; fy < (y + h); fy++) {
        for(int fx = x; fx < (x + w); fx++) FB_PIXEL(fx, fy) = color;
    }
}

static void menu_draw_circle(u32 color, int x, int y, int r) {
    if (!is_menu_init || !raw_fb || x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT || r <= 0 ||
        (x - r) < 0 || (x + r) > SCREEN_WIDTH || (y - r) < 0 || (y + r) > SCREEN_HEIGHT) return;

    menu_draw_rect(color, x - r, y, r * 2, 1);

    for(int i = 1; i < r; i++) {
        int a = (int)sqrt((double)((r * r) - (i * i)));
        menu_draw_rect(color, x - a, y - i, a * 2, 1);
        menu_draw_rect(color, x - a, y + i, a * 2, 1);
    }
}

NX_INLINE void menu_draw_rgba888_img(const u8 *rgba8888_img, int x, int y, int w, int h) {
    _menu_draw_rgba888_img(rgba8888_img, (u8)RGBA8_MAX_ALPHA_VALUE, x, y, w, h);
}

NX_INLINE void menu_draw_rgba888_img_with_alpha(const u8 *rgba8888_img, u8 alpha, int x, int y, int w, int h) {
    _menu_draw_rgba888_img(rgba8888_img, alpha, x, y, w, h);
}

__attribute__((format(printf, 7, 8))) static void menu_draw_str(menu_font_type_t font_type, u32 size, u32 color, int x, int y, int *out_x, const char *fmt, ...) {
    if (!is_menu_init || !raw_fb || font_type >= FONT_TYPE_TOTAL || x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT || !fmt || !*fmt) return;

    va_list args;
    char *str = NULL;
    size_t str_len = 0;

    ssize_t units = 0;
    u32 code = 0;
    const u8 *p = NULL;

    FT_Face font_face = menu_fonts[font_type].font_face;
    FT_UInt glyph_idx = 0;
    FT_Error ft_res = 0;

    va_start(args, fmt);

    str_len = vsnprintf(NULL, 0, fmt, args);

    str = calloc(str_len + 1, sizeof(char));
    if (!str) {
        LOG_MSG_ERROR("calloc failed");
        goto out;
    }

    vsprintf(str, fmt, args);

    p = (const u8*)str;

    ft_res = FT_Set_Char_Size(font_face, 0, size << 6, 0, SCREEN_DPI_RES);
    if (ft_res) {
        LOG_MSG_ERROR("FT_Set_Char_Size failed (%d)", ft_res);
        goto out;
    }

    do {
        units = decode_utf8(&code, p);
        if (units <= 0) break;
        p += units;

        glyph_idx = FT_Get_Char_Index(font_face, code);

        ft_res = FT_Load_Glyph(font_face, glyph_idx, FT_LOAD_DEFAULT);
        if (!ft_res) ft_res = FT_Render_Glyph(font_face->glyph, FT_RENDER_MODE_NORMAL);
        if (ft_res) break;

        menu_draw_chr_bitmap(&(font_face->glyph->bitmap), color, x + font_face->glyph->bitmap_left, y - font_face->glyph->bitmap_top);

        x += (font_face->glyph->advance.x >> 6);
        y += (font_face->glyph->advance.y >> 6);
    } while(*p && x < SCREEN_WIDTH && y < SCREEN_HEIGHT);

    if (out_x) *out_x = x;

out:
    if (str) free(str);

    va_end(args);
}

__attribute__((format(printf, 3, 4))) static int menu_get_str_w(menu_font_type_t font_type, u32 size, const char *fmt, ...) {
    if (!is_menu_init || font_type >= FONT_TYPE_TOTAL || !fmt || !*fmt) return 0;

    va_list args;
    char *str = NULL;
    size_t str_len = 0;
    int w = 0;

    ssize_t units = 0;
    u32 code = 0;
    const u8 *p = NULL;

    FT_Face font_face = menu_fonts[font_type].font_face;
    FT_UInt glyph_idx = 0;
    FT_Error ft_res = 0;

    va_start(args, fmt);

    str_len = vsnprintf(NULL, 0, fmt, args);

    str = calloc(str_len + 1, sizeof(char));
    if (!str) {
        LOG_MSG_ERROR("calloc failed");
        goto out;
    }

    vsprintf(str, fmt, args);

    p = (const u8*)str;

    ft_res = FT_Set_Char_Size(font_face, 0, size << 6, 0, SCREEN_DPI_RES);
    if (ft_res) {
        LOG_MSG_ERROR("FT_Set_Char_Size failed (%d)", ft_res);
        goto out;
    }

    do {
        units = decode_utf8(&code, p);
        if (units <= 0) break;
        p += units;


        glyph_idx = FT_Get_Char_Index(font_face, code);

        ft_res = FT_Load_Glyph(font_face, glyph_idx, FT_LOAD_DEFAULT);
        if (!ft_res) ft_res = FT_Render_Glyph(font_face->glyph, FT_RENDER_MODE_NORMAL);
        if (ft_res) break;

        w += (font_face->glyph->advance.x >> 6);
    } while(*p);

out:
    if (str) free(str);

    va_end(args);

    return w;
}

static void menu_play_startup_anim(void) {
    menu_image_t *bg = &(menu_images[3]), *logo = &(menu_images[22]);
    int x = ((SCREEN_WIDTH / 2) - (logo->w / 2)), y = ((SCREEN_HEIGHT / 2) - (logo->h / 2));

    struct timespec start = {0}, now = {0};
    double diff = 0.0;

    utilsSetLongRunningProcessState(true);

    menu_start_frame();
    menu_draw_rgba888_img(bg->rgba8888_img, 0, 0, bg->w, bg->h);
    menu_draw_rgba888_img(logo->rgba8888_img, x, y, logo->w, logo->h);
    menu_end_frame();

    svcSleepThread((u64)(STARTUP_ANIM_STATIC_DURATION * 1000000000.0));

    clock_gettime(CLOCK_REALTIME, &start);

    do {
        menu_start_frame();

        menu_draw_rgba888_img(bg->rgba8888_img, 0, 0, bg->w, bg->h);

        u8 alpha = (u8)(RGBA8_MAX_ALPHA_VALUE - ((diff * RGBA8_MAX_ALPHA_VALUE) / STARTUP_ANIM_FADEOUT_DURATION));
        if (alpha) menu_draw_rgba888_img_with_alpha(logo->rgba8888_img, alpha, x, y, logo->w, logo->h);

        menu_end_frame();

        utilsAppletLoopDelay();

        clock_gettime(CLOCK_REALTIME, &now);
        diff = utilsDiffTimespec(&now, &start);
    } while(diff < STARTUP_ANIM_FADEOUT_DURATION);

    utilsSetLongRunningProcessState(false);
}

static u32 menu_get_elem_count(menu_t *menu) {
    if (!menu || !menu->elements || !menu->elements[0]) {
        if (menu) menu->elem_count = 0;
        return 0;
    }

    if (menu->elem_count) return menu->elem_count;

    u32 cnt = 0;
    while(menu->elements[cnt] != NULL) cnt++;

    menu->elem_count = cnt;
    return cnt;
}

static u32 menu_get_page_size(menu_t *menu) {
    if (!menu) return 0;

    if (menu->page_size) return menu->page_size;

    menu->page_size = MENU_DEFAULT_PAGE_SIZE;

    return menu->page_size;
}

static void menu_draw_img_layers(menu_img_layer_t **img_layers) {
    if (!img_layers) return;

    menu_img_layer_t *cur_img_layer = NULL;

    while((cur_img_layer = *img_layers++) != NULL) {
        if (cur_img_layer->x == MENU_IMAGE_CENTER) cur_img_layer->x = ((SCREEN_WIDTH / 2) - (cur_img_layer->img->w / 2));

        if (cur_img_layer->y == MENU_IMAGE_CENTER) cur_img_layer->y = ((SCREEN_HEIGHT / 2) - (cur_img_layer->img->h / 2));

        _menu_draw_rgba888_img(cur_img_layer->img->rgba8888_img, (u8)RGBA8_MAX_ALPHA_VALUE, cur_img_layer->x, cur_img_layer->y, cur_img_layer->img->w, cur_img_layer->img->h);
    }
}

static void menu_draw_app_info(void) {
    menu_draw_str(FONT_TYPE_SEMIBOLD, 22, COLOR_BUFF, 38, 52, NULL, APP_TITLE " v" APP_VERSION ".");
    menu_draw_str(FONT_TYPE_THIN, 22, COLOR_BUFF, 38, 84, NULL, "Built on " BUILD_TIMESTAMP ".");
}

static void menu_draw_submenu_banner(menu_t *parent_menu) {
    if (!parent_menu) return;

    menu_elem_t *parent_element = parent_menu->elements[parent_menu->selected];
    menu_image_t *icon = parent_element->icon;

    menu_font_type_t font_type = root_menu.font_type;
    u32 font_size = root_menu.font_size, font_color = root_menu.font_color;
    int font_height = root_menu.font_height;

    int x = root_menu.element_x, y = MENU_SUBMENU_NAME_Y_OFFSET, w = root_menu.element_w, h = root_menu.element_h;

    menu_draw_rect(font_color, x, y, w, 1);

    int str_w = menu_get_str_w(font_type, font_size, "%s", parent_element->str);
    menu_draw_str(font_type, font_size, font_color, (SCREEN_WIDTH / 2) - (str_w / 2), y + (h / 2) + (font_height / 4), NULL, "%s", parent_element->str);

    menu_draw_rect(font_color, x, y + (h - 1), w, 1);

    if (icon) menu_draw_rgba888_img(icon->rgba8888_img, x - icon->w - 2, y + (h / 2) - (icon->h / 2), icon->w, icon->h);
}

static void menu_draw_scrollbar(void) {
    if (cur_menu->elem_count <= cur_menu->page_size) return;

    int x = (cur_menu->element_x + cur_menu->element_w + MENU_SCROLLBAR_X_OFFSET);
    int y = (cur_menu->element_y + MENU_SCROLLBAR_OUTER_RADIUS);
    int w = MENU_SCROLLBAR_WIDTH;
    int h = (((cur_menu->element_h + cur_menu->element_sep) * (int)MIN(cur_menu->elem_count, cur_menu->page_size)) - (cur_menu->element_sep + (MENU_SCROLLBAR_OUTER_RADIUS * 2)));
    int dot_y = ((int)(((double)cur_menu->selected / (double)(cur_menu->elem_count - 1)) * (double)h) + y);

    menu_draw_rect(COLOR_BRICK, x, y, w, h);
    x += MENU_SCROLLBAR_OUTER_RADIUS;

    menu_draw_circle(COLOR_BRICK, x, y, MENU_SCROLLBAR_OUTER_RADIUS);
    menu_draw_circle(COLOR_BRICK, x, y + h, MENU_SCROLLBAR_OUTER_RADIUS);

    menu_draw_circle(COLOR_BUFF, x, dot_y, MENU_SCROLLBAR_INNER_RADIUS);
}

static bool menu_init_ft_data(void) {
    FT_Error ft_res = 0;
    bool ret = false;

    ft_res = FT_Init_FreeType(&ft_lib);
    if (ft_res) {
        LOG_MSG_ERROR("FT_Init_FreeType failed (%d)", ft_res);
        goto out;
    }

    for(u8 i = 0; i < FONT_TYPE_TOTAL; i++) {
        menu_font_t *cur_menu_font = &(menu_fonts[i]);

        cur_menu_font->ttf = utilsLoadFileToMemory(cur_menu_font->path, &(cur_menu_font->ttf_size));
        if (!cur_menu_font->ttf) {
            LOG_MSG_ERROR("Failed to load font %s", cur_menu_font->path);
            goto out;
        }

        ft_res = FT_New_Memory_Face(ft_lib, cur_menu_font->ttf, cur_menu_font->ttf_size, 0, &(cur_menu_font->font_face));
        if (ft_res) {
            LOG_MSG_ERROR("FT_New_Memory_Face failed (%u, %d)", i, ft_res);
            goto out;
        }
    }

    ret = true;

out:
    return ret;
}

static void menu_deinit_ft_data(void) {
    for(u8 i = 0; i < FONT_TYPE_TOTAL; i++) {
        menu_font_t *cur_menu_font = &(menu_fonts[i]);

        if (cur_menu_font->ttf) {
            free(cur_menu_font->ttf);
            cur_menu_font->ttf = NULL;
        }

        if (cur_menu_font->font_face) {
            FT_Done_Face(cur_menu_font->font_face);
            cur_menu_font->font_face = NULL;
        }

        cur_menu_font->ttf_size = 0;
    }

    if (ft_lib) {
        FT_Done_FreeType(ft_lib);
        ft_lib = NULL;
    }
}

static bool menu_load_img_data(void) {
    bool ret = true;

    for(u32 i = 0; i < menu_images_cnt; i++) {
        menu_image_t *cur_menu_img = &(menu_images[i]);
        bool is_png = (strcasecmp(strrchr(cur_menu_img->path, '.'), ".png") == 0);

        if (is_png) {
            cur_menu_img->rgba8888_img = utilsLoadRgba8888ImageFromPngFile(cur_menu_img->path, &(cur_menu_img->w), &(cur_menu_img->h));
        } else {
            cur_menu_img->rgba8888_img = utilsLoadRgba8888ImageFromJpegFile(cur_menu_img->path, &(cur_menu_img->w), &(cur_menu_img->h));
        }

        if (!cur_menu_img->rgba8888_img) {
            LOG_MSG_ERROR("Failed to load img %s", cur_menu_img->path);
            ret = false;
            break;
        }
    }

    return ret;
}

static void menu_free_img_data(void) {
    for(u32 i = 0; i < menu_images_cnt; i++) {
        menu_image_t *cur_menu_img = &(menu_images[i]);

        if (cur_menu_img->rgba8888_img) {
            free(cur_menu_img->rgba8888_img);
            cur_menu_img->rgba8888_img = NULL;
        }

        cur_menu_img->w = cur_menu_img->h = 0;
    }
}

static bool menu_init_fb(void) {
    Result res = 0;

    res = framebufferCreate(&fb, nwindowGetDefault(), SCREEN_WIDTH, SCREEN_HEIGHT, PIXEL_FORMAT_RGBA_8888, 2);
    if (R_FAILED(res)) {
        LOG_MSG_ERROR("framebufferCreate failed (0x%X)", res);
        return false;
    }

    res = framebufferMakeLinear(&fb);
    if (R_FAILED(res)) {
        LOG_MSG_ERROR("framebufferMakeLinear failed (0x%X)", res);
        return false;
    }

    return true;
}

NX_INLINE void menu_deinit_fb(void) {
    framebufferClose(&fb);
}

static void _menu_draw_rgba888_img(const u8 *rgba8888_img, u8 alpha, int x, int y, int w, int h) {
    if (!is_menu_init || !raw_fb || !rgba8888_img || x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT || w <= 0 || h <= 0) return;

    for(int fy = y, iy = 0; fy < (y + h); fy++, iy++) {
        if (fy >= SCREEN_HEIGHT) break;

        for(int fx = x, ix = 0; fx < (x + w); fx++, ix++) {
            if (fx >= SCREEN_WIDTH) break;

            u32 pos = (u32)(((iy * w) + ix) * 4);
            u32 img_pxl = *((u32*)(rgba8888_img + pos));

            u8 img_a = RGBA8_ALPHA_CHANNEL(img_pxl);
            img_a = MIN(img_a, alpha);
            if (!img_a) continue;

            if (img_a == (u8)RGBA8_MAX_ALPHA_VALUE) {
                FB_PIXEL(fx, fy) = img_pxl;
            } else {
                u32 fb_pxl = FB_PIXEL(fx, fy);

                u8 fb_r = RGBA8_RED_CHANNEL(fb_pxl), fb_g = RGBA8_GREEN_CHANNEL(fb_pxl), fb_b = RGBA8_BLUE_CHANNEL(fb_pxl);

                u8 img_r = RGBA8_RED_CHANNEL(img_pxl), img_g = RGBA8_GREEN_CHANNEL(img_pxl), img_b = RGBA8_BLUE_CHANNEL(img_pxl);

                float p = ((float)img_a / RGBA8_MAX_ALPHA_VALUE);

                u8 r = ALPHA_BLEND_COLORS(fb_r, img_r, p), g = ALPHA_BLEND_COLORS(fb_g, img_g, p), b = ALPHA_BLEND_COLORS(fb_b, img_b, p);

                FB_PIXEL(fx, fy) = RGBA8_MAXALPHA(r, g, b);
            }
        }
    }
}

static void menu_draw_chr_bitmap(const FT_Bitmap *bitmap, u32 color, int x, int y) {
    if (!bitmap || bitmap->pixel_mode != FT_PIXEL_MODE_GRAY || x < 0 || x >= SCREEN_WIDTH || y < 0 || y >= SCREEN_HEIGHT) return;

    int w = (int)bitmap->width, h = (int)bitmap->rows;
    const u8 *ptr = bitmap->buffer;

    u8 chr_r = RGBA8_RED_CHANNEL(color), chr_g = RGBA8_GREEN_CHANNEL(color), chr_b = RGBA8_BLUE_CHANNEL(color);
    u32 chr_color = RGBA8_MAXALPHA(chr_r, chr_g, chr_b);

    for(int fy = y; fy < (y + h); fy++) {
        if (fy >= SCREEN_HEIGHT) break;

        for(int fx = x, bx = 0; fx < (x + w); fx++, bx++) {
            if (fx >= SCREEN_WIDTH) break;

            u8 a = ptr[bx];
            if (!a) continue;

            if (a == (u8)RGBA8_MAX_ALPHA_VALUE) {
                FB_PIXEL(fx, fy) = chr_color;
            } else {
                u32 fb_pxl = FB_PIXEL(fx, fy);

                u8 fb_r = RGBA8_RED_CHANNEL(fb_pxl), fb_g = RGBA8_GREEN_CHANNEL(fb_pxl), fb_b = RGBA8_BLUE_CHANNEL(fb_pxl);

                float p = ((float)a / RGBA8_MAX_ALPHA_VALUE);

                u8 r = ALPHA_BLEND_COLORS(fb_r, chr_r, p), g = ALPHA_BLEND_COLORS(fb_g, chr_g, p), b = ALPHA_BLEND_COLORS(fb_b, chr_b, p);

                FB_PIXEL(fx, fy) = RGBA8_MAXALPHA(r, g, b);
            }
        }

        ptr += bitmap->pitch;
    }
}

static void menu_load_stor_list(bool reset_storage) {
    u32 elem_count = 0, idx = 0;

    menu_free_stor_list();

    usb_storages = umsGetDevices(&usb_storages_cnt);
    elem_count = (ConfigOutputStorage_Count + usb_storages_cnt);

    output_stor_menu_elem = calloc(elem_count + 1, sizeof(menu_elem_t*));

    for(u32 i = 0; i < elem_count; i++) {
        u64 total = 0, free = 0;
        char total_str[36] = {0}, free_str[32] = {0};

        if (!output_stor_menu_elem[idx]) {
            output_stor_menu_elem[idx] = calloc(1, sizeof(menu_elem_t));
            output_stor_menu_elem[idx]->str = calloc(sizeof(char), 0x300);
            output_stor_menu_elem[idx]->task_func = &menu_set_output_stor_opt;
        }

        if (i == 1) {
            sprintf(output_stor_menu_elem[idx]->str, "PC");
            output_stor_menu_elem[idx]->icon = &(menu_images[7]);
            output_stor_menu_elem[idx]->icon_hl = &(menu_images[8]);
        } else {
            UsbHsFsDevice *ums_device = (i >= ConfigOutputStorage_Count ? &(usb_storages[i - ConfigOutputStorage_Count]) : NULL);

            sprintf(total_str, "%s/", i == 0 ? DEVOPTAB_SDMC_DEVICE : ums_device->name);
            utilsGetFileSystemStatsByPath(total_str, &total, &free);
            utilsGenerateFormattedSizeString(total, total_str, sizeof(total_str));
            utilsGenerateFormattedSizeString(free, free_str, sizeof(free_str));

            if (i == 0) {
                sprintf(output_stor_menu_elem[idx]->str, "MICRO SD (%s FREE / %s TOTAL)", free_str, total_str);

                output_stor_menu_elem[idx]->icon = &(menu_images[9]);
                output_stor_menu_elem[idx]->icon_hl = &(menu_images[10]);
            } else {
                sprintf(output_stor_menu_elem[idx]->str, "%s", ums_device->name);

                char c, *ptr = output_stor_menu_elem[idx]->str;

                while((c = *ptr)) {
                    if (c == ':') {
                        *ptr = '\0';
                        break;
                    }

                    *ptr++ = toupper(c);
                }

                ptr = output_stor_menu_elem[idx]->str;
                sprintf(ptr + strlen(ptr), " (%s) (%s FREE / %s TOTAL)", LIBUSBHSFS_FS_TYPE_STR(ums_device->fs_type), free_str, total_str);

                output_stor_menu_elem[idx]->icon = &(menu_images[16]);
                output_stor_menu_elem[idx]->icon_hl = &(menu_images[17]);
            }
        }

        idx++;
    }

    output_stor_menu.elements = output_stor_menu_elem;

    output_stor_menu.selected = output_stor_menu.scroll = 0;

    output_stor_menu.elem_count = elem_count;

    if (reset_storage && output_stor >= ConfigOutputStorage_Count) menu_set_output_stor_opt();
}

static void menu_free_stor_list(void) {
    u32 elem_count = (2 + usb_storages_cnt);

    if (output_stor_menu_elem) {
        for(u32 i = 0; i < elem_count && output_stor_menu_elem[i]; i++) {
            if (output_stor_menu_elem[i]->str) {
                free(output_stor_menu_elem[i]->str);
                output_stor_menu_elem[i]->str = NULL;
            }

            free(output_stor_menu_elem[i]);
            output_stor_menu_elem[i] = NULL;
        }

        free(output_stor_menu_elem);
        output_stor_menu_elem = NULL;
    }

    if (usb_storages) {
        free(usb_storages);
        usb_storages = NULL;
    }

    usb_storages_cnt = 0;

    output_stor_menu.elements = NULL;
}

static u32 menu_get_output_stor_opt(void)
{
    return (u32)configGetInteger("output_storage");
}

static bool menu_set_output_stor_opt(void)
{
    u32 value = output_stor_menu.selected;
    output_stor = value;
    if (value < ConfigOutputStorage_Count) configSetInteger("output_storage", (int)value);
    return false;
}

static bool menu_get_dump_xci_opt(void) {
    return configGetBoolean("advanced/dump_xci");
}

static void menu_set_dump_xci_opt(bool value) {
    configSetBoolean("advanced/dump_xci", value);
}

static bool menu_get_dump_initial_data_opt(void) {
    return configGetBoolean("advanced/dump_initial_data");
}

static void menu_set_dump_initial_data_opt(bool value) {
    configSetBoolean("advanced/dump_initial_data", value);
}

static bool menu_get_dump_cert_opt(void) {
    return configGetBoolean("advanced/dump_certificate");
}

static void menu_set_dump_cert_opt(bool value) {
    configSetBoolean("advanced/dump_certificate", value);
}

static bool menu_get_dump_card_id_set_opt(void) {
    return configGetBoolean("advanced/dump_card_id_set");
}

static void menu_set_dump_card_id_set_opt(bool value) {
    configSetBoolean("advanced/dump_card_id_set", value);
}

static bool menu_get_dump_card_uid_opt(void) {
    return configGetBoolean("advanced/dump_card_uid");
}

static void menu_set_dump_card_uid_opt(bool value) {
    configSetBoolean("advanced/dump_card_uid", value);
}

static bool menu_easy_one_click_proc(void) {
    Thread thread = {0};

    dumper_thrd_data_t thread_data = {
        .mutex = 0,
        .data_written = 0,
        .total_size = 0,
        .error = false,
        .transfer_cancelled = false,
        .dump_xci = menu_get_dump_xci_opt(),
        .dump_initial_data = menu_get_dump_initial_data_opt(),
        .dump_certificate = menu_get_dump_cert_opt(),
        .dump_card_id_set = menu_get_dump_card_id_set_opt(),
        .dump_card_uid = menu_get_dump_card_uid_opt(),
        .output_storage = output_stor,
        .ums_device = (output_stor >= ConfigOutputStorage_Count ? &(usb_storages[output_stor - ConfigOutputStorage_Count]) : NULL)
    };

    size_t total_size = 0, data_written = 0;

    u8 kazatchok_idx = 0;
    menu_img_layer_t *kazatchok_layer = progress_img_layers[4];
    kazatchok_layer->img = &(menu_images[18]);

    struct timespec total_ts = {0}, btn_cancel_ts = {0}, kazatchok_ts = {0}, now = {0};
    double btn_cancel_time_diff = 0.0, kazatchok_time_diff = 0.0;
    bool btn_cancel_cur_state = false, btn_cancel_prev_state = false;

    bool display_error = true, thread_created = false, prep_failed = false, applet_status = true, thread_error = false, ret = false;

    if (!thread_data.dump_xci && !thread_data.dump_initial_data && !thread_data.dump_certificate && !thread_data.dump_card_id_set && !thread_data.dump_card_uid) {
        LOG_MSG_ERROR("ALL ADVANCED OPTIONS ARE DISABLED. PLEASE ENABLE AT LEAST ONE OPTION.");
        goto out;
    }

    if (!menu_wait_gc(&display_error)) goto out;

    if (!menu_wait_usb()) {
        display_error = false;
        goto out;
    }

    utilsSetLongRunningProcessState(true);

    if (!utilsCreateThread(&thread, dumper_save_mig_switch_data, &thread_data, 2)) goto out;

    thread_created = true;

    while(true) {
        SCOPED_LOCK(&(thread_data.mutex)) {
            if (thread_data.total_size) total_size = thread_data.total_size;
            if (thread_data.error) prep_failed = true;
        }

        if (total_size || prep_failed) break;

        utilsAppletLoopDelay();
    }

    if (prep_failed) goto out;

    clock_gettime(CLOCK_REALTIME, &total_ts);
    kazatchok_ts = total_ts;

    while((applet_status = appletMainLoop())) {
        SCOPED_LOCK(&(thread_data.mutex)) {
            if (thread_data.error) {
                thread_error = true;
            } else {
                data_written = thread_data.data_written;
            }
        }

        if (thread_error || data_written >= total_size) break;

        clock_gettime(CLOCK_REALTIME, &now);

        utilsScanPads();
        btn_cancel_cur_state = (utilsGetButtonsHeld() & HidNpadButton_B);

        if (btn_cancel_cur_state && btn_cancel_cur_state != btn_cancel_prev_state) {
            btn_cancel_ts = now;
        } else if (btn_cancel_cur_state && btn_cancel_cur_state == btn_cancel_prev_state) {
            btn_cancel_time_diff = utilsDiffTimespec(&now, &btn_cancel_ts);
            if (btn_cancel_time_diff >= MENU_DUMPER_CANCEL_TIMEOUT) {
                SCOPED_LOCK(&(thread_data.mutex)) thread_data.transfer_cancelled = true;
                LOG_MSG_ERROR("PROCESS CANCELLED BY USER");
                break;
            }
        }

        btn_cancel_prev_state = btn_cancel_cur_state;

        kazatchok_time_diff = utilsDiffTimespec(&now, &kazatchok_ts);

        if (kazatchok_time_diff >= MENU_KAZATCHOK_FRAME_DELAY) {
            kazatchok_idx++;
            if (kazatchok_idx >= MENU_KAZATCHOK_MAX_IDX) kazatchok_idx = 0;
            kazatchok_layer->img = &(menu_images[18 + kazatchok_idx]);
            kazatchok_ts = now;
        }

        menu_start_frame();

        menu_draw_img_layers(progress_img_layers);

        menu_draw_app_info();

        menu_draw_rect(COLOR_BUFF, MENU_PROGRESSBAR_OUTER_X, MENU_PROGRESSBAR_OUTER_Y, MENU_PROGRESSBAR_OUTER_WIDTH, MENU_PROGRESSBAR_OUTER_HEIGHT);

        int pb_w = (((double)data_written / (double)total_size) * (double)MENU_PROGRESSBAR_INNER_WIDTH);
        int pb_x = 0, pb_chunk_w = MENU_PROGRESSBAR_CHUNK_WIDTH;

        while(pb_x < pb_w) {
            if (pb_chunk_w == MENU_PROGRESSBAR_CHUNK_WIDTH) {
                if ((pb_x + pb_chunk_w) > pb_w) pb_chunk_w = (pb_w - pb_x);

                menu_draw_rect(COLOR_VERMILION, MENU_PROGRESSBAR_INNER_X + pb_x, MENU_PROGRESSBAR_INNER_Y, pb_chunk_w, MENU_PROGRESSBAR_INNER_HEIGHT);

                pb_x += pb_chunk_w;
                pb_chunk_w = MENU_PROGRESSBAR_CHUNK_SEPARATION;
            } else {
                pb_x += pb_chunk_w;
                pb_chunk_w = MENU_PROGRESSBAR_CHUNK_WIDTH;
            }
        }

        menu_end_frame();

        utilsAppletLoopDelay();
    }

    if (!applet_status) {
        SCOPED_LOCK(&(thread_data.mutex)) thread_data.transfer_cancelled = true;
        display_error = false;
        goto out;
    }

    ret = (!thread_error && data_written >= total_size);

out:
    if (thread_created) utilsJoinThread(&thread);

    utilsSetLongRunningProcessState(false);

    if (ret) {
        menu_show_success();
    } else {
        if (display_error) menu_show_error();
    }

    return ret;
}

static bool menu_wait_gc(bool *display_error) {
    const char *not_inserted_msg = "PLEASE INSERT A GAMECARD TO PROCEED";
    int not_inserted_msg_w = menu_get_str_w(FONT_TYPE_EXTRABOLD, 24, "%s", not_inserted_msg);

    const char *processing_msg = "PROCESSING GAMECARD, PLEASE WAIT...";
    int processing_msg_w = menu_get_str_w(FONT_TYPE_EXTRABOLD, 24, "%s", processing_msg);

    u8 cur_status = GameCardStatus_NotInserted, prev_status = GameCardStatus_InsertedAndInfoLoaded;
    bool applet_status = true, cancel = false, ret = true;

    while((applet_status = appletMainLoop())) {
        if ((cur_status = gamecardGetStatus()) > GameCardStatus_Processing) break;

        if (cur_status != prev_status) {
            menu_start_frame();

            menu_draw_img_layers(cur_status == GameCardStatus_NotInserted ? no_connect_img_layers : gc_processing_img_layers);

            menu_draw_app_info();

            menu_image_t *icon = (cur_status == GameCardStatus_NotInserted ? &(menu_images[28]) : &(menu_images[29]));
            menu_draw_rgba888_img(icon->rgba8888_img, (SCREEN_WIDTH / 2) - (icon->w / 2), (SCREEN_HEIGHT / 2) - (50 + icon->h), icon->w, icon->h);

            const char *msg = (cur_status == GameCardStatus_NotInserted ? not_inserted_msg : processing_msg);
            int str_w = (cur_status == GameCardStatus_NotInserted ? not_inserted_msg_w : processing_msg_w);
            menu_draw_str(FONT_TYPE_EXTRABOLD, 24, COLOR_BUFF, (SCREEN_WIDTH / 2) - (str_w / 2), (SCREEN_HEIGHT / 2) - 15, NULL, "%s", msg);

            menu_end_frame();

            prev_status = cur_status;
        }

        if (cur_status == GameCardStatus_NotInserted) {
            utilsScanPads();
            u64 btn_down = utilsGetButtonsDown();
            if (btn_down & HidNpadButton_B) {
                cancel = true;
                break;
            }
        }

        utilsAppletLoopDelay();
    }

    if (!applet_status || cancel) {
        *display_error = ret = false;
    } else if (cur_status != GameCardStatus_InsertedAndInfoLoaded) {
        if (cur_status == GameCardStatus_NoGameCardPatchEnabled) {
            LOG_MSG_ERROR("\"NOGC\" PATCH IS ENABLED. PLEASE DISABLE IT BEFORE LAUNCHING A CFW.");
        } else if (cur_status == GameCardStatus_LotusAsicFirmwareUpdateRequired) {
            LOG_MSG_ERROR("GAMECARD CONTROLLER UPDATE REQUIRED. PLEASE UPDATE YOUR CONSOLE.");
        }

        *display_error = true;
        ret = false;
    }

    return ret;
}

static bool menu_wait_usb(void) {
    if (output_stor != ConfigOutputStorage_UsbHost) return true;

    const char *msg1 = "PLEASE CONNECT THE CONSOLE TO A PC TO PROCEED";
    int msg1_w = menu_get_str_w(FONT_TYPE_EXTRABOLD, 24, "%s", msg1);

    const char *msg2 = "MAKE SURE TO RUN THE HOST SERVER PROGRAM ON THE PC";
    int msg2_w = menu_get_str_w(FONT_TYPE_EXTRABOLD, 24, "%s", msg2);

    menu_image_t *no_pc_icon = &(menu_images[27]);

    u8 usb_host_speed = UsbHostSpeed_None;
    bool applet_status = true, cancel = false, msg_drawn = false, ret = true;

    while((applet_status = appletMainLoop())) {
        if ((usb_host_speed = usbIsReady()) != UsbHostSpeed_None) break;

        if (!msg_drawn) {
            menu_start_frame();

            menu_draw_img_layers(no_connect_img_layers);

            menu_draw_app_info();

            menu_draw_rgba888_img(no_pc_icon->rgba8888_img, (SCREEN_WIDTH / 2) - (no_pc_icon->w / 2), (SCREEN_HEIGHT / 2) - (50 + no_pc_icon->h), no_pc_icon->w, no_pc_icon->h);

            menu_draw_str(FONT_TYPE_EXTRABOLD, 24, COLOR_BUFF, (SCREEN_WIDTH / 2) - (msg1_w / 2), (SCREEN_HEIGHT / 2) - 15, NULL, "%s", msg1);
            menu_draw_str(FONT_TYPE_EXTRABOLD, 24, COLOR_BUFF, (SCREEN_WIDTH / 2) - (msg2_w / 2), (SCREEN_HEIGHT / 2) + 25, NULL, "%s", msg2);

            menu_end_frame();

            msg_drawn = true;
        }

        utilsScanPads();
        u64 btn_down = utilsGetButtonsDown();
        if (btn_down & HidNpadButton_B) {
            cancel = true;
            break;
        }

        utilsAppletLoopDelay();
    }

    if (!applet_status || cancel) ret = false;

    return ret;
}

static void menu_show_success(void) {
    const char *btn_prompt = "PRESS ANY BUTTON TO GO BACK TO THE MAIN MENU";
    int str_w = 0;

    menu_start_frame();

    menu_draw_img_layers(success_img_layers);

    menu_draw_app_info();

    str_w = menu_get_str_w(FONT_TYPE_EXTRABOLD, 15, "%s", btn_prompt);
    menu_draw_str(FONT_TYPE_EXTRABOLD, 15, COLOR_BUFF, (SCREEN_WIDTH / 2) - (str_w / 2), SCREEN_HEIGHT - 185, NULL, "%s", btn_prompt);

    menu_end_frame();

    utilsWaitForButtonPress(0);
}

static void menu_show_error(void) {
    char *msg = NULL, *msg_start = NULL, c;
    const char *btn_prompt = "PRESS ANY BUTTON TO GO BACK TO THE MAIN MENU";
    int str_w = 0, y = (SCREEN_HEIGHT - 56);

    menu_start_frame();

    menu_draw_img_layers(error_img_layers);

    menu_draw_app_info();

    msg = logGetLastMessage();
    if (msg) {
        msg_start = (strchr(msg, ':') + 2);

        char *ptr = msg_start;
        while((c = *ptr)) *ptr++ = toupper(c);

        str_w = menu_get_str_w(FONT_TYPE_EXTRABOLD, 15, "ERROR: %s", msg_start);
        menu_draw_str(FONT_TYPE_EXTRABOLD, 15, COLOR_BUFF, (SCREEN_WIDTH / 2) - (str_w / 2), y, NULL, "ERROR: %s", msg_start);
        y += 23;

        free(msg);
    }

    str_w = menu_get_str_w(FONT_TYPE_EXTRABOLD, 15, "%s", btn_prompt);
    menu_draw_str(FONT_TYPE_EXTRABOLD, 15, COLOR_BUFF, (SCREEN_WIDTH / 2) - (str_w / 2), y, NULL, "%s", btn_prompt);

    menu_end_frame();

    utilsWaitForButtonPress(0);
}
