/*
 * title.c
 *
 * Copyright (c) 2020-2023, DarkMatterCore <pabloacurielz@gmail.com>.
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "utils.h"
#include "title.h"
#include "gamecard.h"

#define NS_APPLICATION_RECORD_BLOCK_SIZE    1024

/* Type definitions. */

typedef struct {
    NcmContentMetaDatabase ncm_db;
    NcmContentStorage ncm_storage;
    TitleInfo **titles;
    u32 title_count;
} TitleStorage;

/* Global variables. */

static Mutex g_titleMutex = 0;

static Thread g_titleGameCardInfoThread = {0};
static UEvent g_titleGameCardInfoThreadExitEvent = {0}, *g_titleGameCardStatusChangeUserEvent = NULL;
static bool g_titleInterfaceInit = false, g_titleGameCardInfoThreadCreated = false, g_titleGameCardAvailable = false, g_titleGameCardInfoUpdated = false;

static NsApplicationControlData *g_nsAppControlData = NULL;

static TitleApplicationMetadata **g_appMetadata = NULL;
static u32 g_appMetadataCount = 0;

static TitleStorage g_titleStorage = {0};

/* Function prototypes. */

NX_INLINE void titleFreeApplicationMetadata(void);
static bool titleReallocateApplicationMetadata(u32 extra_app_count, bool free_entries);

static bool titleInitializeTitleStorage(void);
static void titleCloseTitleStorage(void);
static bool titleReallocateTitleInfoFromStorage(u32 extra_title_count, bool free_entries);

static bool titleGenerateMetadataEntriesFromNsRecords(void);
static bool titleRetrieveUserApplicationMetadataByTitleId(u64 title_id, TitleApplicationMetadata *out);

NX_INLINE TitleApplicationMetadata *titleFindApplicationMetadataByTitleId(u64 title_id, u32 extra_app_count);

NX_INLINE u64 titleGetApplicationIdByContentMetaKey(const NcmContentMetaKey *meta_key);

static bool titleGenerateTitleInfoEntriesForTitleStorage(void);
static bool titleGetMetaKeysFromContentDatabase(NcmContentMetaDatabase *ncm_db, NcmContentMetaKey **out_meta_keys, u32 *out_meta_key_count);
static bool titleGetContentInfosForMetaKey(NcmContentMetaDatabase *ncm_db, const NcmContentMetaKey *meta_key, NcmContentInfo **out_content_infos, u32 *out_content_count);

static void titleUpdateTitleInfoLinkedLists(void);

static bool titleCreateGameCardInfoThread(void);
static void titleDestroyGameCardInfoThread(void);
static void titleGameCardInfoThreadFunc(void *arg);

static bool titleRefreshGameCardTitleInfo(void);

static TitleInfo *_titleGetInfoFromStorageByTitleId(u64 title_id);

static TitleInfo *titleDuplicateTitleInfoFull(TitleInfo *title_info, TitleInfo *previous, TitleInfo *next);
static TitleInfo *titleDuplicateTitleInfo(TitleInfo *title_info);

static int titleUserApplicationMetadataEntrySortFunction(const void *a, const void *b);
static int titleInfoEntrySortFunction(const void *a, const void *b);

bool titleInitialize(void)
{
    bool ret = false;

    SCOPED_LOCK(&g_titleMutex)
    {
        ret = g_titleInterfaceInit;
        if (ret) break;

        /* Allocate memory for the ns application control data. */
        /* This will be used each time we need to retrieve the metadata from an application. */
        g_nsAppControlData = calloc(1, sizeof(NsApplicationControlData));
        if (!g_nsAppControlData)
        {
            LOG_MSG_ERROR("Failed to allocate memory for the ns application control data!");
            break;
        }

        /* Generate application metadata entries from ns records. */
        /* Theoretically speaking, we should only need to do this once. */
        /* However, if any new gamecard is inserted while the application is running, we *will* have to retrieve the metadata from its application(s). */
        if (!titleGenerateMetadataEntriesFromNsRecords())
        {
            LOG_MSG_ERROR("Failed to generate application metadata from ns records!");
            break;
        }

        /* Create user-mode exit event. */
        ueventCreate(&g_titleGameCardInfoThreadExitEvent, true);

        /* Retrieve gamecard status change user event. */
        g_titleGameCardStatusChangeUserEvent = gamecardGetStatusChangeUserEvent();
        if (!g_titleGameCardStatusChangeUserEvent)
        {
            LOG_MSG_ERROR("Failed to retrieve gamecard status change user event!");
            break;
        }

        /* Create gamecard title info thread. */
        if (!(g_titleGameCardInfoThreadCreated = titleCreateGameCardInfoThread())) break;

        /* Update flags. */
        ret = g_titleInterfaceInit = true;
    }

    return ret;
}

void titleExit(void)
{
    SCOPED_LOCK(&g_titleMutex)
    {
        /* Destroy gamecard detection thread. */
        if (g_titleGameCardInfoThreadCreated)
        {
            titleDestroyGameCardInfoThread();
            g_titleGameCardInfoThreadCreated = false;
        }

        /* Close title storage. */
        titleCloseTitleStorage();

        /* Free application metadata. */
        titleFreeApplicationMetadata();

        /* Free ns application control data. */
        if (g_nsAppControlData)
        {
            free(g_nsAppControlData);
            g_nsAppControlData = NULL;
        }

        g_titleInterfaceInit = false;
    }
}

TitleApplicationMetadata **titleGetGameCardApplicationMetadataEntries(u32 *out_count)
{
    u32 app_count = 0;
    TitleApplicationMetadata **app_metadata = NULL, **tmp_app_metadata = NULL;

    SCOPED_LOCK(&g_titleMutex)
    {
        if (!g_titleInterfaceInit || !g_appMetadata || !g_appMetadataCount || !g_titleGameCardAvailable || !out_count)
        {
            LOG_MSG_ERROR("Invalid parameters!");
            break;
        }

        bool error = false;

        for(u32 i = 0; i < g_appMetadataCount; i++)
        {
            TitleApplicationMetadata *cur_app_metadata = g_appMetadata[i];
            if (!cur_app_metadata) continue;

            /* Skip current metadata entry if content data for this title isn't available on the inserted gamecard. */
            if (!_titleGetInfoFromStorageByTitleId(cur_app_metadata->title_id)) continue;

            /* Reallocate application metadata pointer array. */
            tmp_app_metadata = realloc(app_metadata, (app_count + 1) * sizeof(TitleApplicationMetadata*));
            if (!tmp_app_metadata)
            {
                LOG_MSG_ERROR("Failed to reallocate application metadata pointer array!");
                if (app_metadata) free(app_metadata);
                app_metadata = NULL;
                error = true;
                break;
            }

            app_metadata = tmp_app_metadata;
            tmp_app_metadata = NULL;

            /* Set current pointer and increase counter. */
            app_metadata[app_count++] = cur_app_metadata;
        }

        if (error) break;

        /* Update output counter. */
        *out_count = app_count;

        if (!app_metadata || !app_count) LOG_MSG_ERROR("No gamecard content data found for user applications!");
    }

    return app_metadata;
}

void titleFreeTitleInfo(TitleInfo **info)
{
    TitleInfo *ptr = NULL, *tmp1 = NULL, *tmp2 = NULL;
    if (!info || !(ptr = *info)) return;

    /* Free content infos. */
    if (ptr->content_infos) free(ptr->content_infos);

    /* Free previous sibling(s). */
    tmp1 = ptr->previous;
    while(tmp1)
    {
        tmp2 = tmp1->previous;
        tmp1->previous = tmp1->next = NULL;
        titleFreeTitleInfo(&tmp1);
        tmp1 = tmp2;
    }

    /* Free next sibling(s). */
    tmp1 = ptr->next;
    while(tmp1)
    {
        tmp2 = tmp1->next;
        tmp1->previous = tmp1->next = NULL;
        titleFreeTitleInfo(&tmp1);
        tmp1 = tmp2;
    }

    free(ptr);
    *info = NULL;
}

bool titleGetUserApplicationData(u64 app_id, TitleUserApplicationData *out)
{
    bool ret = false;

    SCOPED_LOCK(&g_titleMutex)
    {
        if (!g_titleInterfaceInit || !app_id || !out)
        {
            LOG_MSG_ERROR("Invalid parameters!");
            break;
        }

        bool error = false;
        TitleInfo *app_info = NULL, *patch_info = NULL, *aoc_info = NULL, *aoc_patch_info = NULL;

        /* Clear output. */
        titleFreeUserApplicationData(out);

#define TITLE_ALLOCATE_USER_APP_DATA(elem, msg, decl) \
    if (elem##_info && !out->elem##_info) { \
        out->elem##_info = titleDuplicateTitleInfoFull(elem##_info, NULL, NULL); \
        if (!out->elem##_info) { \
            LOG_MSG_ERROR("Failed to duplicate %s info for %016lX!", msg, app_id); \
            decl; \
        } \
    }

        /* Get info for the first user application title. */
        app_info = _titleGetInfoFromStorageByTitleId(app_id);
        TITLE_ALLOCATE_USER_APP_DATA(app, "user application", break);

        /* Get info for the first patch title. */
        patch_info = _titleGetInfoFromStorageByTitleId(titleGetPatchIdByApplicationId(app_id));
        TITLE_ALLOCATE_USER_APP_DATA(patch, "patch", break);

        /* Get info for the first add-on content and add-on content patch titles. */
        if (g_titleStorage.titles && g_titleStorage.title_count)
        {
            for(u32 i = 0; i < g_titleStorage.title_count; i++)
            {
                TitleInfo *title_info = g_titleStorage.titles[i];
                if (!title_info) continue;

                if (title_info->meta_key.type == NcmContentMetaType_AddOnContent && titleCheckIfAddOnContentIdBelongsToApplicationId(app_id, title_info->meta_key.id))
                {
                    aoc_info = title_info;
                    break;
                } else
                if (title_info->meta_key.type == NcmContentMetaType_DataPatch && titleCheckIfDataPatchIdBelongsToApplicationId(app_id, title_info->meta_key.id))
                {
                    aoc_patch_info = title_info;
                    break;
                }
            }

            TITLE_ALLOCATE_USER_APP_DATA(aoc, "add-on content", error = true; break);

            TITLE_ALLOCATE_USER_APP_DATA(aoc_patch, "add-on content patch", error = true; break);

            if (out->aoc_info && out->aoc_patch_info) break;
        }

        if (error) break;

#undef TITLE_ALLOCATE_USER_APP_DATA

        /* Check retrieved title info. */
        ret = (app_info || patch_info || aoc_info || aoc_patch_info);
        if (!ret) LOG_MSG_ERROR("Failed to retrieve user application data for ID \"%016lX\"!", app_id);
    }

    /* Clear output. */
    if (!ret) titleFreeUserApplicationData(out);

    return ret;
}

void titleFreeUserApplicationData(TitleUserApplicationData *user_app_data)
{
    if (!user_app_data) return;

    /* Free user application info. */
    titleFreeTitleInfo(&(user_app_data->app_info));

    /* Free patch info. */
    titleFreeTitleInfo(&(user_app_data->patch_info));

    /* Free add-on content info. */
    titleFreeTitleInfo(&(user_app_data->aoc_info));

    /* Free add-on content patch info. */
    titleFreeTitleInfo(&(user_app_data->aoc_patch_info));
}

bool titleIsGameCardInfoUpdated(void)
{
    bool ret = false;

    SCOPED_TRY_LOCK(&g_titleMutex)
    {
        /* Check if the gamecard thread detected a gamecard status change. */
        ret = (g_titleInterfaceInit && g_titleGameCardInfoUpdated);
        if (ret) g_titleGameCardInfoUpdated = false;
    }

    return ret;
}

char *titleGenerateGameCardFileName(u8 naming_convention, u8 illegal_char_replace_type)
{
    char *filename = NULL;

    SCOPED_LOCK(&g_titleMutex)
    {
        TitleInfo **titles = g_titleStorage.titles;
        u32 title_count = g_titleStorage.title_count;

        GameCardHeader gc_header = {0};
        size_t cur_filename_len = 0, app_name_len = 0;
        char app_name[0x300] = {0};
        bool error = false;

        if (!g_titleInterfaceInit || !g_titleGameCardAvailable || naming_convention > TitleNamingConvention_IdAndVersionOnly || \
            (naming_convention == TitleNamingConvention_Full && illegal_char_replace_type > TitleFileNameIllegalCharReplaceType_KeepAsciiCharsOnly))
        {
            LOG_MSG_ERROR("Invalid parameters!");
            break;
        }

        /* Check if the gamecard title storage is empty. */
        /* This is especially true for Kiosk / Quest gamecards. */
        if (!titles || !title_count) goto fallback;

        for(u32 i = 0; i < title_count; i++)
        {
            TitleInfo *app_info = titles[i];
            if (!app_info || app_info->meta_key.type != NcmContentMetaType_Application) continue;

            u32 app_version = app_info->meta_key.version;

            /* Check if the inserted gamecard holds any bundled patches for the current user application. */
            /* If so, we'll use the highest patch version available as part of the filename. */
            for(u32 j = 0; j < title_count; j++)
            {
                if (j == i) continue;

                TitleInfo *cur_title_info = titles[j];
                if (!cur_title_info || cur_title_info->meta_key.type != NcmContentMetaType_Patch || \
                    !titleCheckIfPatchIdBelongsToApplicationId(app_info->meta_key.id, cur_title_info->meta_key.id) || cur_title_info->meta_key.version <= app_version) continue;

                app_version = cur_title_info->meta_key.version;
            }

            /* Generate current user application name. */
            *app_name = '\0';

            if (naming_convention == TitleNamingConvention_Full)
            {
                if (cur_filename_len) strcat(app_name, " + ");

                if (app_info->app_metadata && *(app_info->app_metadata->lang_entry.name))
                {
                    app_name_len = strlen(app_name);
                    snprintf(app_name + app_name_len, MAX_ELEMENTS(app_name) - app_name_len, "%s ", app_info->app_metadata->lang_entry.name);
                    if (illegal_char_replace_type) utilsReplaceIllegalCharacters(app_name, illegal_char_replace_type == TitleFileNameIllegalCharReplaceType_KeepAsciiCharsOnly);
                }

                app_name_len = strlen(app_name);
                snprintf(app_name + app_name_len, MAX_ELEMENTS(app_name) - app_name_len, "[%016lX][v%u]", app_info->meta_key.id, app_version);
            } else
            if (naming_convention == TitleNamingConvention_IdAndVersionOnly)
            {
                if (cur_filename_len) strcat(app_name, "+");
                app_name_len = strlen(app_name);
                snprintf(app_name + app_name_len, MAX_ELEMENTS(app_name) - app_name_len, "%016lX_v%u", app_info->meta_key.id, app_version);
            }

            /* Reallocate output buffer. */
            app_name_len = strlen(app_name);

            char *tmp_filename = realloc(filename, (cur_filename_len + app_name_len + 1) * sizeof(char));
            if (!tmp_filename)
            {
                LOG_MSG_ERROR("Failed to reallocate filename buffer!");
                if (filename) free(filename);
                filename = NULL;
                error = true;
                break;
            }

            filename = tmp_filename;
            tmp_filename = NULL;

            /* Concatenate current user application name. */
            filename[cur_filename_len] = '\0';
            strcat(filename, app_name);
            cur_filename_len += app_name_len;
        }

fallback:
        if (!filename && !error)
        {
            LOG_MSG_ERROR("Error: the inserted gamecard doesn't hold any user applications!");

            /* Fallback string if no applications can be found. */
            sprintf(app_name, "gamecard");

            if (gamecardGetHeader(&gc_header))
            {
                strcat(app_name, "_");
                cur_filename_len = strlen(app_name);
                utilsGenerateHexString(app_name + cur_filename_len, sizeof(app_name) - cur_filename_len, gc_header.package_id, sizeof(gc_header.package_id), false);
            }

            filename = strdup(app_name);
            if (!filename) LOG_MSG_ERROR("Failed to duplicate fallback filename!");
        }
    }

    return filename;
}

NX_INLINE void titleFreeApplicationMetadata(void)
{
    for(u32 i = 0; i < g_appMetadataCount; i++)
    {
        TitleApplicationMetadata *cur_app_metadata = g_appMetadata[i];
        if (cur_app_metadata)
        {
            if (cur_app_metadata->icon) free(cur_app_metadata->icon);
            free(cur_app_metadata);
        }
    }

    if (g_appMetadata) free(g_appMetadata);

    g_appMetadata = NULL;
    g_appMetadataCount = 0;
}

static bool titleReallocateApplicationMetadata(u32 extra_app_count, bool free_entries)
{
    TitleApplicationMetadata **tmp_app_metadata = NULL;
    u32 realloc_app_count = (!free_entries ? (g_appMetadataCount + extra_app_count) : g_appMetadataCount);
    bool success = false;

    if (free_entries)
    {
        if (!g_appMetadata)
        {
            LOG_MSG_ERROR("Invalid parameters!");
            goto end;
        }

        /* Free previously allocated application metadata entries. */
        for(u32 i = 0; i <= extra_app_count; i++)
        {
            TitleApplicationMetadata *cur_app_metadata = g_appMetadata[g_appMetadataCount + i];
            if (cur_app_metadata)
            {
                if (cur_app_metadata->icon) free(cur_app_metadata->icon);
                free(cur_app_metadata);
                g_appMetadata[g_appMetadataCount + i] = NULL;
            }
        }
    }

    if (realloc_app_count)
    {
        /* Reallocate application metadata pointer array. */
        tmp_app_metadata = realloc(g_appMetadata, realloc_app_count * sizeof(TitleApplicationMetadata*));
        if (tmp_app_metadata)
        {
            /* Update application metadata pointer. */
            g_appMetadata = tmp_app_metadata;
            tmp_app_metadata = NULL;

            /* Clear new application metadata pointer array area (if needed). */
            if (!free_entries && extra_app_count) memset(g_appMetadata + g_appMetadataCount, 0, extra_app_count * sizeof(TitleApplicationMetadata*));
        } else {
            LOG_MSG_ERROR("Failed to reallocate application metadata pointer array! (%u element[s]).", realloc_app_count);
            goto end;
        }
    } else
    if (g_appMetadata)
    {
        /* Free application metadata pointer array. */
        free(g_appMetadata);
        g_appMetadata = NULL;
    }

    /* Update flag. */
    success = true;

end:
    return success;
}

static bool titleInitializeTitleStorage(void)
{
    Result rc = 0;
    bool success = false;

    /* Close title storage before proceeding. */
    titleCloseTitleStorage();

    /* Open ncm database. */
    rc = ncmOpenContentMetaDatabase(&(g_titleStorage.ncm_db), NcmStorageId_GameCard);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("ncmOpenContentMetaDatabase failed! (0x%X).", rc);
        goto end;
    }

    /* Open ncm storage. */
    rc = ncmOpenContentStorage(&(g_titleStorage.ncm_storage), NcmStorageId_GameCard);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("ncmOpenContentStorage failed! (0x%X).", rc);
        goto end;
    }

    /* Generate title info entries. */
    if (!titleGenerateTitleInfoEntriesForTitleStorage())
    {
        LOG_MSG_ERROR("Failed to generate title info entries!");
        goto end;
    }

    LOG_MSG_INFO("Loaded %u title info %s.", g_titleStorage.title_count, (g_titleStorage.title_count == 1 ? "entry" : "entries"));

    /* Update flag. */
    success = true;

end:
    return success;
}

static void titleCloseTitleStorage(void)
{
    NcmContentMetaDatabase *ncm_db = &(g_titleStorage.ncm_db);
    NcmContentStorage *ncm_storage = &(g_titleStorage.ncm_storage);

    /* Free title infos from this title storage. */
    if (g_titleStorage.titles)
    {
        for(u32 i = 0; i < g_titleStorage.title_count; i++)
        {
            TitleInfo *cur_title_info = g_titleStorage.titles[i];
            if (cur_title_info)
            {
                if (cur_title_info->content_infos) free(cur_title_info->content_infos);
                free(cur_title_info);
            }
        }

        free(g_titleStorage.titles);
        g_titleStorage.titles = NULL;
    }

    /* Reset title count. */
    g_titleStorage.title_count = 0;

    /* Check if the ncm storage handle for this title storage has already been retrieved. If so, close it. */
    if (serviceIsActive(&(ncm_storage->s))) ncmContentStorageClose(ncm_storage);

    /* Check if the ncm database handle for this title storage has already been retrieved. If so, close it. */
    if (serviceIsActive(&(ncm_db->s))) ncmContentMetaDatabaseClose(ncm_db);
}

static bool titleReallocateTitleInfoFromStorage(u32 extra_title_count, bool free_entries)
{
    TitleInfo **title_info = g_titleStorage.titles, **tmp_title_info = NULL;
    u32 title_count = g_titleStorage.title_count;
    u32 realloc_title_count = (!free_entries ? (title_count + extra_title_count) : title_count);
    bool success = false;

    if (free_entries)
    {
        if (!title_info)
        {
            LOG_MSG_ERROR("Invalid parameters!");
            goto end;
        }

        /* Free previously allocated title info entries. */
        for(u32 i = 0; i <= extra_title_count; i++)
        {
            TitleInfo *cur_title_info = title_info[title_count + i];
            if (cur_title_info)
            {
                if (cur_title_info->content_infos) free(cur_title_info->content_infos);
                free(cur_title_info);
                title_info[title_count + i] = NULL;
            }
        }
    }

    if (realloc_title_count)
    {
        /* Reallocate title info pointer array. */
        tmp_title_info = realloc(title_info, realloc_title_count * sizeof(TitleInfo*));
        if (tmp_title_info)
        {
            /* Update title info pointer. */
            title_info = tmp_title_info;
            tmp_title_info = NULL;

            /* Clear new title info pointer array area (if needed). */
            if (!free_entries && extra_title_count) memset(title_info + title_count, 0, extra_title_count * sizeof(TitleInfo*));
        } else {
            LOG_MSG_ERROR("Failed to reallocate title info pointer array! (%u element[s]).", realloc_title_count);
            goto end;
        }
    } else
    if (title_info)
    {
        /* Free title info pointer array. */
        free(title_info);
        title_info = NULL;
    }

    /* Update pointer array in global title storage. */
    g_titleStorage.titles = title_info;

    /* Update flag. */
    success = true;

end:
    return success;
}

static bool titleGenerateMetadataEntriesFromNsRecords(void)
{
    Result rc = 0;

    NsApplicationRecord *app_records = NULL, *tmp_app_records = NULL;
    u32 app_records_block_count = 0, app_records_count = 0, extra_app_count = 0;
    size_t app_records_size = 0, app_records_block_size = (NS_APPLICATION_RECORD_BLOCK_SIZE * sizeof(NsApplicationRecord));

    bool success = false, free_entries = false;

    /* Retrieve NS application records in a loop until we get them all. */
    do {
        /* Allocate memory for the NS application records. */
        tmp_app_records = realloc(app_records, app_records_size + app_records_block_size);
        if (!tmp_app_records)
        {
            LOG_MSG_ERROR("Failed to reallocate NS application records buffer! (%u)", app_records_count);
            goto end;
        }

        app_records = tmp_app_records;
        tmp_app_records = NULL;
        app_records_size += app_records_block_size;

        /* Clear newly allocated block. */
        NsApplicationRecord *app_records_block = &(app_records[app_records_count]);
        memset(app_records_block, 0, app_records_block_size);

        /* Retrieve NS application records. */
        rc = nsListApplicationRecord(app_records_block, NS_APPLICATION_RECORD_BLOCK_SIZE, (s32)app_records_count, (s32*)&app_records_block_count);
        if (R_FAILED(rc))
        {
            LOG_MSG_ERROR("nsListApplicationRecord failed! (0x%X) (%u).", rc, app_records_count);
            if (!app_records_count) goto end;
            break; /* Gotta work with what we have. */
        }

        app_records_count += app_records_block_count;
    } while(app_records_block_count >= NS_APPLICATION_RECORD_BLOCK_SIZE);

    /* Return right away if no records were retrieved. */
    if (!app_records_count)
    {
        success = true;
        goto end;
    }

    /* Reallocate application metadata pointer array. */
    if (!titleReallocateApplicationMetadata(app_records_count, false))
    {
        LOG_MSG_ERROR("Failed to reallocate application metadata pointer array for NS records!");
        goto end;
    }

    free_entries = true;

    /* Retrieve application metadata for each NS application record. */
    for(u32 i = 0; i < app_records_count; i++)
    {
        TitleApplicationMetadata *cur_app_metadata = g_appMetadata[g_appMetadataCount + extra_app_count];
        if (!cur_app_metadata)
        {
            /* Allocate memory for a new application metadata entry. */
            cur_app_metadata = calloc(1, sizeof(TitleApplicationMetadata));
            if (!cur_app_metadata)
            {
                LOG_MSG_ERROR("Failed to allocate memory for application metadata entry #%u! (%u / %u).", extra_app_count, i + 1, app_records_count);
                goto end;
            }

            /* Set application metadata entry pointer. */
            g_appMetadata[g_appMetadataCount + extra_app_count] = cur_app_metadata;
        }

        /* Retrieve application metadata. */
        if (!titleRetrieveUserApplicationMetadataByTitleId(app_records[i].application_id, cur_app_metadata)) continue;

        /* Increase extra application metadata counter. */
        extra_app_count++;
    }

    /* Check retrieved application metadata count. */
    if (!extra_app_count)
    {
        LOG_MSG_ERROR("Unable to retrieve application metadata from NS application records! (%u element[s]).", app_records_count);
        goto end;
    }

    /* Update application metadata count. */
    g_appMetadataCount += extra_app_count;

    /* Free extra allocated pointers if we didn't use them. */
    if (extra_app_count < app_records_count) titleReallocateApplicationMetadata(0, false);

    /* Sort application metadata entries by name. */
    if (g_appMetadataCount > 1) qsort(g_appMetadata, g_appMetadataCount, sizeof(TitleApplicationMetadata*), &titleUserApplicationMetadataEntrySortFunction);

    /* Update flag. */
    success = true;

end:
    if (app_records) free(app_records);

    /* Free previously allocated application metadata pointers. Ignore return value. */
    if (!success && free_entries) titleReallocateApplicationMetadata(extra_app_count, true);

    return success;
}

static bool titleRetrieveUserApplicationMetadataByTitleId(u64 title_id, TitleApplicationMetadata *out)
{
    if (!g_nsAppControlData || !title_id || !out)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    Result rc = 0;
    u64 write_size = 0;
    NacpLanguageEntry *lang_entry = NULL;

    u32 icon_size = 0;
    u8 *icon = NULL;

    /* Retrieve ns application control data. */
    rc = nsGetApplicationControlData(NsApplicationControlSource_Storage, title_id, g_nsAppControlData, sizeof(NsApplicationControlData), &write_size);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("nsGetApplicationControlData failed for title ID \"%016lX\"! (0x%X).", title_id, rc);
        return false;
    }

    if (write_size < sizeof(NacpStruct))
    {
        LOG_MSG_ERROR("Retrieved application control data buffer is too small! (0x%lX).", write_size);
        return false;
    }

    /* Get language entry. */
    rc = nacpGetLanguageEntry(&(g_nsAppControlData->nacp), &lang_entry);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("nacpGetLanguageEntry failed! (0x%X).", rc);
        return false;
    }

    /* Get icon. */
    icon_size = (u32)(write_size - sizeof(NacpStruct));
    if (icon_size)
    {
        icon = malloc(icon_size);
        if (!icon)
        {
            LOG_MSG_ERROR("Error allocating memory for the icon buffer! (0x%X).", icon_size);
            return false;
        }

        memcpy(icon, g_nsAppControlData->icon, icon_size);
    }

    /* Copy data. */
    out->title_id = title_id;

    if (lang_entry)
    {
        memcpy(&(out->lang_entry), lang_entry, sizeof(NacpLanguageEntry));
        utilsTrimString(out->lang_entry.name);
        utilsTrimString(out->lang_entry.author);
    } else {
        /* Yes, this can happen -- NACPs with empty language entries are a thing, somehow. */
        sprintf(out->lang_entry.name, "Unknown");
        sprintf(out->lang_entry.author, "Unknown");
        LOG_DATA_DEBUG(&(g_nsAppControlData->nacp), sizeof(NacpStruct), "NACP dump (ID %016lX):", title_id);
    }

    out->icon_size = icon_size;
    out->icon = icon;

    return true;
}

NX_INLINE TitleApplicationMetadata *titleFindApplicationMetadataByTitleId(u64 title_id, u32 extra_app_count)
{
    if (!title_id || !g_appMetadata || !g_appMetadataCount) return NULL;

    for(u32 i = 0; i < g_appMetadataCount; i++)
    {
        TitleApplicationMetadata *cur_app_metadata = g_appMetadata[i];
        if (cur_app_metadata && cur_app_metadata->title_id == title_id) return cur_app_metadata;
    }

    return NULL;
}

NX_INLINE u64 titleGetApplicationIdByContentMetaKey(const NcmContentMetaKey *meta_key)
{
    if (!meta_key) return 0;

    u64 app_id = meta_key->id;

    switch(meta_key->type)
    {
        case NcmContentMetaType_Patch:
            app_id = titleGetApplicationIdByPatchId(meta_key->id);
            break;
        case NcmContentMetaType_AddOnContent:
            app_id = titleGetApplicationIdByAddOnContentId(meta_key->id);
            break;
        case NcmContentMetaType_Delta:
            app_id = titleGetApplicationIdByDeltaId(meta_key->id);
            break;
        case NcmContentMetaType_DataPatch:
            app_id = titleGetApplicationIdByDataPatchId(meta_key->id);
            break;
        default:
            break;
    }

    return app_id;
}

static bool titleGenerateTitleInfoEntriesForTitleStorage(void)
{
    NcmContentMetaDatabase *ncm_db = &(g_titleStorage.ncm_db);

    if (!serviceIsActive(&(ncm_db->s)))
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    u32 total = 0, extra_title_count = 0;
    NcmContentMetaKey *meta_keys = NULL;

    bool success = false, free_entries = false;

    /* Get content meta keys for this storage. */
    if (!titleGetMetaKeysFromContentDatabase(ncm_db, &meta_keys, &total)) goto end;

    /* Check if we're dealing with an empty storage. */
    if (!total)
    {
        success = true;
        goto end;
    }

    /* Reallocate pointer array in title storage. */
    if (!titleReallocateTitleInfoFromStorage(total, false)) goto end;

    free_entries = true;

    /* Fill new title info entries. */
    for(u32 i = 0; i < total; i++)
    {
        u64 tmp_size = 0;
        NcmContentMetaKey *cur_meta_key = &(meta_keys[i]);

        TitleInfo *cur_title_info = g_titleStorage.titles[g_titleStorage.title_count + extra_title_count];
        if (!cur_title_info)
        {
            /* Allocate memory for a new entry. */
            cur_title_info = calloc(1, sizeof(TitleInfo));
            if (!cur_title_info)
            {
                LOG_MSG_ERROR("Failed to allocate memory for title info entry #%u! (%u / %u).", extra_title_count, i + 1, total);
                goto end;
            }

            /* Set title info entry pointer. */
            g_titleStorage.titles[g_titleStorage.title_count + extra_title_count] = cur_title_info;
        }

        /* Get content infos. */
        if (!titleGetContentInfosForMetaKey(ncm_db, cur_meta_key, &(cur_title_info->content_infos), &(cur_title_info->content_count)))
        {
            LOG_MSG_ERROR("Failed to get content infos for title ID %016lX!", cur_meta_key->id);
            continue;
        }

        /* Calculate title size. */
        for(u32 j = 0; j < cur_title_info->content_count; j++)
        {
            ncmContentInfoSizeToU64(&(cur_title_info->content_infos[j]), &tmp_size);
            cur_title_info->size += tmp_size;
        }

        /* Fill information. */
        memcpy(&(cur_title_info->meta_key), cur_meta_key, sizeof(NcmContentMetaKey));
        cur_title_info->version.value = cur_title_info->meta_key.version;
        utilsGenerateFormattedSizeString((double)cur_title_info->size, cur_title_info->size_str, sizeof(cur_title_info->size_str));

        /* Retrieve application metadata. */
        u64 app_id = titleGetApplicationIdByContentMetaKey(&(cur_title_info->meta_key));
        cur_title_info->app_metadata = titleFindApplicationMetadataByTitleId(app_id, 0);

        /* Increase extra title info counter. */
        extra_title_count++;
    }

    /* Check retrieved title info count. */
    if (!extra_title_count)
    {
        LOG_MSG_ERROR("Unable to generate title info entries! (%u element[s]).", total);
        goto end;
    }

    /* Update title info count. */
    g_titleStorage.title_count += extra_title_count;

    /* Free extra allocated pointers if we didn't use them. */
    if (extra_title_count < total) titleReallocateTitleInfoFromStorage(0, false);

    /* Sort title info entries by title ID, version and storage ID. */
    qsort(g_titleStorage.titles, g_titleStorage.title_count, sizeof(TitleInfo*), &titleInfoEntrySortFunction);

    /* Update linked lists for user applications, patches and add-on contents. */
    titleUpdateTitleInfoLinkedLists();

    /* Update flag. */
    success = true;

end:
    if (meta_keys) free(meta_keys);

    /* Free previously allocated title info pointers. Ignore return value. */
    if (!success && free_entries) titleReallocateTitleInfoFromStorage(extra_title_count, true);

    return success;
}

static bool titleGetMetaKeysFromContentDatabase(NcmContentMetaDatabase *ncm_db, NcmContentMetaKey **out_meta_keys, u32 *out_meta_key_count)
{
    if (!ncm_db || !serviceIsActive(&(ncm_db->s)) || !out_meta_keys || !out_meta_key_count)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    Result rc = 0;
    u32 written = 0, total = 0;
    NcmContentMetaKey *meta_keys = NULL, *meta_keys_tmp = NULL;
    size_t meta_keys_size = sizeof(NcmContentMetaKey);
    bool success = false;

    /* Allocate memory for the ncm application content meta keys. */
    meta_keys = calloc(1, meta_keys_size);
    if (!meta_keys)
    {
        LOG_MSG_ERROR("Unable to allocate memory for the ncm application meta keys!");
        goto end;
    }

    /* Get a full list of all titles available in this storage. */
    /* Meta type '0' means all title types will be retrieved. */
    rc = ncmContentMetaDatabaseList(ncm_db, (s32*)&total, (s32*)&written, meta_keys, 1, 0, 0, 0, UINT64_MAX, NcmContentInstallType_Full);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("ncmContentMetaDatabaseList failed! (0x%X) (first entry).", rc);
        goto end;
    }

    /* Check if our application meta keys buffer was actually filled. */
    /* If it wasn't, odds are there are no titles in this storage. */
    if (!written || !total)
    {
        *out_meta_key_count = 0;
        success = true;
        goto end;
    }

    /* Check if we need to resize our application meta keys buffer. */
    if (total > written)
    {
        /* Update application meta keys buffer size. */
        meta_keys_size *= total;

        /* Reallocate application meta keys buffer. */
        meta_keys_tmp = realloc(meta_keys, meta_keys_size);
        if (!meta_keys_tmp)
        {
            LOG_MSG_ERROR("Unable to reallocate application meta keys buffer! (%u entries).", total);
            goto end;
        }

        meta_keys = meta_keys_tmp;
        meta_keys_tmp = NULL;

        /* Issue call again. */
        rc = ncmContentMetaDatabaseList(ncm_db, (s32*)&total, (s32*)&written, meta_keys, (s32)total, 0, 0, 0, UINT64_MAX, NcmContentInstallType_Full);
        if (R_FAILED(rc))
        {
            LOG_MSG_ERROR("ncmContentMetaDatabaseList failed! (0x%X) (%u %s).", rc, total, total > 1 ? "entries" : "entry");
            goto end;
        }

        /* Safety check. */
        if (written != total)
        {
            LOG_MSG_ERROR("Application meta key count mismatch! (%u != %u).", written, total);
            goto end;
        }
    }

    /* Update output. */
    *out_meta_keys = meta_keys;
    *out_meta_key_count = total;

    success = true;

end:
    if (!success && meta_keys) free(meta_keys);

    return success;
}

static bool titleGetContentInfosForMetaKey(NcmContentMetaDatabase *ncm_db, const NcmContentMetaKey *meta_key, NcmContentInfo **out_content_infos, u32 *out_content_count)
{
    if (!ncm_db || !serviceIsActive(&(ncm_db->s)) || !meta_key || !out_content_infos || !out_content_count)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return false;
    }

    Result rc = 0;

    NcmContentMetaHeader content_meta_header = {0};
    u64 content_meta_header_read_size = 0;

    NcmContentInfo *content_infos = NULL;
    u32 content_count = 0, written = 0;

    bool success = false;

    /* Retrieve content meta header. */
    rc = ncmContentMetaDatabaseGet(ncm_db, meta_key, &content_meta_header_read_size, &content_meta_header, sizeof(NcmContentMetaHeader));
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("ncmContentMetaDatabaseGet failed! (0x%X).", rc);
        goto end;
    }

    if (content_meta_header_read_size != sizeof(NcmContentMetaHeader))
    {
        LOG_MSG_ERROR("Content meta header size mismatch! (0x%lX != 0x%lX).", content_meta_header_read_size, sizeof(NcmContentMetaHeader));
        goto end;
    }

    /* Get content count. */
    content_count = (u32)content_meta_header.content_count;
    if (!content_count)
    {
        LOG_MSG_ERROR("Content count is zero!");
        goto end;
    }

    /* Allocate memory for the content infos. */
    content_infos = calloc(content_count, sizeof(NcmContentInfo));
    if (!content_infos)
    {
        LOG_MSG_ERROR("Unable to allocate memory for the content infos buffer! (%u content[s]).", content_count);
        goto end;
    }

    /* Retrieve content infos. */
    rc = ncmContentMetaDatabaseListContentInfo(ncm_db, (s32*)&written, content_infos, (s32)content_count, meta_key, 0);
    if (R_FAILED(rc))
    {
        LOG_MSG_ERROR("ncmContentMetaDatabaseListContentInfo failed! (0x%X).", rc);
        goto end;
    }

    if (written != content_count)
    {
        LOG_MSG_ERROR("Content count mismatch! (%u != %u).", written, content_count);
        goto end;
    }

    /* Update output. */
    *out_content_infos = content_infos;
    *out_content_count = content_count;

    success = true;

end:
    if (!success && content_infos) free(content_infos);

    return success;
}

static void titleUpdateTitleInfoLinkedLists(void)
{
    TitleInfo **titles = g_titleStorage.titles;
    u32 title_count = g_titleStorage.title_count;

    /* Don't proceed if the current storage holds no titles. */
    if (!titles || !title_count) return;

    /* Process titles from the current storage. */
    for(u32 i = 0; i < title_count; i++)
    {
        /* Get pointer to the current title info and reset its linked list pointers. */
        TitleInfo *child_info = titles[i];
        if (!child_info) continue;

        child_info->previous = child_info->next = NULL;

        /* If we're dealing with a title that's not an user application, patch, add-on content or add-on content patch, proceed onto the next one. */
        if (child_info->meta_key.type < NcmContentMetaType_Application || (child_info->meta_key.type > NcmContentMetaType_AddOnContent && \
            child_info->meta_key.type != NcmContentMetaType_DataPatch)) continue;

        if (child_info->meta_key.type != NcmContentMetaType_Application && !child_info->app_metadata)
        {
            /* We're dealing with a patch, an add-on content or an add-on content patch. */
            /* We'll just retrieve a pointer to the first matching user application entry and use it to set a pointer to an application metadata entry. */
            u64 app_id = titleGetApplicationIdByContentMetaKey(&(child_info->meta_key));
            TitleInfo *parent = _titleGetInfoFromStorageByTitleId(app_id);
            if (parent)
            {
                /* Set pointer to application metadata. */
                child_info->app_metadata = parent->app_metadata;
            } else {
                continue;
            }
        }

        /* Locate previous user application, patch, add-on content or add-on content patch entry. */
        /* If it's found, we will update both its next pointer and the previous pointer from the current entry. */

        /* Don't proceed if we're currently dealing with the first entry. */
        if (i == 0) continue;

        for(u32 j = (i + 1); j > 0; j--)
        {
            TitleInfo *prev_info = titles[j - 1];
            if (!prev_info) continue;

            if (prev_info->meta_key.type == child_info->meta_key.type && \
                (((child_info->meta_key.type == NcmContentMetaType_Application || child_info->meta_key.type == NcmContentMetaType_Patch) && prev_info->meta_key.id == child_info->meta_key.id) || \
                (child_info->meta_key.type == NcmContentMetaType_AddOnContent && titleCheckIfAddOnContentIdsAreSiblings(prev_info->meta_key.id, child_info->meta_key.id)) || \
                (child_info->meta_key.type == NcmContentMetaType_DataPatch && titleCheckIfDataPatchIdsAreSiblings(prev_info->meta_key.id, child_info->meta_key.id))))
            {
                prev_info->next = child_info;
                child_info->previous = prev_info;
                break;
            }
        }
    }
}

static bool titleCreateGameCardInfoThread(void)
{
    if (!utilsCreateThread(&g_titleGameCardInfoThread, titleGameCardInfoThreadFunc, NULL, 1))
    {
        LOG_MSG_ERROR("Failed to create gamecard title info thread!");
        return false;
    }

    return true;
}

static void titleDestroyGameCardInfoThread(void)
{
    /* Signal the exit event to terminate the gamecard title info thread. */
    ueventSignal(&g_titleGameCardInfoThreadExitEvent);

    /* Wait for the gamecard title info thread to exit. */
    utilsJoinThread(&g_titleGameCardInfoThread);
}

static void titleGameCardInfoThreadFunc(void *arg)
{
    NX_IGNORE_ARG(arg);

    Result rc = 0;
    int idx = 0;

    Waiter gamecard_status_event_waiter = waiterForUEvent(g_titleGameCardStatusChangeUserEvent);
    Waiter exit_event_waiter = waiterForUEvent(&g_titleGameCardInfoThreadExitEvent);

    while(true)
    {
        /* Wait until an event is triggered. */
        rc = waitMulti(&idx, -1, gamecard_status_event_waiter, exit_event_waiter);
        if (R_FAILED(rc)) continue;

        /* Exit event triggered. */
        if (idx == 1) break;

        /* Update gamecard title info. */
        SCOPED_LOCK(&g_titleMutex) g_titleGameCardInfoUpdated = titleRefreshGameCardTitleInfo();
    }

    /* Update gamecard flags. */
    g_titleGameCardAvailable = g_titleGameCardInfoUpdated = false;

    threadExit();
}

static bool titleRefreshGameCardTitleInfo(void)
{
    TitleInfo **titles = NULL;
    u32 title_count = 0, gamecard_app_count = 0, extra_app_count = 0;
    bool status = false, success = false, cleanup = true, free_entries = false;

    /* Retrieve current gamecard status. */
    status = (gamecardGetStatus() == GameCardStatus_InsertedAndInfoLoaded);
    if (status == g_titleGameCardAvailable || !status)
    {
        success = cleanup = (status != g_titleGameCardAvailable);
        goto end;
    }

    /* Initialize title storage. */
    if (!titleInitializeTitleStorage())
    {
        LOG_MSG_ERROR("Failed to initialize gamecard title storage!");
        goto end;
    }

    /* Get gamecard title storage info. */
    titles = g_titleStorage.titles;
    title_count = g_titleStorage.title_count;

    /* Verify title count. */
    if (!title_count)
    {
        LOG_MSG_ERROR("Gamecard title count is zero!");
        goto end;
    }

    /* Get gamecard user application count. */
    for(u32 i = 0; i < title_count; i++)
    {
        TitleInfo *cur_title_info = titles[i];
        if (cur_title_info && cur_title_info->meta_key.type == NcmContentMetaType_Application) gamecard_app_count++;
    }

    /* Return immediately if, for some reason, there are no user applications. */
    if (!gamecard_app_count)
    {
        success = true;
        cleanup = false;
        goto end;
    }

    /* Reallocate application metadata pointer array. */
    if (!titleReallocateApplicationMetadata(gamecard_app_count, false))
    {
        LOG_MSG_ERROR("Failed to reallocate application metadata pointer array for gamecard user applications!");
        goto end;
    }

    free_entries = true;

    /* Retrieve application metadata for gamecard user applications. */
    for(u32 i = 0; i < title_count; i++)
    {
        TitleInfo *cur_title_info = titles[i];
        if (!cur_title_info) continue;

        /* Do not proceed if application metadata has already been retrieved, or if we can successfully retrieve it. */
        u64 app_id = titleGetApplicationIdByContentMetaKey(&(cur_title_info->meta_key));
        if (cur_title_info->app_metadata != NULL || (cur_title_info->app_metadata = titleFindApplicationMetadataByTitleId(app_id, extra_app_count)) != NULL) continue;

        /* Retrieve application metadata pointer. */
        TitleApplicationMetadata *cur_app_metadata = g_appMetadata[g_appMetadataCount + extra_app_count];
        if (!cur_app_metadata)
        {
            /* Allocate memory for a new application metadata entry. */
            cur_app_metadata = calloc(1, sizeof(TitleApplicationMetadata));
            if (!cur_app_metadata)
            {
                LOG_MSG_ERROR("Failed to allocate memory for application metadata entry #%u!", extra_app_count);
                goto end;
            }

            /* Set application metadata entry pointer. */
            g_appMetadata[g_appMetadataCount + extra_app_count] = cur_app_metadata;
        }

        /* Retrieve application metadata. */
        if (!titleRetrieveUserApplicationMetadataByTitleId(app_id, cur_app_metadata)) continue;

        /* Update application metadata pointer in title info. */
        cur_title_info->app_metadata = cur_app_metadata;

        /* Increase extra application metadata counter. */
        extra_app_count++;
    }

    if (extra_app_count)
    {
        /* Update application metadata count. */
        g_appMetadataCount += extra_app_count;

        /* Sort application metadata entries by name. */
        if (g_appMetadataCount > 1) qsort(g_appMetadata, g_appMetadataCount, sizeof(TitleApplicationMetadata*), &titleUserApplicationMetadataEntrySortFunction);

        /* Update linked lists for user applications, patches and add-on contents. */
        titleUpdateTitleInfoLinkedLists();
    } else
    if (g_appMetadata[g_appMetadataCount])
    {
        /* Free leftover application metadata entry (if needed). */
        free(g_appMetadata[g_appMetadataCount]);
        g_appMetadata[g_appMetadataCount] = NULL;
    }

    /* Free extra allocated pointers if we didn't use them. */
    if (extra_app_count < gamecard_app_count) titleReallocateApplicationMetadata(0, false);

    /* Update flags. */
    success = true;
    cleanup = false;

end:
    /* Update gamecard status. */
    g_titleGameCardAvailable = status;

    /* Free previously allocated application metadata pointers. Ignore return value. */
    if (!success && free_entries) titleReallocateApplicationMetadata(extra_app_count, true);

    if (cleanup)
    {
        /* Close gamecard title storage. */
        titleCloseTitleStorage();

        /* Update linked lists for user applications, patches and add-on contents. */
        titleUpdateTitleInfoLinkedLists();
    }

    return success;
}

static TitleInfo *_titleGetInfoFromStorageByTitleId(u64 title_id)
{
    if (!g_titleStorage.titles || !*(g_titleStorage.titles) || !g_titleStorage.title_count || !title_id)
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    TitleInfo *out = NULL;

    for(u32 i = 0; i < g_titleStorage.title_count; i++)
    {
        TitleInfo *title_info = g_titleStorage.titles[i];
        if (title_info && title_info->meta_key.id == title_id)
        {
            out = title_info;
            break;
        }
    }

    if (!out) LOG_MSG_DEBUG("Unable to find title info entry with ID \"%016lX\".", title_id);

    return out;
}

static TitleInfo *titleDuplicateTitleInfoFull(TitleInfo *title_info, TitleInfo *previous, TitleInfo *next)
{
    if (!titleIsValidInfoBlock(title_info))
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    TitleInfo *title_info_dup = NULL, *tmp1 = NULL, *tmp2 = NULL;
    bool dup_previous = false, dup_next = false, success = false;

    /* Duplicate TitleInfo object. */
    title_info_dup = titleDuplicateTitleInfo(title_info);
    if (!title_info_dup)
    {
        LOG_MSG_ERROR("Failed to duplicate TitleInfo object!");
        return NULL;
    }

#define TITLE_DUPLICATE_LINKED_LIST(elem, prv, nxt) \
    if (title_info->elem) { \
        if (elem) { \
            title_info_dup->elem = elem; \
        } else { \
            title_info_dup->elem = titleDuplicateTitleInfoFull(title_info->elem, prv, nxt); \
            if (!title_info_dup->elem) goto end; \
            dup_##elem = true; \
        } \
    }

#define TITLE_FREE_DUPLICATED_LINKED_LIST(elem) \
    if (dup_##elem) { \
        tmp1 = title_info_dup->elem; \
        while(tmp1) { \
            tmp2 = tmp1->elem; \
            tmp1->previous = tmp1->next = NULL; \
            titleFreeTitleInfo(&tmp1); \
            tmp1 = tmp2; \
        } \
    }

    /* Duplicate linked lists based on two different principles: */
    /* 1) Linked list pointers will only be populated if their corresponding pointer is also populated in the TitleInfo element to duplicate. */
    /* 2) Pointers passed into this function take precedence before actual data duplication. */
    TITLE_DUPLICATE_LINKED_LIST(previous, NULL, title_info_dup);
    TITLE_DUPLICATE_LINKED_LIST(next, title_info_dup, NULL);

    /* Update flag. */
    success = true;

end:
    /* We can't directly use titleFreeTitleInfo() on title_info_dup because some or all of the linked list data may have been provided as function arguments. */
    /* So we'll take care of freeing data the old fashioned way. */
    if (!success && title_info_dup)
    {
        /* Free content infos pointer. */
        if (title_info_dup->content_infos) free(title_info_dup->content_infos);

        /* Free previous and next linked lists (if duplicated). */
        /* We need to take care of not freeing the linked lists right away, either because we may have already freed them, or because they may have been passed as arguments. */
        /* Furthermore, both the next pointer from the previous sibling and the previous pointer from the next sibling reference our current duplicated entry. */
        /* To avoid issues, we'll just clear all linked list pointers. */
        TITLE_FREE_DUPLICATED_LINKED_LIST(previous);
        TITLE_FREE_DUPLICATED_LINKED_LIST(next);

        /* Free allocated buffer and update return pointer. */
        free(title_info_dup);
        title_info_dup = NULL;
    }

#undef TITLE_DUPLICATE_LINKED_LIST

#undef TITLE_FREE_DUPLICATED_LINKED_LIST

    return title_info_dup;
}

static TitleInfo *titleDuplicateTitleInfo(TitleInfo *title_info)
{
    if (!titleIsValidInfoBlock(title_info))
    {
        LOG_MSG_ERROR("Invalid parameters!");
        return NULL;
    }

    TitleInfo *title_info_dup = NULL;
    NcmContentInfo *content_infos_dup = NULL;
    bool success = false;

    /* Allocate memory for the new TitleInfo element. */
    title_info_dup = calloc(1, sizeof(TitleInfo));
    if (!title_info_dup)
    {
        LOG_MSG_ERROR("Failed to allocate memory for TitleInfo duplicate!");
        return NULL;
    }

    /* Copy TitleInfo data. */
    memcpy(title_info_dup, title_info, sizeof(TitleInfo));
    title_info_dup->previous = title_info_dup->next = NULL;

    /* Allocate memory for NcmContentInfo elements. */
    content_infos_dup = calloc(title_info->content_count, sizeof(NcmContentInfo));
    if (!content_infos_dup)
    {
        LOG_MSG_ERROR("Failed to allocate memory for NcmContentInfo duplicates!");
        goto end;
    }

    /* Copy NcmContentInfo data. */
    memcpy(content_infos_dup, title_info->content_infos, title_info->content_count * sizeof(NcmContentInfo));

    /* Update content infos pointer. */
    title_info_dup->content_infos = content_infos_dup;

    /* Update flag. */
    success = true;

end:
    if (!success)
    {
        if (content_infos_dup) free(content_infos_dup);

        if (title_info_dup)
        {
            free(title_info_dup);
            title_info_dup = NULL;
        }
    }

    return title_info_dup;
}

static int titleUserApplicationMetadataEntrySortFunction(const void *a, const void *b)
{
    const TitleApplicationMetadata *app_metadata_1 = *((const TitleApplicationMetadata**)a);
    const TitleApplicationMetadata *app_metadata_2 = *((const TitleApplicationMetadata**)b);

    return strcasecmp(app_metadata_1->lang_entry.name, app_metadata_2->lang_entry.name);
}

static int titleInfoEntrySortFunction(const void *a, const void *b)
{
    const TitleInfo *title_info_1 = *((const TitleInfo**)a);
    const TitleInfo *title_info_2 = *((const TitleInfo**)b);

    if (title_info_1->meta_key.id < title_info_2->meta_key.id)
    {
        return -1;
    } else
    if (title_info_1->meta_key.id > title_info_2->meta_key.id)
    {
        return 1;
    }

    if (title_info_1->version.value < title_info_2->version.value)
    {
        return -1;
    } else
    if (title_info_1->version.value > title_info_2->version.value)
    {
        return 1;
    }

    return 0;
}
