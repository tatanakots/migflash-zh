/*
 * dumper.h
 *
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#pragma once

typedef struct {
    Mutex mutex;
    size_t data_written, total_size;
    bool error, transfer_cancelled;
    bool dump_xci, dump_initial_data, dump_certificate, dump_card_id_set, dump_card_uid;
    u32 output_storage;
    UsbHsFsDevice *ums_device;
} dumper_thrd_data_t;

void dumper_save_mig_switch_data(void *arg);
