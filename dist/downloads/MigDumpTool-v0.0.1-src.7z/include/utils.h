/*
 * utils.h
 *
 * Copyright (c) 2020-2023, DarkMatterCore <pabloacurielz@gmail.com>.
 * Copyright (c) 2024, MIG Switch.
 *
 * This file is part of MigDumpTool (https://migswitch.com).
 *
 * MigDumpTool is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * MigDumpTool is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#pragma once

#ifndef __UTILS_H__
#define __UTILS_H__

/* Included here for convenience. */
#include "includes.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Scoped lock macro. */
#define SCOPED_LOCK(mtx)        for(UtilsScopedLock ANONYMOUS_VARIABLE(scoped_lock) CLEANUP(utilsUnlockScope) = utilsLockScope(mtx); ANONYMOUS_VARIABLE(scoped_lock).cond; ANONYMOUS_VARIABLE(scoped_lock).cond = 0)

/* Scoped try lock macro. */
#define SCOPED_TRY_LOCK(mtx)    for(UtilsScopedLock ANONYMOUS_VARIABLE(scoped_lock) CLEANUP(utilsUnlockScope) = utilsTryLockScope(mtx); ANONYMOUS_VARIABLE(scoped_lock).cond; ANONYMOUS_VARIABLE(scoped_lock).cond = 0)

/// Used by scoped locks.
typedef struct {
    Mutex *mtx;
    bool lock;
    int cond;
} UtilsScopedLock;

/// Used to determine which CFW is the application running under.
typedef enum {
    UtilsCustomFirmwareType_Unknown    = 0,
    UtilsCustomFirmwareType_Atmosphere = 1,
    UtilsCustomFirmwareType_SXOS       = 2,
    UtilsCustomFirmwareType_ReiNX      = 3,
    UtilsCustomFirmwareType_Count      = 4  ///< Total values supported by this enum.
} UtilsCustomFirmwareType;

/// Resource initialization.
/// Called at program startup.
bool utilsInitializeResources(void);

/// Resource deinitialization.
/// Called at program exit.
void utilsCloseResources(void);

/// Returns a pointer to the application launch path.
const char *utilsGetLaunchPath(void);

/// Returns the nxlink socket descriptor, or -1 if an nxlink connection couldn't be established.
int utilsGetNxLinkFileDescriptor(void);

/// Returns a pointer to the FsFileSystem object for the SD card.
FsFileSystem *utilsGetSdCardFileSystemObject(void);

/// Commits SD card filesystem changes.
/// Must be used after closing a file handle from the SD card.
bool utilsCommitSdCardFileSystemChanges(void);

/// Returns a UtilsCustomFirmwareType value.
u8 utilsGetCustomFirmwareType(void);

/// Returns true if the application is running under a Mariko unit.
bool utilsIsMarikoUnit(void);

/// Returns true if the application is running under a development unit.
bool utilsIsDevelopmentUnit(void);

/// Returns true if the application is running under applet mode.
bool utilsIsAppletMode(void);

/// Blocks HOME button presses, disables screen dimming and auto sleep and overclocks system CPU/MEM.
/// Must be called before starting long-running processes.
/// If state is set to false, regular system behavior is restored.
void utilsSetLongRunningProcessState(bool state);

/// Thread management functions.
bool utilsCreateThread(Thread *out_thread, ThreadFunc func, void *arg, int cpu_id);
void utilsJoinThread(Thread *thread);

/// Formats a string and appends it to the provided buffer.
/// If the buffer isn't big enough to hold both its current contents and the new formatted string, it will be resized.
__attribute__((format(printf, 3, 4))) bool utilsAppendFormattedStringToBuffer(char **dst, size_t *dst_size, const char *fmt, ...);

/// Replaces illegal FAT characters in the provided UTF-8 string with underscores.
/// If 'ascii_only' is set to true, all codepoints outside the [0x20,0x7F) range will also be replaced with underscores.
/// Replacements are performed on a per-codepoint basis, which means the string length can be reduced by this function.
void utilsReplaceIllegalCharacters(char *str, bool ascii_only);

/// Trims whitespace characters from the provided string.
void utilsTrimString(char *str);

/// Generates a NULL-terminated hex string representation of the binary data in 'src' and stores it in 'dst'.
/// If 'uppercase' is true, uppercase characters will be used to generate the hex string. Otherwise, lowercase characters will be used.
void utilsGenerateHexString(char *dst, size_t dst_size, const void *src, size_t src_size, bool uppercase);

/// Parses the hex string in 'src' and stores its binary representation in 'dst'.
/// 'src' must match the regex /^(?:[A-Fa-f0-9]{2})+$/.
/// 'src_size' may be zero, in which case strlen() will be used to determine the length of 'src'. Furthermore, 'src_size' must always be a multiple of 2.
/// 'dst_size' must be at least 'src_size / 2'.
/// Returns false if there's an error validating input arguments.
bool utilsParseHexString(void *dst, size_t dst_size, const char *src, size_t src_size);

/// Formats the provided 'size' value to a human-readable size string and stores it in 'dst'.
void utilsGenerateFormattedSizeString(double size, char *dst, size_t dst_size);

/// Saves the total size and free space available from the filesystem pointed to by the input path (e.g. "sdmc:/") to 'out_total' and 'out_free', respectively.
/// Either 'out_total' or 'out_free' can be NULL, but at least one of them must be a valid pointer.
/// Returns false if there's an error.
bool utilsGetFileSystemStatsByPath(const char *path, u64 *out_total, u64 *out_free);

/// Returns true if a file exists.
bool utilsCheckIfFileExists(const char *path);

/// Deletes a ConcatenationFile located at the input path.
void utilsRemoveConcatenationFile(const char *path);

/// Creates a ConcatenationFile at the input path.
bool utilsCreateConcatenationFile(const char *path);

/// Creates a full directory tree using the provided path.
/// If 'create_last_element' is true, the last element from the provided path will be created as well.
void utilsCreateDirectoryTree(const char *path, bool create_last_element);

/// Calculates the size of a directory by recursively traversing all of its child entries.
/// The provided path must be absolute and it must include the virtual device name it belongs to (e.g. "sdmc:/path/to/dir").
bool utilsGetDirectorySize(const char *path, u64 *out_size);

/// Recursively deletes the directory located at the provided path and all of its contents.
/// The provided path must be absolute and it must include the virtual device name it belongs to (e.g. "sdmc:/path/to/dir").
bool utilsDeleteDirectoryRecursively(const char *path);

/// Returns a pointer to a dynamically allocated string that holds the full path formed by the provided arguments. Both path prefix and file extension are optional.
/// If any elements from the generated path exceed safe filesystem limits, each exceeding element will be truncated. Truncations, if needed, are performed on a per-codepoint basis (UTF-8).
/// If an extension is provided, it will always be preserved, regardless of any possible truncations being carried out.
/// A path separator is automatically placed between the provided prefix and the filename if the prefix doesn't end with one.
/// A dot *isn't* automatically placed between the filename and the provided extension -- if required, it must be provided as part of the extension string.
/// Furthermore, if the full length for the generated path is >= FS_MAX_PATH, NULL will be returned.
/// The allocated buffer must be freed by the calling function using free().
char *utilsGeneratePath(const char *prefix, const char *filename, const char *extension);

/// Prints an error message using the standard console output and waits for the user to press a button.
void utilsPrintConsoleError(const char *msg);

/// Read buttons.
void utilsScanPads(void);
u64 utilsGetButtonsDown(void);
u64 utilsGetButtonsHeld(void);
u64 utilsWaitForButtonPress(u64 flag);

u8 *utilsLoadFileToMemory(const char *path, size_t *out_size);

u8 *utilsLoadRgba8888ImageFromJpegBuffer(const void *jpeg_buf, size_t jpeg_buf_size, int *out_w, int *out_h);
u8 *utilsLoadRgba8888ImageFromJpegFile(const char *path, int *out_w, int *out_h);

u8 *utilsLoadRgba8888ImageFromPngBuffer(const void *png_buf, size_t png_buf_size, int *out_w, int *out_h);
u8 *utilsLoadRgba8888ImageFromPngFile(const char *path, int *out_w, int *out_h);

/// Simple wrapper to sleep the current thread for a specific number of full seconds.
NX_INLINE void utilsSleep(u64 seconds)
{
    if (seconds) svcSleepThread(seconds * (u64)1000000000);
}

NX_INLINE void utilsAppletLoopDelay(void)
{
    svcSleepThread(SIXTY_FPS_DELAY);
}

/// Wrappers used in scoped locks.
NX_INLINE UtilsScopedLock utilsLockScope(Mutex *mtx)
{
    UtilsScopedLock scoped_lock = { mtx, !mutexIsLockedByCurrentThread(mtx), 1 };
    if (scoped_lock.lock) mutexLock(scoped_lock.mtx);
    return scoped_lock;
}

NX_INLINE UtilsScopedLock utilsTryLockScope(Mutex *mtx)
{
    UtilsScopedLock scoped_lock = { mtx, !mutexIsLockedByCurrentThread(mtx), 1 };
    if (scoped_lock.lock) scoped_lock.cond = (int)mutexTryLock(scoped_lock.mtx);
    return scoped_lock;
}

NX_INLINE void utilsUnlockScope(UtilsScopedLock *scoped_lock)
{
    if (scoped_lock->lock) mutexUnlock(scoped_lock->mtx);
}

NX_INLINE double utilsDiffTimespec(const struct timespec *time1, const struct timespec *time0) {
    return ((time1->tv_sec - time0->tv_sec) + ((time1->tv_nsec - time0->tv_nsec) / 1000000000.0));
}

#ifdef __cplusplus
}
#endif

#endif /* __UTILS_H__ */
