Clone libusbhsfs into libs/libusbhsfs before building
